/* =========================================================================
   Part 3 —— 着色、拆解交互、电芯检测、仪表盘、图表与主循环
   ========================================================================= */

/* =========================================================================
   5. 物理量着色
   ========================================================================= */
const CMAP = {
  temp: { stops: [[10, '#1e3a8a'], [18, '#0ea5e9'], [25, '#22c55e'], [33, '#eab308'], [42, '#f97316'], [52, '#dc2626'], [65, '#7f1d1d']], get: c => c.T },
  volt: { stops: [[3.00, '#dc2626'], [3.40, '#f97316'], [3.70, '#22c55e'], [4.00, '#0ea5e9'], [4.20, '#7c3aed']], get: c => c.V },
  soc: { stops: [[0, '#dc2626'], [20, '#f97316'], [45, '#eab308'], [75, '#84cc16'], [100, '#16a34a']], get: c => c.soc * 100 },
  res: { stops: [[0.25, '#16a34a'], [0.45, '#84cc16'], [0.70, '#eab308'], [1.10, '#f97316'], [1.80, '#dc2626']], get: c => c.R * 1000 },
};
const _c1 = new T.Color(), _c2 = new T.Color(), _out = new T.Color();
function mapColor(mode, c) {
  const m = CMAP[mode];
  if (!m) return null;
  const v = m.get(c), S = m.stops;
  if (v <= S[0][0]) return _out.set(S[0][1]);
  if (v >= S[S.length - 1][0]) return _out.set(S[S.length - 1][1]);
  for (let i = 1; i < S.length; i++) {
    if (v <= S[i][0]) {
      const t = (v - S[i - 1][0]) / (S[i][0] - S[i - 1][0]);
      _c1.set(S[i - 1][1]); _c2.set(S[i][1]);
      return _out.copy(_c1).lerp(_c2, t);
    }
  }
  return _out.set(S[0][1]);
}

let colorMode = 'struct';
const STRUCT_BODY = new T.Color(0xa8b2c1), STRUCT_CAP = new T.Color(0xef6a1e);
const STRUCT_FILM = new T.Color(0x1e3a8a);          /* 电芯侧面 PET 绝缘蓝膜底色 */
function applyColors() {
  const isolate = !!(selected && selected.type === 'cell' && ui.ghostIso);
  for (const c of sim.cells) {
    if (colorMode === 'struct') {
      c.bodyMat.color.copy(STRUCT_BODY); c.bodyMat.emissive.setRGB(0, 0, 0); c.bodyMat.emissiveIntensity = 1;
      c.capMat.color.copy(STRUCT_CAP); c.capMat.emissive.setRGB(0, 0, 0); c.capMat.emissiveIntensity = 1;
    } else {
      const col = mapColor(colorMode, c);
      c.capMat.color.copy(col);
      c.capMat.emissive.copy(col).multiplyScalar(0.26);
      c.capMat.emissiveIntensity = 1;
      c.bodyMat.color.copy(col).lerp(STRUCT_BODY, 0.62);
      c.bodyMat.emissive.copy(col).multiplyScalar(0.14);
      c.bodyMat.emissiveIntensity = 1;
    }
    if (c.flash > 0) {
      c.capMat.emissive.setHex(0x2563eb);
      c.capMat.emissiveIntensity = 0.4 + c.flash * 2.2;
    }
    /* 侧面绝缘蓝膜跟随状态色（保留自身底色，避免遮盖热力图） */
    if (c.filmMat) {
      if (colorMode === 'struct') { c.filmMat.color.copy(STRUCT_FILM); c.filmMat.emissive.setRGB(0, 0, 0); }
      else { c.filmMat.color.copy(c.bodyMat.color).lerp(STRUCT_FILM, 0.42); }
    }
    let op = 1;
    if (ui.ghostIso) {
      if (selected && selected.type === 'cell') op = isolate && selected.cell === c ? 1 : (selected.cell === c ? 1 : 0.16);
      else if (selected && selected.type === 'module') op = selected.module === c.mod.id ? 1 : 0.16;
    }
    const tr = op < 1;
    c.bodyMat.transparent = tr; c.bodyMat.opacity = op;
    c.capMat.transparent = tr; c.capMat.opacity = op;
    if (c.filmMat) { c.filmMat.transparent = tr; c.filmMat.opacity = op; }
  }
}
function decayFlash() {
  for (const c of sim.cells) if (c.flash > 0) c.flash = Math.max(0, c.flash - 0.030);
}

/* =========================================================================
   6. 拆解 / 图层控制
   ========================================================================= */
const ui = { explode: 1.0, labels: true, rotate: true, clip: false, ghost: false, ghostIso: false, visible: {} };
LAYERS.forEach(function (l) { ui.visible[l.id] = true; });

function applyExplode() {
  LAYERS.forEach(function (l) {
    const g = layerGroups[l.id];
    if (g) g.position.y = ui.explode * l.explode;
  });
  /* 模组汇流层跟随其层位（由 LAYERS 派生，避免硬编码失配） */
  const eD1 = (LAYERS.find(l => l.id === 'deck1') || { explode: 3 }).explode;
  const eD2 = (LAYERS.find(l => l.id === 'deck2') || { explode: 6 }).explode;
  if (layerGroups.bb1) layerGroups.bb1.position.y = ui.explode * eD1;
  if (layerGroups.bb2) layerGroups.bb2.position.y = ui.explode * eD2;
  /* 模组内电芯微量抬升，体现模组可拆 */
  MODULES.forEach(function (m) {
    m.cells.forEach(function (c) { c.group.position.y = c.baseY + ui.explode * 0.10; });
  });
}
function applyVisibility() {
  LAYERS.forEach(function (l) {
    const g = layerGroups[l.id];
    if (g) g.visible = ui.visible[l.id];
  });
  if (layerGroups.bb1) layerGroups.bb1.visible = ui.visible.deck1;
  if (layerGroups.bb2) layerGroups.bb2.visible = ui.visible.deck2;
}
function applyGhost() {
  GHOST_MATS.forEach(function (m) {
    m.transparent = ui.ghost; m.opacity = ui.ghost ? 0.34 : 1; m.depthWrite = !ui.ghost;
    m.needsUpdate = true;
  });
}
function applyClip() {
  renderer.clippingPlanes = ui.clip ? [new T.Plane(new T.Vector3(0, 0, -1), 0.8)] : [];
}

/* =========================================================================
   7. 拾取与选中
   ========================================================================= */
const ray = new T.Raycaster();
const ndc = new T.Vector2();
const tip = $('tooltip');
let selected = null;
const boxHelper = new T.BoxHelper(new T.Object3D(), 0x2563eb);
boxHelper.visible = false; scene.add(boxHelper);

function visibleChain(o) { let p = o; while (p) { if (p.visible === false) return false; p = p.parent; } return true; }
function pickAt(cx, cy) {
  const r = canvas.getBoundingClientRect();
  ndc.x = ((cx - r.left) / r.width) * 2 - 1;
  ndc.y = -((cy - r.top) / r.height) * 2 + 1;
  ray.setFromCamera(ndc, camera);
  const hits = ray.intersectObjects(pickables, false);
  for (let i = 0; i < hits.length; i++) if (visibleChain(hits[i].object)) return hits[i];
  return null;
}
function showTip(html, cx, cy) {
  const r = canvas.getBoundingClientRect();
  tip.innerHTML = html;
  tip.style.opacity = 1;
  tip.style.left = (cx - r.left) + 'px';
  tip.style.top = (cy - r.top) + 'px';
}
canvas.addEventListener('pointermove', function (e) {
  const hit = pickAt(e.clientX, e.clientY);
  const info = hit && hit.object.userData.pick;
  if (info && info.type === 'cell') {
    const c = info.cell;
    showTip('<div class="tt">' + c.id + ' · 第 ' + c.serial + ' 串</div>' +
      '<div class="tr">电压 <b>' + fmt(c.V, 4) + ' V</b> · SOC <b>' + fmt(c.soc * 100, 1) + ' %</b></div>' +
      '<div class="tr">温度 <b>' + fmt(c.T, 2) + ' ℃</b> · 内阻 <b>' + fmt(c.R * 1000, 3) + ' mΩ</b></div>' +
      '<div class="tr">单击可拆解检测该单体</div>', e.clientX, e.clientY);
    canvas.style.cursor = 'pointer';
  } else if (info && info.type === 'module') {
    const m = sim.modules[info.module];
    const tmx = Math.max.apply(null, m.cells.map(c => c.T));
    const tmn = Math.min.apply(null, m.cells.map(c => c.T));
    showTip('<div class="tt">' + m.id + ' · ' + m.name + '</div>' +
      '<div class="tr">12S1P · 电压 <b>' + fmt(m.cells.reduce((a, c) => a + c.V, 0), 2) + ' V</b></div>' +
      '<div class="tr">模组温度 <b>' + fmt(tmn, 1) + ' ~ ' + fmt(tmx, 1) + ' ℃</b></div>', e.clientX, e.clientY);
    canvas.style.cursor = 'pointer';
  } else if (info && info.type === 'layer') {
    const L = LAYERS.find(l => l.id === info.layer);
    showTip('<div class="tt">' + (L ? L.name : '') + '</div><div class="tr">结构层 · 单击查看该层参数</div>', e.clientX, e.clientY);
    canvas.style.cursor = 'pointer';
  } else {
    tip.style.opacity = 0; canvas.style.cursor = 'grab';
  }
});
canvas.addEventListener('pointerleave', function () { tip.style.opacity = 0; });
let downXY = null;
canvas.addEventListener('pointerdown', function (e) { downXY = [e.clientX, e.clientY]; });
canvas.addEventListener('pointerup', function (e) {
  if (!downXY) return;
  const moved = Math.hypot(e.clientX - downXY[0], e.clientY - downXY[1]);
  downXY = null;
  if (moved > 5 || e.button !== 0) return;
  const hit = pickAt(e.clientX, e.clientY);
  const info = hit && hit.object.userData.pick;
  if (!info) { select(null); return; }
  if (info.type === 'cell') select({ type: 'cell', cell: info.cell });
  else if (info.type === 'module') select({ type: 'module', module: info.module });
  else if (info.type === 'layer') select({ type: 'layer', layer: info.layer });
});

function select(sel) {
  selected = sel;
  const ft = $('ftSel');
  if (!sel) {
    boxHelper.visible = false; probe.visible = false;
    ft.textContent = '未选中对象';
    renderDetail(); applyColors(); return;
  }
  let obj = null;
  if (sel.type === 'cell') { obj = sel.cell.group; ft.textContent = '已选中单体 ' + sel.cell.id + '（第 ' + sel.cell.serial + ' 串）'; }
  else if (sel.type === 'module') { obj = sim.modules[sel.module].group; ft.textContent = '已选中 ' + sel.module + ' 模组'; }
  else {
    obj = layerGroups[sel.layer];
    const L = LAYERS.find(l => l.id === sel.layer);
    ft.textContent = '已选中结构层：' + (L ? L.name : '');
  }
  if (obj) { boxHelper.setFromObject(obj); boxHelper.visible = true; }
  applyColors(); renderDetail();
}
function toggleGhostIso(v) {
  ui.ghostIso = v;
  const el = $('tgIso');
  if (el) el.classList.toggle('on', v);
  applyColors();
}
function updateProbe() {
  if (!test.active || !test.cell) { probe.visible = false; return; }
  const c = test.cell, wp = new T.Vector3();
  c.group.getWorldPosition(wp);
  probe.visible = true;
  probe.position.set(wp.x, wp.y + CFG.cellH / 2 + 0.58, wp.z);
  const ring = probe.children[2];
  const s = 1 + Math.sin(sim.t * 9) * 0.08;
  ring.scale.set(s, s, s);
  ring.material.opacity = 0.5 + Math.sin(sim.t * 9) * 0.35;
}

/* =========================================================================
   8. 图层标注
   ========================================================================= */
const labelHost = $('labelHost');
const layerLabels = {};
LAYERS.forEach(function (l) {
  const d = document.createElement('div');
  d.className = 'lbl' + ((l.id === 'harn' || l.id === 'fire') ? ' orange' : '');
  d.textContent = l.name;
  labelHost.appendChild(d);
  layerLabels[l.id] = d;
});
const _v3 = new T.Vector3();
function updateLabels() {
  const show = ui.labels && ui.explode > 0.12;
  LAYERS.forEach(function (l) {
    const el = layerLabels[l.id];
    if (!show || !ui.visible[l.id]) { el.classList.remove('show'); return; }
    _v3.set(-PACK_HX - 0.35, l.y + ui.explode * l.explode, -PACK_HZ - 0.45).project(camera);
    if (_v3.z > 1) { el.classList.remove('show'); return; }
    const r = stage.getBoundingClientRect();
    el.style.left = ((_v3.x * 0.5 + 0.5) * r.width) + 'px';
    el.style.top = ((-_v3.y * 0.5 + 0.5) * r.height) + 'px';
    el.classList.add('show');
  });
}

/* =========================================================================
   9. 图表
   ========================================================================= */
class Chart {
  constructor(cv, series, max) {
    this.cv = cv; this.ctx = cv.getContext('2d'); this.series = series;
    this.data = series.map(function () { return []; });
    this.max = max || 200;
    this.range = series.map(function () { return [Infinity, -Infinity]; });
    this.resize();
  }
  resize() {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = this.cv.clientWidth || 300, h = this.cv.clientHeight || 88;
    this.cv.width = Math.floor(w * dpr); this.cv.height = Math.floor(h * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.w = w; this.h = h;
  }
  push(vals) {
    const self = this;
    vals.forEach(function (v, i) {
      if (v === null || !isFinite(v)) return;
      const arr = self.data[i];
      arr.push(v);
      if (arr.length > self.max) arr.shift();
      let mn = Infinity, mx = -Infinity;
      for (let k = 0; k < arr.length; k++) { if (arr[k] < mn) mn = arr[k]; if (arr[k] > mx) mx = arr[k]; }
      const pad = (mx - mn) * 0.18 + 1e-6;
      self.range[i] = [mn - pad, mx + pad];
    });
  }
  draw() {
    const g = this.ctx, W = this.w, H = this.h, padL = 6, padR = 6, padT = 5, padB = 5;
    g.clearRect(0, 0, W, H);
    g.strokeStyle = '#eaeff6'; g.lineWidth = 1;
    for (let i = 1; i < 4; i++) {
      const y = padT + (H - padT - padB) * i / 4;
      g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke();
    }
    const self = this;
    this.series.forEach(function (s, si) {
      const arr = self.data[si];
      if (arr.length < 2) return;
      const r = self.range[si], span = (r[1] - r[0]) || 1;
      g.beginPath();
      for (let i = 0; i < arr.length; i++) {
        const x = padL + (W - padL - padR) * i / (self.max - 1);
        const y = padT + (H - padT - padB) * (1 - (arr[i] - r[0]) / span);
        i === 0 ? g.moveTo(x, y) : g.lineTo(x, y);
      }
      g.strokeStyle = s.color; g.lineWidth = 1.6; g.lineJoin = 'round'; g.stroke();
      const last = arr[arr.length - 1];
      const x = padL + (W - padL - padR) * (arr.length - 1) / (self.max - 1);
      const y = padT + (H - padT - padB) * (1 - (last - r[0]) / span);
      g.fillStyle = s.color;
      g.beginPath(); g.arc(x, y, 2.2, 0, Math.PI * 2); g.fill();
      g.font = '600 9.5px "JetBrains Mono",Consolas,monospace';
      g.fillStyle = s.color;
      const right = x > W - 44;
      g.textAlign = right ? 'right' : 'left';
      g.fillText(fmt(last, s.dp), right ? x - 5 : x + 5, Math.max(9, Math.min(H - 3, y + 3)));
    });
  }
}
let chart1 = null, chart2 = null;

/* ---------- 扫描报告 ---------- */
function drawSweepChart(res) {
  const cv = $('sweepChart');
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const w = cv.clientWidth || 800, h = cv.clientHeight || 150;
  cv.width = Math.floor(w * dpr); cv.height = Math.floor(h * dpr);
  const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, w, h);
  const vals = res.map(r => r.R * 1000);
  const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
  const sd = Math.sqrt(vals.reduce((a, b) => a + (b - mean) * (b - mean), 0) / vals.length);
  let mn = Math.min.apply(null, vals), mx = Math.max.apply(null, vals);
  mn = mn - (mx - mn) * 0.12; mx = mx + (mx - mn) * 0.12;
  const padL = 38, padB = 16, padT = 10;
  const bw = (w - padL - 10) / vals.length;
  const yOf = v => padT + (h - padT - padB) * (1 - (v - mn) / (mx - mn));
  /* ±2σ 带 */
  g.fillStyle = 'rgba(21,128,61,.07)';
  const yTop = yOf(Math.min(mx, mean + 2 * sd)), yBot = yOf(Math.max(mn, mean - 2 * sd));
  g.fillRect(padL, yTop, w - padL - 10, Math.max(1, yBot - yTop));
  g.strokeStyle = '#cbd5e1'; g.setLineDash([3, 3]); g.lineWidth = 1;
  g.beginPath(); g.moveTo(padL, yOf(mean)); g.lineTo(w - 10, yOf(mean)); g.stroke();
  g.setLineDash([]);
  const self = this;
  vals.forEach(function (v, i) {
    const x = padL + i * bw;
    const out = Math.abs(v - mean) > 3 * sd;
    g.fillStyle = out ? '#dc2626' : (v > mean + sd ? '#f97316' : (v < mean - sd ? '#2563eb' : '#94a3b8'));
    const y = yOf(v);
    g.fillRect(x + bw * 0.16, y, Math.max(1.5, bw * 0.68), h - padB - y);
  });
  g.fillStyle = '#93a1b5'; g.font = '10px "JetBrains Mono",Consolas,monospace';
  g.textAlign = 'right';
  g.fillText(fmt(mn, 2), padL - 6, yOf(mn) + 3);
  g.fillText(fmt((mn + mx) / 2, 2), padL - 6, yOf((mn + mx) / 2) + 3);
  g.fillText(fmt(mx, 2), padL - 6, padT + 8);
  g.textAlign = 'center';
  g.fillText('单体序号 1 → 72（按串接顺序）', w / 2, h - 3);
  return { mean: mean, sd: sd };
}
function showSweepReport() {
  const res = sweep.results;
  if (!res.length) return;
  const st = drawSweepChart(res);
  const vals = res.map(r => r.R * 1000);
  const mn = Math.min.apply(null, vals), mx = Math.max.apply(null, vals);
  const outliers = res.filter(r => Math.abs(r.R * 1000 - st.mean) > 3 * st.sd);
  const worst = res.slice().sort((a, b) => Math.abs(b.R - st.mean) - Math.abs(a.R - st.mean)).slice(0, 6);
  const cvr = st.sd / st.mean;
  const grade = cvr < 0.03 ? ['优', 'ok', '#15803d'] : (cvr < 0.06 ? ['良', 'info', '#1d4ed8'] : ['关注', 'warn', '#c2740b']);
  $('sweepMeta').textContent = '方法：25 A / 600 ms 恒流脉冲，ΔV/ΔI 在线辨识 · 采样点 ' + res.length +
    ' · 执行时刻 t = ' + fmt(sim.t, 1) + ' s · 单体平均温度 ' + fmt(sim.tavg, 1) + ' ℃';
  const items = [
    ['平均直流内阻', fmt(st.mean, 3), 'mΩ', ''],
    ['标准差 σ', fmt(st.sd * 1000, 1), 'µΩ', ''],
    ['极差 Rmax−Rmin', fmt((mx - mn) * 1000, 1), 'µΩ', ''],
    ['离散系数 σ/R̄', fmt(cvr * 100, 2), '%', ''],
    ['3σ 离群单体', outliers.length, '只', outliers.length ? 'color:#c2740b' : 'color:#15803d'],
    ['一致性评级', grade[0], '', 'color:' + grade[2]],
  ];
  $('sweepStats').innerHTML = items.map(function (it) {
    return '<div class="k"><span>' + it[0] + '</span><b style="' + it[3] + '">' + it[1] + '<i>' + it[2] + '</i></b></div>';
  }).join('');
  $('sweepList').innerHTML = worst.map(function (r, i) {
    const c = r.cell;
    const dev = (r.R * 1000 - st.mean) / st.mean * 100;
    return '<div class="it"><div class="id">#' + (i + 1) + ' ' + c.id + ' · 第 ' + c.serial + ' 串</div>' +
      '<div class="d">R = ' + fmt(r.R * 1000, 3) + ' mΩ  偏离均值 ' + (dev > 0 ? '+' : '') + fmt(dev, 2) + '%</div>' +
      '<div class="d">T = ' + fmt(c.T, 1) + ' ℃ · SOC = ' + fmt(c.soc * 100, 1) + '% · 产热 ' + fmt(Math.max(0, c.heat), 2) + ' W</div></div>';
  }).join('');
  $('sweepModal').classList.add('show');
  pushAlarm(outliers.length ? 'w' : 'i', '内阻扫描完成：均值 ' + fmt(st.mean, 3) + ' mΩ，σ/R̄ = ' + fmt(cvr * 100, 2) + '%，3σ 离群 ' + outliers.length + ' 只，评级 ' + grade[0]);
}

/* =========================================================================
   10. 仪表盘渲染
   ========================================================================= */
function renderAlarms() {
  const host = $('alarmList');
  if (!alarms.length) { host.innerHTML = '<div class="empty">暂无报警事件</div>'; return; }
  host.innerHTML = alarms.slice(0, 24).map(function (a) {
    return '<div class="alarm ' + a.lvl + '"><span class="tm">' + a.t.toFixed(1) + 's</span><span class="ms">' + a.msg + '</span></div>';
  }).join('');
}
function renderLegend() {
  const L = LEGENDS[colorMode];
  $('legendTitle').textContent = L.title;
  $('legendBar').style.background = L.bar;
  $('legendScale').innerHTML = L.scale.map(s => '<span>' + s + '</span>').join('');
  $('legendNote').innerHTML = L.note;
  $('colorHint').textContent = COLOR_MODES.find(c => c.id === colorMode).hint;
}
function updateDashboard() {
  const soc = sim.socAvg * 100;
  $('mSoc').innerHTML = fmt(soc, 1) + '<i>%</i>';
  const bar = $('mSocBar');
  bar.style.width = clamp(soc, 0, 100) + '%';
  bar.style.background = soc > 30 ? '#2563eb' : (soc > 15 ? '#c2740b' : '#dc2626');
  $('mSoh').innerHTML = fmt(sim.sohC * 100, 2) + '<i>%</i>';
  $('mSohS').textContent = 'SOH-R ' + fmt(sim.sohR * 100, 1) + '% · SOH-P ' + fmt(sim.sohP * 100, 1)
    + '% · 等效 ' + fmt(sim.cycDose, 2) + ' 次循环';
  $('mVpack').innerHTML = fmt(sim.Vpack, 2) + '<i>V</i>';
  $('mVpackS').textContent = CFG.series + 'S × ' + fmt(sim.Vpack / CFG.series, 3) + ' V/单体';
  $('mIpack').innerHTML = fmt(sim.Ipack, 1) + '<i>A</i>';
  $('mIpackS').textContent = fmt(sim.Ipack / CFG.CapAh, 2) + ' C · ' + (sim.Ipack > 0.5 ? '放电' : (sim.Ipack < -0.5 ? '充电' : '静置'));
  $('mPower').innerHTML = fmt(sim.P / 1000, 2) + '<i>kW</i>';
  $('mPowerS').textContent = '限值 ' + fmt(sim.PlimitD / 1000, 0) + ' / ' + fmt(sim.PlimitC / 1000, 0) + ' kW';
  const eNom = CFG.CapAh * CFG.series * CFG.Vnom / 1000;
  const eAvail = eNom * sim.sohC;
  const eNow = eAvail * sim.socAvg;
  $('mEnergy').innerHTML = fmt(eNow, 2) + '<i>kWh</i>';
  $('mEnergyS').textContent = '额定 ' + fmt(eAvail, 1) + ' kWh · 可用 ' + fmt(eNow * 0.97, 1) + ' kWh';

  /* ---- 标称电压 / 开路电压 ---- */
  $('mVnom').innerHTML = fmt(VNOM_PACK, 1) + '<i>V</i>';
  $('mVnomS').textContent = CFG.series + 'S × ' + fmt(CFG.Vnom, 2) + ' V · 平台电压（常量）';
  $('mOcv').innerHTML = fmt(sim.ocvPack, 2) + '<i>V</i>';
  $('mOcvS').textContent = '单体均值 ' + fmt(sim.ocvAvg, 4) + ' V · 端压 ' + fmt(sim.Vpack, 2) + ' V';
  /* ---- SOP ---- */
  const sp = sim.sop;
  $('mSopD').innerHTML = fmt(sp.PdPeak / 1000, 1) + '<i>kW</i>';
  $('mSopDS').textContent = '持续 ' + fmt(sp.PdCont / 1000, 1) + ' kW · ' + fmt(sp.IdPeak, 0) + ' A · ' + sp.limD;
  $('mSopC').innerHTML = fmt(sp.PcPeak / 1000, 1) + '<i>kW</i>';
  $('mSopCS').textContent = '持续 ' + fmt(sp.PcCont / 1000, 1) + ' kW · ' + fmt(sp.IcPeak, 0) + ' A · ' + sp.limC;

  /* ---- 老化与健康状态 SOH ---- */
  $('kSohC').innerHTML = fmt(sim.sohC * 100, 2) + '<span class="u">%</span>';
  $('kSohR').innerHTML = fmt(sim.sohR * 100, 2) + '<span class="u">%</span>';
  $('kSohP').innerHTML = fmt(sim.sohP * 100, 2) + '<span class="u">%</span>';
  $('kQloss').innerHTML = fmt(sim.qLossCyc * 100, 3) + ' / ' + fmt(sim.qLossCal * 100, 3) + '<span class="u">%</span>';
  $('kRgrowth').innerHTML = fmt(1 + CFG.kRgrowth * sim.qLoss, 3) + '<span class="u">×</span>';
  $('kCyc2').innerHTML = fmt(sim.cycDose, 2) + ' 次 / ' + fmt(sim.throughput / 1000, 3) + ' kAh';
  $('kRul').innerHTML = isFinite(sim.rulCyc)
    ? fmt(sim.rulCyc, 0) + ' 次 · ' + fmt(sim.rulKm / 10000, 1) + ' 万 km · ' + fmt(sim.rulDays / 365, 1) + ' 年'
    : '--';
  $('kRulLim').textContent = sim.rulLimit;

  /* ---- 电压与功率状态 SOP ---- */
  $('kVolt3').innerHTML = fmt(VNOM_PACK, 1) + ' / ' + fmt(sim.ocvPack, 2) + ' / ' + fmt(sim.Vpack, 2) + '<span class="u">V</span>';
  $('kVrange').innerHTML = fmt(VMIN_PACK, 1) + ' ~ ' + fmt(VMAX_PACK, 1) + '<span class="u">V</span>';
  $('kEnergy2').innerHTML = fmt(ENOM_PACK, 1) + ' / ' + fmt(ENOM_PACK * sim.sohC * sim.socAvg * 0.97, 1) + '<span class="u">kWh</span>';
  $('kRpack').innerHTML = fmt(sim.rPack * 1000, 1) + '<span class="u">mΩ</span>';
  $('kId').innerHTML = fmt(sp.IdCont, 0) + ' / ' + fmt(sp.IdPeak, 0) + '<span class="u">A</span>';
  $('kIc').innerHTML = fmt(sp.IcCont, 0) + ' / ' + fmt(sp.IcPeak, 0) + '<span class="u">A</span>';
  $('kLimD').textContent = sp.limD;
  $('kLimC').textContent = sp.limC;

  $('kVmax').innerHTML = fmt(sim.vmax, 4) + '<span class="u">V</span>';
  $('kVmin').innerHTML = fmt(sim.vmin, 4) + '<span class="u">V</span>';
  const dv = (sim.vmax - sim.vmin) * 1000;
  const dvc = dv > CFG.dVwarn * 1000 ? '#dc2626' : (dv > 60 ? '#c2740b' : '#15803d');
  $('kVdelta').innerHTML = '<span style="color:' + dvc + '">' + fmt(dv, 1) + '</span><span class="u">mV</span>';
  $('kRavg').innerHTML = fmt(sim.ravg * 1000, 4) + '<span class="u">mΩ</span>';
  $('kTmax').innerHTML = '<span style="color:' + (sim.tmax > CFG.TmaxWarn ? '#dc2626' : '#0f172a') + '">' + fmt(sim.tmax, 2) + '</span><span class="u">°C</span>';
  $('kTmin').innerHTML = fmt(sim.tmin, 2) + '<span class="u">°C</span>';
  $('kTdelta').innerHTML = fmt(sim.tmax - sim.tmin, 2) + '<span class="u">K</span>';

  $('kCool').innerHTML = fmt(CFG.TcoolIn, 0) + ' / ' + fmt(sim.coolOut, 2) + '<span class="u">°C</span>';
  $('kHeat').innerHTML = fmt(sim.heat / 1000, 3) + '<span class="u">kW</span>';
  $('kHa').innerHTML = fmt(sim.hA, 2) + '<span class="u">W/K·芯</span>';
  $('kPump').innerHTML = fmt(sim.pump * 0.045, 1) + '<span class="u">W</span>';

  $('kIso').innerHTML = '<span style="color:' + (sim.iso < 500 ? '#dc2626' : '#15803d') + '">' + fmt(sim.iso, 0) + '</span><span class="u">MΩ</span>';
  $('kPd').innerHTML = fmt(sim.sop.PdCont / 1000, 1) + ' / ' + fmt(sim.sop.PdPeak / 1000, 1) + '<span class="u">kW</span>';
  $('kPc').innerHTML = fmt(sim.sop.PcCont / 1000, 1) + ' / ' + fmt(sim.sop.PcPeak / 1000, 1) + '<span class="u">kW</span>';
  $('kAh').innerHTML = fmt(sim.throughput / 1000, 3) + '<span class="u">kAh</span>';
  $('kCyc').innerHTML = fmt(sim.cycDose, 2) + '<span class="u">次</span>';
  $('ftSim').textContent = '仿真时钟 ' + sim.t.toFixed(1) + ' s';

  const modeName = MODES.find(m => m.id === sim.mode).name;
  const lvl = (sim.tmax > CFG.TmaxFault || sim.vmax > CFG.Vmax || sim.vmin < CFG.Vmin) ? 'e'
    : ((sim.tmax > CFG.TmaxWarn || (sim.vmax - sim.vmin) > CFG.dVwarn) ? 'w' : '');
  $('badges').innerHTML =
    '<div class="pill"><span class="dt ' + lvl + '"></span>工况 <b>' + modeName + '</b></div>' +
    '<div class="pill">车速 <b>' + fmt(sim.speedKmh, 0) + '</b> km/h</div>' +
    '<div class="pill">平均温度 <b>' + fmt(sim.tavg, 1) + '</b> ℃</div>' +
    '<div class="pill">SOC <b>' + fmt(soc, 1) + '</b> %</div>' +
    '<div class="pill">' + (sim.pump > 0 ? '液冷运行' : '液冷停机') + ' · 出口 <b>' + fmt(sim.coolOut, 1) + '</b> ℃</div>';
}

/* ---------- 详情面板 ---------- */
function renderDetail() {
  const host = $('detailHost');
  if (!selected) { host.innerHTML = '<div class="empty">单击模型中的电芯 / 模组 / 结构层查看详细参数</div>'; return; }
  if (selected.type === 'cell') {
    const c = selected.cell, m = c.mod;
    const vavg = (sim.vmax + sim.vmin) / 2;
    const dvm = (c.V - vavg) * 1000;
    const dtk = c.T - sim.tavg;
    const grade = (Math.abs(dvm) < 10 && Math.abs(dtk) < 1.5) ? ['优', 'ok']
      : ((Math.abs(dvm) < 22 && Math.abs(dtk) < 3) ? ['良', 'info'] : ['关注', 'warn']);
    const testing = test.active && test.cell === c;
    const ph = testing ? test.phase : 4;
    const phaseName = ['基线采样', '施加 25 A 脉冲', 'ΔV/ΔI 运算', '完成'][test.phase];
    host.innerHTML =
      '<div class="detail">' +
      '<div class="dh"><div><div class="n">' + c.id + '</div><div class="t">' + m.name + ' · 第 ' + c.serial + ' 串 · 行' + (c.row + 1) + '/列' + (c.col + 1) + '</div></div>' +
      '<button class="x" id="dClose">×</button></div>' +
      '<div class="db"><table class="kv">' +
      '<tr><td>端电压 V</td><td>' + fmt(c.V, 4) + '<span class="u">V</span></td></tr>' +
      '<tr><td>开路电压 OCV</td><td>' + fmt(ocvOf(c.soc), 4) + '<span class="u">V</span></td></tr>' +
      '<tr><td>极化压降 I·R</td><td>' + fmt(Math.abs(sim.Ipack * c.R), 4) + '<span class="u">V</span></td></tr>' +
      '<tr><td>荷电状态 SOC</td><td>' + fmt(c.soc * 100, 2) + '<span class="u">%</span></td></tr>' +
      '<tr><td>电芯温度</td><td>' + fmt(c.T, 3) + '<span class="u">℃</span></td></tr>' +
      '<tr><td>局部冷却液温</td><td>' + fmt(c.Tcool, 2) + '<span class="u">℃</span></td></tr>' +
      '<tr><td>直流内阻 R</td><td>' + fmt(c.R * 1000, 4) + '<span class="u">mΩ</span></td></tr>' +
      '<tr><td>当前产热功率</td><td>' + fmt(Math.max(0, c.heat), 3) + '<span class="u">W</span></td></tr>' +
      '<tr><td>容量离散系数</td><td>' + fmt(c.capFactor, 4) + '</td></tr>' +
      '<tr><td>累计吞吐电量</td><td>' + fmt(c.throughAh, 3) + '<span class="u">Ah</span></td></tr>' +
      '</table>' +
      '<div style="display:flex;gap:6px;margin-top:9px;align-items:center;flex-wrap:wrap">' +
      '<span class="tag ' + grade[1] + '">一致性 ' + grade[0] + '</span>' +
      '<span class="tag info">ΔV ' + (dvm > 0 ? '+' : '') + fmt(dvm, 2) + ' mV</span>' +
      '<span class="tag ' + (Math.abs(dtk) > 2 ? 'warn' : 'ok') + '">ΔT ' + (dtk > 0 ? '+' : '') + fmt(dtk, 2) + ' K</span>' +
      '</div>' +
      '<div class="testbox">' +
      '<div class="tst"><span>单体直流内阻脉冲辨识</span><span>' + (testing ? phaseName : '待机') + '</span></div>' +
      '<div class="phases">' + [0, 1, 2, 3].map(function (i) {
        return '<i class="' + (ph > i ? 'done' : ((ph === i && testing) ? 'on' : '')) + '"></i>';
      }).join('') + '</div>' +
      '<div class="mres">' +
      ((test.result && test.cell === c)
        ? 'ΔV = <b>' + fmt(test.result.dv * 1000, 3) + ' mV</b> · ΔI = <b>' + fmt(test.result.di, 1) + ' A</b><br>' +
        '实测 R = <b>' + fmt(test.result.Rm * 1000, 4) + ' mΩ</b> · 模型 R = ' + fmt(test.result.Rmodel * 1000, 4) + ' mΩ<br>' +
        '相对偏差 <b>' + (test.result.err > 0 ? '+' : '') + fmt(test.result.err, 2) + ' %</b>（含 1.8% 采样噪声）'
        : (c.Rmeas ? '上次辨识值 <b>' + fmt(c.Rmeas * 1000, 4) + ' mΩ</b> · 当前模型值 ' + fmt(c.R * 1000, 4) + ' mΩ'
          : '尚未对该单体执行内阻辨识'))
      + '</div>' +
      '<button class="btn primary sm" id="dTest" style="width:100%;justify-content:center;margin-top:8px">⚡ 对 ' + c.id + ' 执行内阻检测</button>' +
      '<button class="btn sm" id="dFocus" style="width:100%;justify-content:center;margin-top:7px">隔离定位该单体</button>' +
      '<button class="btn sm" id="dPeek" style="width:100%;justify-content:center;margin-top:7px">查看所在模组</button>' +
      '</div></div></div>';
    $('dTest').onclick = function () { startTest(c); renderDetail(); };
    $('dFocus').onclick = function () { toggleGhostIso(true); focusCell(c); };
    $('dPeek').onclick = function () { select({ type: 'module', module: m.id }); };
  } else if (selected.type === 'module') {
    const m = sim.modules[selected.module], cs = m.cells;
    const vmn = Math.min.apply(null, cs.map(c => c.V)), vmx = Math.max.apply(null, cs.map(c => c.V));
    const tmn = Math.min.apply(null, cs.map(c => c.T)), tmx = Math.max.apply(null, cs.map(c => c.T));
    const rmn = Math.min.apply(null, cs.map(c => c.R)), rmx = Math.max.apply(null, cs.map(c => c.R));
    const socm = cs.reduce((a, c) => a + c.soc, 0) / cs.length;
    const lname = LAYERS.find(l => l.id === (m.deck === 1 ? 'deck1' : 'deck2')).name;
    host.innerHTML =
      '<div class="detail">' +
      '<div class="dh" style="background:linear-gradient(135deg,#0f172a,#334155)">' +
      '<div><div class="n">' + m.id + '</div><div class="t">' + m.name + ' · ' + (m.deck === 1 ? '下层托盘位' : '上层叠置位') + ' · 12S1P</div></div>' +
      '<button class="x" id="dClose">×</button></div>' +
      '<div class="db"><table class="kv">' +
      '<tr><td>模组端电压</td><td>' + fmt(cs.reduce((a, c) => a + c.V, 0), 3) + '<span class="u">V</span></td></tr>' +
      '<tr><td>平均 SOC</td><td>' + fmt(socm * 100, 2) + '<span class="u">%</span></td></tr>' +
      '<tr><td>模组内压差</td><td>' + fmt((vmx - vmn) * 1000, 2) + '<span class="u">mV</span></td></tr>' +
      '<tr><td>平均温度</td><td>' + fmt(cs.reduce((a, c) => a + c.T, 0) / cs.length, 2) + '<span class="u">℃</span></td></tr>' +
      '<tr><td>模组内温差</td><td>' + fmt(tmx - tmn, 2) + '<span class="u">K</span></td></tr>' +
      '<tr><td>内阻范围</td><td>' + fmt(rmn * 1000, 3) + '~' + fmt(rmx * 1000, 3) + '<span class="u">mΩ</span></td></tr>' +
      '<tr><td>液冷流程位置</td><td>' + fmt(m.flow * 100, 0) + '<span class="u">%</span></td></tr>' +
      '<tr><td>所属结构层</td><td style="font-size:10.5px">' + lname + '</td></tr>' +
      '</table>' +
      '<div style="display:flex;gap:6px;margin-top:9px;flex-wrap:wrap">' +
      '<span class="tag ' + ((tmx - tmn) > 3 ? 'warn' : 'ok') + '">温差 ' + fmt(tmx - tmn, 2) + ' K</span>' +
      '<span class="tag ' + ((vmx - vmn) > 0.03 ? 'warn' : 'ok') + '">压差 ' + fmt((vmx - vmn) * 1000, 1) + ' mV</span>' +
      '<span class="tag info">12 只电芯</span></div>' +
      '<div class="hint" style="margin-top:9px">展开「' + lname + '」层后可直接单击任一电芯，查看单体级参数并执行内阻检测。</div>' +
      '</div></div>';
  } else {
    const L = LAYERS.find(l => l.id === selected.layer);
    if (!L) { host.innerHTML = '<div class="empty">无数据</div>'; return; }
    const d1 = MODULES.filter(m => m.deck === 1);
    const extra = {
      tray: '<tr><td>整包外形尺寸</td><td>' + (CFG.packL * 1000) + '×' + (CFG.packW * 1000) + '×' + (CFG.packH * 1000) + '<span class="u">mm</span></td></tr>' +
        '<tr><td>整包质量</td><td>' + CFG.massPack + '<span class="u">kg</span></td></tr>' +
        '<tr><td>比能量 / 能量密度</td><td>167 Wh/kg · 98 Wh/L</td></tr>' +
        '<tr><td>密封等级</td><td>IP68</td></tr>',
      cool: '<tr><td>入口温度</td><td>' + fmt(CFG.TcoolIn, 1) + '<span class="u">℃</span></td></tr>' +
        '<tr><td>出口温度</td><td>' + fmt(sim.coolOut, 2) + '<span class="u">℃</span></td></tr>' +
        '<tr><td>冷却液温升 ΔT</td><td>' + fmt(sim.coolOut - CFG.TcoolIn, 2) + '<span class="u">K</span></td></tr>' +
        '<tr><td>当前散热量</td><td>' + fmt(sim.heat / 1000, 3) + '<span class="u">kW</span></td></tr>' +
        '<tr><td>热容流率 m·c<sub>p</sub></td><td>' + fmt(sim.pump, 0) + '<span class="u">W/K</span></td></tr>',
      deck1: '<tr><td>模组数量</td><td>5 × 12S1P</td></tr>' +
        '<tr><td>串接电压</td><td>60 × 3.7 = 222<span class="u">V</span></td></tr>' +
        '<tr><td>平均温度</td><td>' + fmt(d1.reduce((a, m) => a + m.cells.reduce((x, c) => x + c.T, 0), 0) / 60, 2) + '<span class="u">℃</span></td></tr>' +
        '<tr><td>模组压差</td><td>' + fmt((sim.vmax - sim.vmin) * 1000, 1) + '<span class="u">mV</span></td></tr>',
      deck2: '<tr><td>模组数量</td><td>1 × 12S1P（层叠）</td></tr>' +
        '<tr><td>串接电压</td><td>12 × 3.7 = 44.4<span class="u">V</span></td></tr>' +
        '<tr><td>平均温度</td><td>' + fmt(sim.modules['M6'].cells.reduce((a, c) => a + c.T, 0) / 12, 2) + '<span class="u">℃</span></td></tr>' +
        '<tr><td>液冷流程位置</td><td>92<span class="u">%</span>（末端）</td></tr>',
      inter: '<tr><td>电压采样通道</td><td>72 路（12 路/模组）</td></tr>' +
        '<tr><td>采样精度</td><td>±1.5<span class="u">mV</span></td></tr>' +
        '<tr><td>均衡方式</td><td>被动均衡 100 mA</td></tr>',
      ntc: '<tr><td>测温点数量</td><td>24 只（4 只/模组）</td></tr>' +
        '<tr><td>传感器类型</td><td>NTC 10 kΩ / B<sub>25/50</sub>=3435 K</td></tr>' +
        '<tr><td>测量精度</td><td>±0.5<span class="u">℃</span>（25~60 ℃ 区间）</td></tr>' +
        '<tr><td>当前最高测点</td><td>' + fmt(sim.tmax, 2) + '<span class="u">℃</span></td></tr>' +
        '<tr><td>当前最低测点</td><td>' + fmt(sim.tmin, 2) + '<span class="u">℃</span></td></tr>' +
        '<tr><td>采样周期</td><td>100<span class="u">ms</span></td></tr>',
      sense: '<tr><td>采集板数量</td><td>6 块 CSC（1 块/模组）</td></tr>' +
        '<tr><td>单板通道</td><td>12 路电压 + 4 路温度</td></tr>' +
        '<tr><td>电压分辨率</td><td>16 bit · ±1.5<span class="u">mV</span></td></tr>' +
        '<tr><td>通信方式</td><td>隔离 SPI 菊花链 → BMU</td></tr>' +
        '<tr><td>均衡电阻</td><td>12 × 33 Ω / 0.5 W</td></tr>',
      fire: '<tr><td>灭火介质</td><td>全氟己酮（Novec 1230）</td></tr>' +
        '<tr><td>罐体容积 / 压力</td><td>1.2<span class="u">L</span> · 1.2<span class="u">MPa</span></td></tr>' +
        '<tr><td>喷头数量</td><td>6 只雾化喷头</td></tr>' +
        '<tr><td>触发方式</td><td>热敏线 170 ℃ / BMS 指令</td></tr>' +
        '<tr><td>喷放时间</td><td>≤ 10<span class="u">s</span></td></tr>' +
        '<tr><td>当前状态</td><td>' + (sim.tmax > 60 ? '过温预警 · 待命' : '正常待命') + '</td></tr>',
      harn: '<tr><td>系统电压等级</td><td>600<span class="u">V</span> DC</td></tr>' +
        '<tr><td>母线电流</td><td>' + fmt(sim.Ipack, 1) + '<span class="u">A</span></td></tr>' +
        '<tr><td>主熔断器</td><td>500 A / 700 VDC</td></tr>',
      bms: '<tr><td>主控 / 从控</td><td>1 BMU + 6 CSC</td></tr>' +
        '<tr><td>绝缘电阻</td><td>' + fmt(sim.iso, 0) + '<span class="u">MΩ</span></td></tr>' +
        '<tr><td>高压继电器</td><td>主正 / 主负 / 预充 ×3</td></tr>' +
        '<tr><td>电流传感器</td><td>霍尔 ±600 A</td></tr>' +
        '<tr><td>预充回路</td><td>33 Ω / 50 W · 预充 500 ms</td></tr>' +
        '<tr><td>估算算法</td><td>EKF-SOC + 自适应 SOH/SOP</td></tr>' +
        '<tr><td>母线电压</td><td>' + fmt(sim.Vpack, 2) + '<span class="u">V</span></td></tr>',
      seal: '<tr><td>材料 / 截面</td><td>EPDM 发泡 · 12 × 9<span class="u">mm</span></td></tr>' +
        '<tr><td>布置形式</td><td>箱体法兰整周 + 四角硫化接角</td></tr>' +
        '<tr><td>压缩率</td><td>30<span class="u">%</span>（螺栓压紧后）</td></tr>' +
        '<tr><td>防护等级</td><td>IP68 / IP6K9K</td></tr>' +
        '<tr><td>工作温度</td><td>−40 ~ 120<span class="u">℃</span></td></tr>',
      cover: '<tr><td>板厚 / 密封等级</td><td>1.2 mm · IP68</td></tr>' +
        '<tr><td>防爆阀</td><td>1 处（右后）</td></tr>' +
        '<tr><td>低压接插件</td><td>1 组（左前）</td></tr>' +
        '<tr><td>压合对象</td><td>包外密封条（+9.75 u）</td></tr>',
    }[L.id] || '';
    host.innerHTML =
      '<div class="detail">' +
      '<div class="dh" style="background:linear-gradient(135deg,#1e293b,#475569)">' +
      '<div><div class="n" style="font-size:12.5px">' + L.name + '</div><div class="t">结构层 · 爆炸偏移 ' + L.explode.toFixed(2) + ' u</div></div>' +
      '<button class="x" id="dClose">×</button></div>' +
      '<div class="db"><table class="kv">' + extra + '</table>' +
      '<div class="hint" style="margin-top:9px">' + L.note + '</div></div></div>';
  }
  const b = $('dClose');
  if (b) b.onclick = function () { select(null); };
}

/* =========================================================================
   11. 视角
   ========================================================================= */
const VIEWS = {
  iso: [[21, 19, 26.5], [0, 2.9, 0]],
  front: [[0, 8.5, 38], [0, 2.8, 0]],
  top: [[0.01, 38, 0.02], [0, 1.4, 0]],
  side: [[38, 9.0, 0.02], [0, 2.8, 0]],
  cell: [[3.0, 3.0, 8.6], [4.6, 1.4, 0]],
  tray: [[-8.0, 5.0, 12.5], [-3.0, 0.8, 0]],
};
let camAnim = null;
function setView(v) {
  const V = VIEWS[v]; if (!V) return;
  camAnim = {
    t: 0, p0: camera.position.clone(), p1: new T.Vector3(V[0][0], V[0][1], V[0][2]),
    t0: controls.target.clone(), t1: new T.Vector3(V[1][0], V[1][1], V[1][2])
  };
}
function focusCell(c) {
  const wp = new T.Vector3();
  c.group.getWorldPosition(wp);
  camAnim = {
    t: 0, p0: camera.position.clone(),
    p1: new T.Vector3(wp.x + 4.2, wp.y + 3.4, wp.z + 5.4),
    t0: controls.target.clone(), t1: wp.clone()
  };
}

/* =========================================================================
   12. UI 绑定
   ========================================================================= */
function buildUI() {
  /* 工况 */
  $('modes').innerHTML = MODES.map(function (m) {
    return '<button class="mode' + (m.id === sim.mode ? ' on' : '') + '" data-mode="' + m.id + '">' + m.name + '</button>';
  }).join('');
  $('modes').addEventListener('click', function (e) {
    const b = e.target.closest('[data-mode]'); if (!b) return;
    sim.mode = b.dataset.mode;
    Array.prototype.forEach.call($('modes').children, function (c) { c.classList.toggle('on', c === b); });
    pushAlarm('i', '切换工况：' + b.textContent);
  });
  /* 时间倍率 */
  $('speedSeg').innerHTML = [1, 5, 20, 60].map(function (s) {
    return '<button data-sp="' + s + '"' + (s === sim.speed ? ' class="on"' : '') + '>' + s + '×</button>';
  }).join('');
  $('speedSeg').addEventListener('click', function (e) {
    const b = e.target.closest('[data-sp]'); if (!b) return;
    sim.speed = +b.dataset.sp;
    Array.prototype.forEach.call($('speedSeg').children, function (c) { c.classList.toggle('on', c === b); });
  });
  /* 播放 / 复位 */
  $('btnPlay').onclick = function () {
    sim.playing = !sim.playing;
    this.textContent = sim.playing ? '■ 暂停' : '▶ 运行';
  };
  $('btnReset').onclick = resetSim;
  /* 拆解滑块 */
  const ex = $('explode');
  ex.addEventListener('input', function () {
    ui.explode = +this.value / 100;
    $('vExplode').textContent = this.value + '%';
    this.style.setProperty('--p', this.value + '%');
    applyExplode();
  });
  ex.style.setProperty('--p', ex.value + '%');
  /* 图层列表 */
  $('layerList').innerHTML = LAYERS.map(function (l) {
    return '<div class="layer on" data-layer="' + l.id + '">' +
      '<span class="cb"><svg width="9" height="9" viewBox="0 0 10 10"><path d="M1.5 5.2l2.3 2.3L8.6 2.6" stroke="#fff" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></span>' +
      '<span class="sq" style="background:' + l.color + '"></span>' +
      '<span class="nm">' + l.name + '</span>' +
      '<span class="ct">+' + l.explode.toFixed(1) + '</span></div>';
  }).join('');
  $('vLayerCount').textContent = LAYERS.length + ' 层';
  $('layerList').addEventListener('click', function (e) {
    const row = e.target.closest('[data-layer]'); if (!row) return;
    const id = row.dataset.layer;
    if (e.target.closest('.cb')) {
      ui.visible[id] = !ui.visible[id];
      row.classList.toggle('on', ui.visible[id]);
      row.classList.toggle('dim', !ui.visible[id]);
      applyVisibility();
    } else {
      select({ type: 'layer', layer: id });
    }
  });
  /* 视角预设 */
  $('presets').addEventListener('click', function (e) {
    const b = e.target.closest('[data-view]'); if (!b) return;
    setView(b.dataset.view);
  });
  /* 着色模式 */
  $('colorModes').innerHTML = COLOR_MODES.map(function (c) {
    return '<button class="chip' + (c.id === colorMode ? ' on' : '') + '" data-cm="' + c.id + '">' + c.name + '</button>';
  }).join('');
  $('colorModes').addEventListener('click', function (e) {
    const b = e.target.closest('[data-cm]'); if (!b) return;
    colorMode = b.dataset.cm;
    Array.prototype.forEach.call($('colorModes').children, function (c) { c.classList.toggle('on', c === b); });
    renderLegend(); applyColors();
  });
  /* 显示开关 */
  function bindToggle(id, fn) {
    const el = $(id);
    el.addEventListener('click', function () {
      const on = !el.classList.contains('on');
      el.classList.toggle('on', on);
      fn(on);
    });
  }
  bindToggle('tgRotate', function (on) { ui.rotate = on; controls.autoRotate = on; });
  bindToggle('tgClip', function (on) { ui.clip = on; applyClip(); });
  bindToggle('tgGhost', function (on) { ui.ghost = on; applyGhost(); });
  bindToggle('tgLabels', function (on) { ui.labels = on; });
  bindToggle('tgIso', function (on) { toggleGhostIso(on); });
  /* 热管理边界条件 */
  const tc = $('tCool');
  tc.addEventListener('input', function () {
    CFG.TcoolIn = +this.value;
    $('vTcool').textContent = this.value + ' °C';
    this.style.setProperty('--p', ((this.value - 10) / 35 * 100) + '%');
  });
  tc.style.setProperty('--p', ((tc.value - 10) / 35 * 100) + '%');
  $('pumpSeg').addEventListener('click', function (e) {
    const b = e.target.closest('[data-pump]'); if (!b) return;
    sim.pump = +b.dataset.pump;
    Array.prototype.forEach.call($('pumpSeg').children, function (c) { c.classList.toggle('on', c === b); });
    pushAlarm('i', '冷却回路热容流率设为 ' + sim.pump + ' W/K');
  });
  const s0 = $('soc0');
  s0.addEventListener('input', function () {
    SOC0 = +this.value / 100;
    $('vSoc0').textContent = this.value + ' %';
    this.style.setProperty('--p', ((this.value - 10) / 85 * 100) + '%');
  });
  s0.style.setProperty('--p', ((s0.value - 10) / 85 * 100) + '%');
  /* 检测 */
  $('btnSweep').onclick = startSweep;
  $('btnClearAlarm').onclick = function () { alarms.length = 0; renderAlarms(); };
  $('sweepClose').onclick = function () { $('sweepModal').classList.remove('show'); };
  $('sweepModal').addEventListener('click', function (e) {
    if (e.target === this) this.classList.remove('show');
  });
  /* 键盘 */
  window.addEventListener('keydown', function (e) {
    if (e.code === 'Space') { e.preventDefault(); $('btnPlay').click(); }
    if (e.key === 'r' || e.key === 'R') setView('iso');
    if (e.key === 'Escape') select(null);
    if (e.key >= '1' && e.key <= '8') {
      const l = LAYERS[+e.key - 1];
      if (l) select({ type: 'layer', layer: l.id });
    }
  });
  $('ftRev').textContent = 'three.js r' + T.REVISION;
  $('ftModel').textContent = '模型：' + MODULES.length + ' 模组 / ' + sim.cells.length + ' 电芯 / ' + LAYERS.length + ' 结构层';
}

function resetSim() {
  sim.t = 0; sim.throughput = 0; sim.odo = 0;
  sim.cycDose = 0; sim.calDose = 0;
  sim.qLossCyc = 0; sim.qLossCal = CFG.qLossCal0; sim.qLoss = CFG.qLossCal0;
  sim.sohC = 1 - CFG.qLossCal0; sim.sohR = 1; sim.sohP = 1; sim.soh = sim.sohC;
  sim.iso = 620; sim.Vpack = 265; sim.Ipack = 0; sim.P = 0; sim.derate = 1;
  sim.coolOut = CFG.TcoolIn; sim.qnet = 0; sim.heat = 0;
  test.active = false; test.cell = null; test.result = null; test.phase = 0;
  sweep.active = false; sweep.results = []; sweep.i = 0;
  probe.visible = false;
  alarms.length = 0;
  /* 以确定性随机重新生成单体离散性与初始状态 */
  const r2 = mulberry32(20261006);
  function g2() {
    let u = 0, v = 0;
    while (u === 0) u = r2();
    while (v === 0) v = r2();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }
  sim.cells.forEach(function (c) {
    c.capFactor = 1 + g2() * 0.012;
    c.resFactor = 1 + g2() * 0.040;
    const spatial = (1 - c.mod.flow) * 0.012 - 0.004;
    c.soc = clamp(SOC0 + spatial + g2() * 0.006, 0.02, 1);
    c.T = 25 + (1 - c.mod.flow) * 1.2 + g2() * 0.35;
    c.throughAh = 0; c.Rmeas = null; c.flash = 0; c.ocvH = 0;
    c.computeR(); c.ocv = ocvOf(c.soc); c.V = c.ocv;
  });
  let so = 0, sr = 0;
  for (const c of sim.cells) { so += c.ocv; sr += c.R; }
  sim.ocvPack = so; sim.ocvAvg = so / CFG.series; sim.rPack = sr;
  updateExtremes();
  select(null);
  renderAlarms();
  updateDashboard();
  pushAlarm('i', '系统复位：初始 SOC ' + fmt(SOC0 * 100, 0) + '%，冷却液入口 ' + fmt(CFG.TcoolIn, 0) + ' ℃，泵热容流率 ' + sim.pump + ' W/K');
}

/* =========================================================================
   13. 尺寸 / 主循环
   ========================================================================= */
function resize() {
  const w = stage.clientWidth, h = stage.clientHeight;
  renderer.setSize(w, h, false);
  camera.aspect = w / Math.max(1, h);
  camera.updateProjectionMatrix();
  if (chart1) { chart1.resize(); chart1.draw(); }
  if (chart2) { chart2.resize(); chart2.draw(); }
}
window.addEventListener('resize', resize);

let lastT = performance.now(), acc = 0, uiAcc = 0, chartAcc = 0, frame = 0;
function loop(now) {
  requestAnimationFrame(loop);
  const rdt = Math.min(0.06, (now - lastT) / 1000);
  lastT = now;
  frame++;
  if (frame % 20 === 0) $('fps').textContent = (1 / Math.max(1e-3, rdt)).toFixed(0) + ' fps';

  /* 相机动画 */
  if (camAnim) {
    camAnim.t = Math.min(1, camAnim.t + rdt * 1.5);
    const e = camAnim.t < 0.5 ? 2 * camAnim.t * camAnim.t : -1 + (4 - 2 * camAnim.t) * camAnim.t;
    camera.position.lerpVectors(camAnim.p0, camAnim.p1, e);
    controls.target.lerpVectors(camAnim.t0, camAnim.t1, e);
    if (camAnim.t >= 1) camAnim = null;
  }

  /* 仿真推进（固定步长 100 ms 模拟时间） */
  if (sim.playing) {
    acc += rdt * sim.speed;
    let guard = 0;
    while (acc >= 0.1 && guard < 150) { stepSim(0.1); acc -= 0.1; guard++; }
    if (guard >= 150) acc = 0;
  }

  decayFlash();
  if (frame % 4 === 0) applyColors();
  updateProbe();
  updateLabels();
  controls.update();
  renderer.render(scene, camera);

  uiAcc += rdt;
  if (uiAcc > 0.1) { uiAcc = 0; updateDashboard(); if (test.active) renderDetail(); }
  chartAcc += rdt;
  if (chartAcc > 0.25) {
    chartAcc = 0;
    chart1.push([sim.Vpack, sim.Ipack, sim.ocvPack]);
    chart2.push([sim.tmax, sim.tavg, sim.socAvg * 100]);
    chart1.draw(); chart2.draw();
  }
}

/* =========================================================================
   14. 对外脚本接口（便于二次开发 / 自动化验收）
   ========================================================================= */
const API = {
  sim: sim, CFG: CFG, MODULES: MODULES, LAYERS: LAYERS, ui: ui,
  cells: function () { return sim.cells; },
  cell: function (id) { return sim.cells.find(function (c) { return c.id === id; }) || null; },
  select: function (sel) { select(sel); },
  selectCell: function (id) { const c = API.cell(id); if (c) select({ type: 'cell', cell: c }); return c; },
  selectModule: function (id) { if (sim.modules[id]) select({ type: 'module', module: id }); },
  selectLayer: function (id) { if (LAYERS.some(function (l) { return l.id === id; })) select({ type: 'layer', layer: id }); },
  test: function (id) { const c = API.cell(id); if (c) startTest(c); return c; },
  sweep: startSweep,
  setMode: function (m) { if (MODES.some(function (x) { return x.id === m; })) sim.mode = m; },
  setSpeed: function (s) { sim.speed = s; },
  setColorMode: function (m) { colorMode = m; renderLegend(); applyColors(); },
  setExplode: function (v) { ui.explode = clamp(v, 0, 1); applyExplode(); $('explode').value = Math.round(ui.explode * 100); $('vExplode').textContent = Math.round(ui.explode * 100) + '%'; },
  setLayerVisible: function (id, v) { ui.visible[id] = !!v; applyVisibility(); },
  setCoolant: function (t) { CFG.TcoolIn = t; },
  setPump: function (mCp) { sim.pump = mCp; },
  setSoc0: function (s) { SOC0 = clamp(s, 0.05, 1); },
  setView: setView,
  /* 直接把镜头对准世界坐标点（便于定位 / 复现任一实体视角） */
  focus: function (p, d) {
    const dist = d || 7;
    camAnim = null;
    controls.target.set(p[0], p[1], p[2]);
    camera.position.set(p[0] + dist * 0.60, p[1] + dist * 0.50, p[2] + dist * 0.76);
    camera.lookAt(controls.target);
  },
  reset: resetSim,
  layerY: function (id) { return layerGroups[id] ? layerGroups[id].position.y : null; },
  /* 确定性推进仿真（用于脚本化验证 / 批量仿真） */
  step: function (dt, n) {
    const d = dt || 0.1, k = n || 1;
    for (let i = 0; i < k; i++) stepSim(d);
    updateExtremes(); updateDashboard();
    chart1.push([sim.Vpack, sim.Ipack, sim.ocvPack]); chart2.push([sim.tmax, sim.tavg, sim.socAvg * 100]);
    chart1.draw(); chart2.draw();
  },
  stats: function () {
    const r = {
      t: sim.t, soc: sim.socAvg, vpack: sim.Vpack, ipack: sim.Ipack, power: sim.P,
      soh: sim.sohC, sohC: sim.sohC, sohR: sim.sohR, sohP: sim.sohP,
      qLossCyc: sim.qLossCyc, qLossCal: sim.qLossCal, qLoss: sim.qLoss,
      cycDose: sim.cycDose, calDose: sim.calDose,
      rulCyc: sim.rulCyc, rulKm: sim.rulKm, rulDays: sim.rulDays, rulLimit: sim.rulLimit,
      vnom: VNOM_PACK, vminPack: VMIN_PACK, vmaxPack: VMAX_PACK,
      ocv: sim.ocvPack, ocvAvg: sim.ocvAvg, rpack: sim.rPack,
      sop: sim.sop,
      vmax: sim.vmax, vmin: sim.vmin, dv: (sim.vmax - sim.vmin) * 1000,
      tmax: sim.tmax, tmin: sim.tmin, tavg: sim.tavg, dt: sim.tmax - sim.tmin,
      ravg: sim.ravg * 1000, heat: sim.heat, coolOut: sim.coolOut, iso: sim.iso,
      pd: sim.PlimitD, pc: sim.PlimitC, throughput: sim.throughput,
      energies: { nom: CFG.CapAh * CFG.series * CFG.Vnom / 1000 },
      test: test.result ? { cell: test.cell.id, phase: test.phase, R: test.result.Rm, model: test.result.Rmodel, err: test.result.err, dv: test.result.dv, di: test.result.di } : { phase: 0 },
      sweep: sweep.results.length, alarms: alarms.length,
    };
    return r;
  },
  pick: function (x, y) {
    const h = pickAt(x, y);
    if (!h) return null;
    const i = h.object.userData.pick;
    return i ? { type: i.type, cell: i.cell ? i.cell.id : null, module: i.module || null, layer: i.layer || null } : null;
  },
};
window.BatteryPack3D = API;

/* =========================================================================
   15. 启动
   ========================================================================= */
function boot() {
  resize();
  buildModel();
  chart1 = new Chart($('chart1'), [{ color: '#2563eb', label: 'V', dp: 1 }, { color: '#ef6a1e', label: 'A', dp: 0 }, { color: '#15803d', label: 'OCV', dp: 1 }], 200);
  chart2 = new Chart($('chart2'), [{ color: '#dc2626', label: 'Tmax', dp: 1 }, { color: '#6d28d9', label: 'Tavg', dp: 1 }, { color: '#15803d', label: 'SOC', dp: 0 }], 200);
  buildUI();
  applyExplode(); applyVisibility(); applyGhost(); applyClip();
  renderLegend(); applyColors(); renderAlarms(); renderDetail();
  /* 上电自检日志 */
  pushAlarm('i', '系统上电自检通过：72 只单体电压采集正常，绝缘电阻 612 MΩ，BMS 通信正常');
  pushAlarm('i', '冷却回路建压完成，热容流率 ' + sim.pump + ' W/K，入口温度 ' + fmt(CFG.TcoolIn, 0) + ' ℃');
  /* 预跑 3 s 仿真，使初始温度场与电压分布收敛 */
  for (let i = 0; i < 30; i++) stepSim(0.1);
  updateDashboard();
  chart1.push([sim.Vpack, sim.Ipack, sim.ocvPack]); chart2.push([sim.tmax, sim.tavg, sim.socAvg * 100]);
  chart1.draw(); chart2.draw();
  toggleGhostIso(false);
  loop(performance.now());
}
boot();

})();
