#!/usr/bin/env node
/* =========================================================================
   从 src/app.part1.js 派生出纯 Node 仿真内核 agh-bridge/sim-core.js
   —— 让 Agnes Harness 插件能直接 require 仿真引擎，无需启动浏览器。

   为什么用"派生"而不是复制一份：
     仿真逻辑只能有一份真相。src/app.part1.js 是真相，本脚本是它的投影。
     改了 part1 之后重跑本脚本即可，绝不手改 sim-core.js。

   用法: node tools/build-simcore.js
   ========================================================================= */
'use strict';
const fs = require('fs'), path = require('path');

const ROOT = path.resolve(__dirname, '..');
const SRC = path.join(ROOT, 'src', 'app.part1.js');
const OUT_DIR = path.join(ROOT, 'agh-bridge');
const OUT = path.join(OUT_DIR, 'sim-core.js');

let s = fs.readFileSync(SRC, 'utf8');
const orig = s;

/* ---------- 1. 剥离 IIFE 外壳 ----------
   注意：三片源码是拼接后由 part3 末尾统一闭合的，
   所以 part1 只有 IIFE 开头、没有结尾 —— 这里只删开头，绝不能按 lastIndexOf('})();') 切尾，
   否则会切到内部自执行块（如 CLTC）而丢掉后面上百行仿真代码。 */
const HEAD = '(function () {';
if (!s.includes(HEAD)) { console.error('[simcore] 未找到 IIFE 头: ' + HEAD); process.exit(2); }
s = s.replace(HEAD, '');
/* 仅在末行恰好是孤立的 IIFE 闭合时才切（防御未来结构变化） */
const lines0 = s.split('\n');
while (lines0.length && lines0[lines0.length - 1].trim() === '') lines0.pop();
if (lines0.length && /^\s*\}\)\(\);\s*$/.test(lines0[lines0.length - 1])) lines0.pop();
s = lines0.join('\n') + '\n';

/* ---------- 2. 剔除浏览器侧依赖 ---------- */
let nT = 0, nD = 0;
s = s.replace(/^[ \t]*const T = THREE;[ \t]*$/m, () => { nT++; return '/* [sim-core] three.js 引用已移除（本内核不参与渲染） */'; });
s = s.replace(/^[ \t]*const \$ = id => document\.getElementById\(id\);[ \t]*$/m,
  () => { nD++; return "const $ = () => null;   /* [sim-core] DOM stub：Node 环境无 document */"; });
if (nT === 0) console.warn('[simcore] 警告：未匹配到 const T = THREE; —— part1 结构可能变了');
if (nD === 0) console.warn('[simcore] 警告：未匹配到 $ 定义 —— part1 结构可能变了');

/* ---------- 3. Node 侧补充层（纯数值，不碰 DOM） ---------- */
const NODE_LAYER = `
/* =========================================================================
   [sim-core] Node 侧补充层 —— 由 tools/build-simcore.js 追加，请勿手改
   作用：补齐浏览器里由 UI 层承担的职责（复位、取值、批量推进、检测、扫描）
   ========================================================================= */

/* ---- 复位（等价于界面上的 resetSim，去掉全部 UI 调用） ---- */
function resetSim() {
  sim.t = 0; sim.throughput = 0; sim.odo = 0;
  sim.cycDose = 0; sim.calDose = 0;
  sim.qLossCyc = 0; sim.qLossCal = CFG.qLossCal0; sim.qLoss = CFG.qLossCal0;
  sim.sohC = 1 - CFG.qLossCal0; sim.sohR = 1; sim.sohP = 1; sim.soh = sim.sohC;
  sim.iso = 620; sim.Vpack = 265; sim.Ipack = 0; sim.P = 0; sim.derate = 1;
  sim.coolOut = CFG.TcoolIn; sim.qnet = 0; sim.heat = 0; sim.hA = CFG.hA;
  test.active = false; test.cell = null; test.result = null; test.phase = 0;
  sweep.active = false; sweep.results = []; sweep.i = 0;
  alarms.length = 0;
  const r2 = mulberry32(20261006);
  function g2() {
    let u = 0, v = 0;
    while (u === 0) u = r2();
    while (v === 0) v = r2();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }
  sim.cells.forEach(function (c) {
    c.capFactor = 1 + g2() * 0.012;
    c.resFactor = 1 + g2() * 0.040;
    const spatial = (1 - c.mod.flow) * 0.012 - 0.004;
    c.soc = clamp(SOC0 + spatial + g2() * 0.006, 0.02, 1);
    c.T = 25 + (1 - c.mod.flow) * 1.2 + g2() * 0.35;
    c.throughAh = 0; c.Rmeas = null; c.flash = 0; c.ocvH = 0;
    c.computeR(); c.ocv = ocvOf(c.soc); c.V = c.ocv;
  });
  let so = 0, sr = 0;
  for (const c of sim.cells) { so += c.ocv; sr += c.R; }
  sim.ocvPack = so; sim.ocvAvg = so / CFG.series; sim.rPack = sr;
  updateExtremes();
  return getStats();
}

/* ---- 取全量状态（等价于界面 API 的 stats()，去掉 DOM 项） ---- */
function getStats() {
  const r = {
    t: sim.t, soc: sim.socAvg, vpack: sim.Vpack, ipack: sim.Ipack, power: sim.P,
    soh: sim.sohC, sohC: sim.sohC, sohR: sim.sohR, sohP: sim.sohP,
    qLossCyc: sim.qLossCyc, qLossCal: sim.qLossCal, qLoss: sim.qLoss,
    cycDose: sim.cycDose, calDose: sim.calDose,
    rulCyc: sim.rulCyc, rulKm: sim.rulKm, rulDays: sim.rulDays, rulLimit: sim.rulLimit,
    vnom: VNOM_PACK, vminPack: VMIN_PACK, vmaxPack: VMAX_PACK,
    ocv: sim.ocvPack, ocvAvg: sim.ocvAvg, rpack: sim.rPack,
    sop: sim.sop,
    vmax: sim.vmax, vmin: sim.vmin, dv: (sim.vmax - sim.vmin) * 1000,
    tmax: sim.tmax, tmin: sim.tmin, tavg: sim.tavg, dt: sim.tmax - sim.tmin,
    ravg: sim.ravg * 1000, heat: sim.heat, coolOut: sim.coolOut, iso: sim.iso,
    pd: sim.PlimitD, pc: sim.PlimitC, throughput: sim.throughput,
    derate: sim.derate, mode: sim.mode, pump: sim.pump,
    energies: { nom: CFG.CapAh * CFG.series * CFG.Vnom / 1000 },
    test: test.result ? {
      cell: test.cell.id, phase: test.phase, R: test.result.Rm,
      model: test.result.Rmodel, err: test.result.err,
      dv: test.result.dv, di: test.result.di,
    } : { phase: 0 },
    sweep: sweep.results.length,
    alarms: alarms.slice(0, 12).map(a => ({ lvl: a.lvl, t: a.t, msg: a.msg })),
  };
  return r;
}

/* ---- 参数设定 ---- */
function setMode(id) {
  const m = MODES.find(x => x.id === id);
  if (!m) return { ok: false, err: '未知工况: ' + id, available: MODES.map(x => x.id) };
  sim.mode = id; return { ok: true, mode: id, name: m.name };
}
function setPump(v) { sim.pump = Math.max(0, +v || 0); return { ok: true, pump: sim.pump }; }
function setCoolant(v) { CFG.TcoolIn = +v; return { ok: true, TcoolIn: CFG.TcoolIn }; }

/* ---- 推进仿真（dt 默认 0.1 s，与前端主循环一致） ---- */
function runSteps(n, dt) {
  dt = dt || 0.1; n = Math.max(1, Math.min(200000, +n || 1));
  for (let i = 0; i < n; i++) stepSim(dt);
  return getStats();
}

/* ---- 单体定位 ---- */
function cellById(id) {
  return sim.cells.find(c => c.id === id) || null;
}
function cellInfo(c) {
  return {
    id: c.id, module: c.mod.id, row: c.row, col: c.col,
    V: c.V, ocv: c.ocv, soc: c.soc, T: c.T, R: c.R, Rmeas: c.Rmeas,
    heat: c.heat, throughAh: c.throughAh, capFactor: c.capFactor, resFactor: c.resFactor,
    neighbors: c.neighbors.length,
  };
}
function listCells(moduleId) {
  return sim.cells.filter(c => !moduleId || c.mod.id === moduleId).map(cellInfo);
}

/* ---- 单体内阻脉冲辨识（同步推进到出结果） ---- */
function runTest(cellId) {
  const c = cellById(cellId);
  if (!c) return { ok: false, err: '未找到电芯: ' + cellId };
  startTest(c);
  for (let i = 0; i < 60 && test.phase < 3; i++) stepSim(0.1);
  if (!test.result) return { ok: false, err: '辨识未完成（phase=' + test.phase + '）' };
  return {
    ok: true, cell: cellId,
    Rmeas_mOhm: +(test.result.Rm * 1000).toFixed(4),
    Rmodel_mOhm: +(test.result.Rmodel * 1000).toFixed(4),
    err_pct: +test.result.err.toFixed(2),
    dV_mV: +(test.result.dv * 1000).toFixed(3),
    dI_A: +test.result.di.toFixed(2),
  };
}

/* ---- 全芯内阻扫描（同步跑完 72 只） ---- */
function runSweep() {
  startSweep();
  for (let i = 0; i < 4000 && sweep.active; i++) stepSim(0.1);
  const rs = sweep.results.map(r => r.R);
  if (!rs.length) return { ok: false, err: '扫描未产出结果' };
  const mean = rs.reduce((a, b) => a + b, 0) / rs.length;
  const sd = Math.sqrt(rs.reduce((a, b) => a + (b - mean) * (b - mean), 0) / rs.length);
  const sorted = rs.slice().sort((a, b) => a - b);
  const out3 = sweep.results
    .map(r => ({ id: r.cell.id, R: r.R }))
    .filter(r => Math.abs(r.R - mean) > 3 * sd);
  return {
    ok: true, count: rs.length,
    mean_mOhm: +(mean * 1000).toFixed(4),
    sd_mOhm: +(sd * 1000).toFixed(4),
    cv_pct: +(sd / mean * 100).toFixed(2),
    min_mOhm: +(sorted[0] * 1000).toFixed(4),
    max_mOhm: +(sorted[sorted.length - 1] * 1000).toFixed(4),
    range_mOhm: +((sorted[sorted.length - 1] - sorted[0]) * 1000).toFixed(4),
    outliers_3sigma: out3,
    grade: (sd / mean) < 0.02 ? '优' : ((sd / mean) < 0.04 ? '良' : '关注'),
  };
}

/* ---- 自检：断言内部恒等式，确认内核自洽 ---- */
function selfCheck() {
  const out = [];
  resetSim();
  runSteps(5, 0.1);
  let s1 = getStats();
  out.push({ name: 'Vnom', got: +s1.vnom.toFixed(1), want: 266.4, pass: Math.abs(s1.vnom - 266.4) < 0.05 });
  const r1 = Math.abs(s1.vpack - (s1.ocv - s1.ipack * s1.rpack));
  out.push({ name: '静置电压恒等式残差', got: r1.toExponential(2), want: '<1e-9', pass: r1 < 1e-9 });
  setMode('high'); runSteps(300, 0.1);
  let s2 = getStats();
  const r2 = Math.abs(s2.vpack - (s2.ocv - s2.ipack * s2.rpack));
  out.push({ name: '负载电压恒等式残差', got: r2.toExponential(2), want: '<1e-9', pass: r2 < 1e-9 });
  out.push({ name: '电芯数量', got: sim.cells.length, want: 72, pass: sim.cells.length === 72 });
  out.push({ name: '结构层数', got: LAYERS.length, want: 12, pass: LAYERS.length === 12 });
  const q1000 = CFG.kCyc * Math.pow(1000, CFG.zCyc) * 100;
  out.push({ name: '1000 循环衰减 %', got: +q1000.toFixed(1), want: '≈20.1', pass: Math.abs(q1000 - 20.1) < 0.5 });
  const pass = out.every(o => o.pass);
  return { pass: pass, checks: out };
}

/* ---------- 模块加载即初始化 ----------
   浏览器端这一步由 part3 的 boot() 承担；Node 侧没有 boot，必须自己建。 */
buildCells();
resetSim();

/* ---------- 导出 ---------- */
module.exports = {
  CFG, LAYERS, COLOR_MODES, MODES, MODULES, sim, Cell,
  VNOM_PACK, VMAX_PACK, VMIN_PACK,
  ocvOf, buildCells, stepSim, updateExtremes, computeLimits,
  resetSim, getStats, setMode, setPump, setCoolant, runSteps,
  cellById, cellInfo, listCells, runTest, runSweep, selfCheck,
  alarms, test, sweep,
};

/* 允许直接执行做自检: node agh-bridge/sim-core.js */
if (require.main === module) {
  const r = selfCheck();
  console.log('\\n[sim-core] 自检\\n');
  for (const c of r.checks) {
    console.log('  ' + (c.pass ? '[OK]  ' : '[FAIL]') + ' ' + String(c.name).padEnd(22) + ' 实测=' + c.got + '  期望=' + c.want);
  }
  console.log('\\n  结论: ' + (r.pass ? 'PASS —— 内核与浏览器端一致' : 'FAIL —— 内核与 part1 不同步，重跑 build-simcore.js 或检查 part1'));
  process.exit(r.pass ? 0 : 1);
}
`;

const HEADER = `/* =========================================================================
   sim-core.js —— 动力电池包电热仿真内核（纯 Node，无 three.js / 无 DOM）
   ⚠ 本文件由 tools/build-simcore.js 从 src/app.part1.js 自动派生，请勿手改。
     改仿真逻辑请改 src/app.part1.js，然后执行: node tools/build-simcore.js
   派生时间: ${new Date().toISOString()}
   ========================================================================= */
'use strict';

`;

fs.mkdirSync(OUT_DIR, { recursive: true });
fs.writeFileSync(OUT, HEADER + s + NODE_LAYER, 'utf8');

const lines = (HEADER + s + NODE_LAYER).split('\n').length;
console.log('[simcore] 已生成 ' + path.relative(ROOT, OUT));
console.log('[simcore] 源 part1 = ' + orig.split('\n').length + ' 行 → 内核 = ' + lines + ' 行');
console.log('[simcore] 已剔除: three.js 引用 ×' + nT + ', DOM 依赖 ×' + nD);
console.log('[simcore] 自检: node agh-bridge/sim-core.js');
