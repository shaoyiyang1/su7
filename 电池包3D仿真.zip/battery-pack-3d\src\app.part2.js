/* =========================================================================
   Part 2 —— three.js 场景、PBR 材质与电池包分层建模
   ========================================================================= */

/* ---------- 渲染器 / 场景 / 相机 ---------- */
const canvas = $('gl');
const stage = $('stage');
const renderer = new T.WebGLRenderer({ canvas: canvas, antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = T.PCFSoftShadowMap;
renderer.toneMapping = T.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.03;
renderer.outputColorSpace = T.SRGBColorSpace;

const scene = new T.Scene();
const camera = new T.PerspectiveCamera(38, 1, 0.5, 400);
camera.position.set(21, 19, 26.5);

const controls = new T.OrbitControls(camera, renderer.domElement);
controls.enableDamping = true; controls.dampingFactor = 0.075;
controls.minDistance = 7; controls.maxDistance = 85;
controls.maxPolarAngle = 1.545;
controls.target.set(0, 2.9, 0);
controls.autoRotate = true; controls.autoRotateSpeed = 0.55;

/* ---------- 程序化摄影棚环境贴图（离线可用，金属反射的关键） ---------- */
function envTexture() {
  const cv = document.createElement('canvas'); cv.width = 1024; cv.height = 512;
  const g = cv.getContext('2d');
  const grd = g.createLinearGradient(0, 0, 0, 512);
  grd.addColorStop(0, '#ffffff'); grd.addColorStop(.42, '#e6ecf5');
  grd.addColorStop(.5, '#cfd8e5'); grd.addColorStop(1, '#8e9aab');
  g.fillStyle = grd; g.fillRect(0, 0, 1024, 512);
  g.fillStyle = 'rgba(255,255,255,1)'; g.fillRect(90, 30, 240, 170); g.fillRect(610, 50, 200, 150);
  g.fillStyle = 'rgba(255,255,255,.55)'; g.fillRect(380, 16, 150, 90); g.fillRect(860, 26, 120, 120);
  g.fillStyle = 'rgba(178,194,214,.5)'; g.fillRect(0, 400, 1024, 112);
  const tex = new T.CanvasTexture(cv);
  tex.mapping = T.EquirectangularReflectionMapping;
  tex.colorSpace = T.SRGBColorSpace;
  return tex;
}
const pmrem = new T.PMREMGenerator(renderer);
scene.environment = pmrem.fromEquirectangular(envTexture()).texture;
pmrem.dispose();

/* ---------- 灯光 ---------- */
scene.add(new T.HemisphereLight(0xffffff, 0xb9c4d4, 1.05));
const keyLight = new T.DirectionalLight(0xffffff, 2.1);
keyLight.position.set(14, 24, 12); keyLight.castShadow = true;
keyLight.shadow.mapSize.set(2048, 2048);
keyLight.shadow.camera.near = 4; keyLight.shadow.camera.far = 90;
keyLight.shadow.camera.left = -20; keyLight.shadow.camera.right = 20;
keyLight.shadow.camera.top = 20; keyLight.shadow.camera.bottom = -20;
keyLight.shadow.bias = -0.0008; keyLight.shadow.normalBias = 0.02;
scene.add(keyLight);
const fillLight = new T.DirectionalLight(0xdfe8f5, 0.75); fillLight.position.set(-16, 9, -14); scene.add(fillLight);
const rimLight = new T.DirectionalLight(0xffffff, 0.55); rimLight.position.set(0, -6, -18); scene.add(rimLight);

/* ---------- 接地软阴影 ---------- */
(function ground() {
  const cv = document.createElement('canvas'); cv.width = cv.height = 512;
  const g = cv.getContext('2d');
  const rg = g.createRadialGradient(256, 256, 8, 256, 256, 250);
  rg.addColorStop(0, 'rgba(23,35,56,.40)'); rg.addColorStop(.5, 'rgba(23,35,56,.13)');
  rg.addColorStop(1, 'rgba(23,35,56,0)');
  g.fillStyle = rg; g.fillRect(0, 0, 512, 512);
  const tex = new T.CanvasTexture(cv); tex.colorSpace = T.SRGBColorSpace;
  const m = new T.Mesh(new T.PlaneGeometry(46, 46), new T.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false }));
  m.rotation.x = -Math.PI / 2; m.position.y = -1.62; m.renderOrder = -2;
  scene.add(m);
  const sp = new T.Mesh(new T.PlaneGeometry(64, 64), new T.ShadowMaterial({ opacity: 0.15 }));
  sp.rotation.x = -Math.PI / 2; sp.position.y = -1.58; sp.receiveShadow = true;
  scene.add(sp);
})();

/* ---------- 程序化纹理 ---------- */
function ribTexture() {
  const cv = document.createElement('canvas'); cv.width = cv.height = 256;
  const g = cv.getContext('2d');
  g.fillStyle = '#e9edf3'; g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 8; i++) { g.fillStyle = i % 2 ? '#dbe2ec' : '#e4e9f1'; g.fillRect(0, i * 32, 256, 16); }
  for (let i = 0; i < 256; i += 32) { g.fillStyle = 'rgba(150,163,180,.35)'; g.fillRect(0, i, 256, 1.5); }
  const tex = new T.CanvasTexture(cv);
  tex.wrapS = tex.wrapT = T.RepeatWrapping; tex.repeat.set(6, 4);
  tex.anisotropy = 8; tex.colorSpace = T.SRGBColorSpace;
  return tex;
}
function plateTexture() {
  const cv = document.createElement('canvas'); cv.width = cv.height = 128;
  const g = cv.getContext('2d');
  g.fillStyle = '#ccd3dd'; g.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 900; i++) {
    const x = rnd() * 128, y = rnd() * 128, a = rnd() * 0.10;
    g.fillStyle = 'rgba(' + (rnd() > .5 ? 255 : 90) + ',' + (rnd() > .5 ? 255 : 100) + ',255,' + a.toFixed(3) + ')';
    g.fillRect(x, y, 1.4, 1.4);
  }
  const tex = new T.CanvasTexture(cv);
  tex.wrapS = tex.wrapT = T.RepeatWrapping; tex.repeat.set(10, 8);
  tex.colorSpace = T.SRGBColorSpace;
  return tex;
}

/* ---------- 材质库 ---------- */
const MAT = {
  alu: new T.MeshStandardMaterial({ color: 0xc3cad5, metalness: 0.96, roughness: 0.30, envMapIntensity: 1.1 }),
  aluDark: new T.MeshStandardMaterial({ color: 0x9aa3b1, metalness: 0.92, roughness: 0.42, envMapIntensity: 0.95 }),
  aluBright: new T.MeshStandardMaterial({ color: 0xd7dde6, metalness: 0.98, roughness: 0.16, envMapIntensity: 1.35 }),
  trayPlate: new T.MeshStandardMaterial({ map: plateTexture(), color: 0xb9c2ce, metalness: 0.88, roughness: 0.50, envMapIntensity: 0.8 }),
  cooling: new T.MeshStandardMaterial({ color: 0xb9c6d8, metalness: 0.98, roughness: 0.20, envMapIntensity: 1.4 }),
  channel: new T.MeshStandardMaterial({ color: 0x8fa3bd, metalness: 0.95, roughness: 0.32, envMapIntensity: 1.1 }),
  cellBody: new T.MeshStandardMaterial({ color: 0xa8b2c1, metalness: 0.94, roughness: 0.26, envMapIntensity: 1.25 }),
  cap: new T.MeshStandardMaterial({ color: 0xef6a1e, metalness: 0.5, roughness: 0.42, envMapIntensity: 0.9 }),
  terminal: new T.MeshStandardMaterial({ color: 0xd8dee7, metalness: 1.0, roughness: 0.18, envMapIntensity: 1.4 }),
  busbar: new T.MeshStandardMaterial({ color: 0xef6a1e, metalness: 0.62, roughness: 0.36, envMapIntensity: 0.95 }),
  pcb: new T.MeshStandardMaterial({ color: 0x2b3138, metalness: 0.35, roughness: 0.62 }),
  plastic: new T.MeshStandardMaterial({ color: 0x1f242c, metalness: 0.20, roughness: 0.72 }),
  wire: new T.MeshStandardMaterial({ color: 0x2a2f37, metalness: 0.25, roughness: 0.75 }),
  wireOrange: new T.MeshStandardMaterial({ color: 0xef6a1e, metalness: 0.30, roughness: 0.55 }),
  cover: new T.MeshStandardMaterial({ color: 0xcbd2dc, metalness: 0.97, roughness: 0.17, envMapIntensity: 1.45 }),
  bolt: new T.MeshStandardMaterial({ color: 0x8d97a5, metalness: 1.0, roughness: 0.28 }),
  probe: new T.MeshStandardMaterial({ color: 0x2563eb, metalness: 0.6, roughness: 0.30, emissive: 0x1d4ed8, emissiveIntensity: 0.7 }),

  /* ---- 新增实体：灭火装置 / 密封条 / 采集单元 / 电芯细节 ---- */
  fire: new T.MeshStandardMaterial({ color: 0xdc2626, metalness: 0.55, roughness: 0.34, envMapIntensity: 1.05 }),
  fireCap: new T.MeshStandardMaterial({ color: 0x7f1d1d, metalness: 0.80, roughness: 0.28 }),
  firePipe: new T.MeshStandardMaterial({ color: 0xb6bec9, metalness: 0.96, roughness: 0.20, envMapIntensity: 1.30 }),
  nozzle: new T.MeshStandardMaterial({ color: 0x8a929d, metalness: 0.92, roughness: 0.30 }),
  fireWire: new T.MeshStandardMaterial({ color: 0xf97316, metalness: 0.30, roughness: 0.55 }),
  seal: new T.MeshStandardMaterial({ color: 0x2b3038, metalness: 0.04, roughness: 0.93 }),
  sealRib: new T.MeshStandardMaterial({ color: 0x3a4048, metalness: 0.04, roughness: 0.95 }),
  ntc: new T.MeshStandardMaterial({ color: 0x111827, metalness: 0.12, roughness: 0.86 }),
  ntcLead: new T.MeshStandardMaterial({ color: 0x1d4ed8, metalness: 0.28, roughness: 0.62 }),
  nickel: new T.MeshStandardMaterial({ color: 0xc9ced6, metalness: 0.95, roughness: 0.26, envMapIntensity: 1.15 }),
  film: new T.MeshStandardMaterial({ color: 0x1e3a8a, metalness: 0.30, roughness: 0.50 }),
  pad: new T.MeshStandardMaterial({ color: 0x22262c, metalness: 0.08, roughness: 0.92 }),
  fuse: new T.MeshStandardMaterial({ color: 0xd6b171, metalness: 0.88, roughness: 0.30 }),
  ceramic: new T.MeshStandardMaterial({ color: 0xdbd5c7, metalness: 0.10, roughness: 0.75 }),
  hall: new T.MeshStandardMaterial({ color: 0x3f4650, metalness: 0.55, roughness: 0.48 }),
  imc: new T.MeshStandardMaterial({ color: 0x374151, metalness: 0.30, roughness: 0.60 }),
  conn: new T.MeshStandardMaterial({ color: 0xcbd5e1, metalness: 0.35, roughness: 0.55 }),
};
const GHOST_MATS = [MAT.alu, MAT.aluDark, MAT.aluBright, MAT.trayPlate, MAT.cooling, MAT.channel, MAT.cover, MAT.pcb,
  MAT.seal, MAT.sealRib, MAT.fire, MAT.firePipe, MAT.nozzle, MAT.pad];

/* 电芯个体：程序化条码/二维码标签贴图（全场共享一张，不额外占显存） */
function labelTexture() {
  /* 独立的确定性随机源，避免扰动电芯离散性的主随机序列 */
  const lr = mulberry32(778211);
  const cv = document.createElement('canvas'); cv.width = 256; cv.height = 160;
  const g = cv.getContext('2d');
  g.fillStyle = '#f4f7fb'; g.fillRect(0, 0, 256, 160);
  g.fillStyle = '#0f172a';
  let x = 14;
  while (x < 150) {
    const w = 1 + Math.floor(lr() * 4);
    g.fillRect(x, 22, w, 62); x += w + 1 + Math.floor(lr() * 3);
  }
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) {
      if (lr() > 0.45) g.fillRect(168 + i * 20, 22 + j * 20, 20, 20);
    }
  }
  g.fillStyle = '#334155'; g.font = 'bold 20px monospace'; g.fillText('Li-ion NCM 320Ah', 14, 115);
  g.font = '16px monospace'; g.fillText('3.70V  5.4kg  UN38.3', 14, 140);
  const tex = new T.CanvasTexture(cv);
  tex.colorSpace = T.SRGBColorSpace; tex.anisotropy = 4;
  return tex;
}
MAT.label = new T.MeshStandardMaterial({ map: labelTexture(), color: 0xffffff, metalness: 0.05, roughness: 0.82 });

/* ---------- 建模工具 ---------- */
const root = new T.Group(); scene.add(root);
const layerGroups = {};
const pickables = [];
const cellMeshes = [];
function tag(obj, info) { obj.userData.pick = info; pickables.push(obj); return obj; }
function box(w, h, d, mat, x, y, z, parent, info) {
  const m = new T.Mesh(new T.BoxGeometry(w, h, d), mat);
  m.position.set(x, y, z); m.castShadow = true; m.receiveShadow = true;
  if (parent) parent.add(m);
  if (info) tag(m, info);
  return m;
}

/* =========================================================================
   4. 结构建模（12 层）
   ========================================================================= */

/* --- 4.1 下箱体 / 托盘 --- */
function buildTray() {
  const G = new T.Group(); root.add(G); layerGroups.tray = G;
  const info = { type: 'layer', layer: 'tray' };
  box(PACK_HX * 1.97, 0.10, PACK_HZ * 1.97, MAT.trayPlate, 0, 0.05, 0, G, info);
  /* 底部加强筋 */
  for (let i = -4; i <= 4; i++) box(PACK_HX * 1.88, 0.05, 0.10, MAT.aluDark, 0, 0.005, i * 1.15, G, info);
  for (let i = -3; i <= 3; i++) box(0.09, 0.045, PACK_HZ * 1.72, MAT.aluDark, i * 2.2, 0.005, 0, G, info);
  /* 四面边梁（上沿与盖板下沿齐平 y=2.36） */
  const wallH = 2.26, wy = 0.10 + wallH / 2;
  box(PACK_HX * 2, wallH, 0.22, MAT.alu, 0, wy, -PACK_HZ + 0.11, G, info);
  box(PACK_HX * 2, wallH, 0.22, MAT.alu, 0, wy, PACK_HZ - 0.11, G, info);
  box(0.22, wallH, PACK_HZ * 2 - 0.44, MAT.alu, -PACK_HX + 0.11, wy, 0, G, info);
  box(0.22, wallH, PACK_HZ * 2 - 0.44, MAT.alu, PACK_HX - 0.11, wy, 0, G, info);
  /* 外侧加强筋 */
  for (let i = -5; i <= 5; i++) {
    box(0.12, 1.85, 0.10, MAT.aluDark, i * 1.25, 1.10, -PACK_HZ - 0.02, G, info);
    box(0.12, 1.85, 0.10, MAT.aluDark, i * 1.25, 1.10, PACK_HZ + 0.02, G, info);
  }
  for (let i = -4; i <= 4; i++) {
    box(0.10, 1.85, 0.12, MAT.aluDark, -PACK_HX - 0.02, 1.10, i * 1.25, G, info);
    box(0.10, 1.85, 0.12, MAT.aluDark, PACK_HX + 0.02, 1.10, i * 1.25, G, info);
  }
  /* 12 处悬置安装凸台 */
  const bossGeo = new T.CylinderGeometry(0.22, 0.26, 0.26, 16);
  for (let i = -2; i <= 2; i++) {
    for (const zz of [-1, 1]) {
      const b = new T.Mesh(bossGeo, MAT.alu);
      b.position.set(i * 3.4, 1.40, zz * (PACK_HZ + 0.05));
      b.castShadow = true; G.add(b); tag(b, info);
    }
  }
  /* 前端高压接插件座 */
  box(0.9, 0.55, 0.34, MAT.plastic, -3.2, 1.70, -PACK_HZ - 0.06, G, info);
  box(0.9, 0.55, 0.34, MAT.plastic, -1.9, 1.70, -PACK_HZ - 0.06, G, info);
  return G;
}

/* --- 4.2 液冷板 --- */
function buildCooling() {
  const G = new T.Group(); root.add(G); layerGroups.cool = G;
  const info = { type: 'layer', layer: 'cool' };
  const yb = 0.10, th = 0.12;
  box(PACK_HX * 1.94, th, PACK_HZ * 1.90, MAT.cooling, 0, yb + th / 2, 0, G, info);
  /* 蛇形流道 */
  const pts = [], lanes = 5, spanX = PACK_HX * 1.72, laneZ = PACK_HZ * 1.64 / lanes;
  for (let i = 0; i <= lanes; i++) {
    const z = -PACK_HZ * 0.82 + i * laneZ;
    const dir = i % 2 === 0 ? 1 : -1;
    pts.push(new T.Vector3(-spanX * dir, yb + th + 0.010, z));
    pts.push(new T.Vector3(spanX * dir, yb + th + 0.010, z));
    if (i < lanes) pts.push(new T.Vector3(spanX * dir, yb + th + 0.010, z + laneZ / 2));
  }
  const curve = new T.CatmullRomCurve3(pts, false, 'catmullrom', 0.05);
  const tube = new T.Mesh(new T.TubeGeometry(curve, 460, 0.075, 8, false), MAT.channel);
  tube.castShadow = true; G.add(tube); tag(tube, info);
  const tube2 = new T.Mesh(new T.TubeGeometry(curve, 460, 0.045, 8, false), MAT.aluBright);
  tube2.position.y = 0.024; G.add(tube2); tag(tube2, info);
  /* 进出水管与快插 */
  const pipeGeo = new T.CylinderGeometry(0.13, 0.13, 1.5, 14);
  const p1 = new T.Mesh(pipeGeo, MAT.aluBright); p1.rotation.z = Math.PI / 2;
  p1.position.set(-PACK_HX * 0.98, yb + th / 2, -PACK_HZ * 0.72); p1.castShadow = true; G.add(p1); tag(p1, info);
  const p2 = p1.clone(); p2.position.z = PACK_HZ * 0.72; G.add(p2); tag(p2, info);
  const p3 = new T.Mesh(new T.CylinderGeometry(0.13, 0.13, 1.4, 14), MAT.aluBright);
  p3.rotation.x = Math.PI / 2; p3.position.set(-PACK_HX * 0.62, yb + th / 2, -PACK_HZ * 0.72);
  p3.castShadow = true; G.add(p3); tag(p3, info);
  const p4 = p3.clone(); p4.position.z = PACK_HZ * 0.72; G.add(p4); tag(p4, info);
  box(0.5, 0.30, 0.42, MAT.plastic, -PACK_HX * 0.62, yb + th / 2 + 0.08, -PACK_HZ * 0.95, G, info);
  return G;
}

/* --- 4.3 模组（12 只电芯 + 铝制框架） --- */
function buildModule(mod) {
  const G = new T.Group(); root.add(G);
  const by = DECK_Y[mod.deck];
  G.position.set(mod.x, 0, mod.z);
  const minfo = { type: 'module', module: mod.id };
  box(MOD_BLOCK_X + 0.34, 0.075, MOD_BLOCK_Z + 0.34, MAT.alu, 0, by - 0.055, 0, G, minfo);
  box(MOD_BLOCK_X + 0.30, 0.72, 0.16, MAT.aluDark, 0, by + 0.36, MOD_BLOCK_Z / 2 + 0.14, G, minfo);
  box(MOD_BLOCK_X + 0.30, 0.72, 0.16, MAT.aluDark, 0, by + 0.36, -MOD_BLOCK_Z / 2 - 0.14, G, minfo);
  box(0.13, 0.62, MOD_BLOCK_Z + 0.30, MAT.aluDark, MOD_BLOCK_X / 2 + 0.12, by + 0.32, 0, G, minfo);
  box(0.13, 0.62, MOD_BLOCK_Z + 0.30, MAT.aluDark, -MOD_BLOCK_X / 2 - 0.12, by + 0.32, 0, G, minfo);
  for (const zz of [-1, 1]) {
    const t = new T.Mesh(new T.CylinderGeometry(0.035, 0.035, MOD_BLOCK_X + 0.5, 10), MAT.bolt);
    t.rotation.z = Math.PI / 2; t.position.set(0, by + 0.74, zz * (MOD_BLOCK_Z / 2 + 0.14));
    t.castShadow = true; G.add(t); tag(t, minfo);
  }
  box(0.42, 0.16, 0.50, MAT.plastic, MOD_BLOCK_X / 2 + 0.30, by + 0.68, -MOD_BLOCK_Z / 2 + 0.30, G, minfo);

  mod.group = G;
  mod.cellGroup = new T.Group(); G.add(mod.cellGroup);

  const cw = CFG.cellW, ch = CFG.cellH, cd = CFG.cellD;
  mod.cells.forEach(function (cell) {
    const cx = (cell.col - (CFG.modCols - 1) / 2) * (cw + CFG.gapX);
    const cz = (cell.row - (CFG.modRows - 1) / 2) * (cd + CFG.gapZ);
    const CG = new T.Group();
    CG.position.set(cx, by + ch / 2, cz);
    const info = { type: 'cell', cell: cell, module: mod.id };
    const bodyMat = MAT.cellBody.clone(), capMat = MAT.cap.clone();
    const filmMat = MAT.film.clone();
    cell.bodyMat = bodyMat; cell.capMat = capMat; cell.filmMat = filmMat;
    const body = new T.Mesh(new T.BoxGeometry(cw - 0.05, ch - 0.04, cd - 0.05), bodyMat);
    body.castShadow = true; body.receiveShadow = true; CG.add(body); tag(body, info); cellMeshes.push(body);
    /* 侧面 PET 绝缘蓝膜（随状态色着色，保证热力图可读） */
    for (const s of [-1, 1]) {
      const fl = new T.Mesh(new T.BoxGeometry(0.014, ch - 0.16, cd - 0.10), filmMat);
      fl.position.set(s * (cw / 2 - 0.028), -0.02, 0); CG.add(fl); tag(fl, info);
    }
    /* 底部绝缘垫片 + 顶盖绝缘垫圈 */
    const pad = new T.Mesh(new T.BoxGeometry(cw - 0.09, 0.040, cd - 0.09), MAT.pad);
    pad.position.y = -ch / 2 - 0.018; pad.receiveShadow = true; CG.add(pad); tag(pad, info);
    const cap = new T.Mesh(new T.BoxGeometry(cw - 0.015, 0.055, cd - 0.015), capMat);
    cap.position.y = ch / 2 - 0.012; cap.castShadow = true; CG.add(cap); tag(cap, info); cellMeshes.push(cap);
    /* 极柱：铝极柱座 + 极柱本体（正负极各 1） */
    for (const s of [-1, 1]) {
      const bs = new T.Mesh(new T.BoxGeometry(0.26, 0.022, 0.26), MAT.aluDark);
      bs.position.set(s * 0.42, ch / 2 + 0.030, 0); CG.add(bs); tag(bs, info);
      const tm = new T.Mesh(new T.CylinderGeometry(0.055, 0.055, 0.058, 12), MAT.terminal);
      tm.position.set(s * 0.42, ch / 2 + 0.068, 0); CG.add(tm); tag(tm, info);
      const nt = new T.Mesh(new T.CylinderGeometry(0.030, 0.030, 0.030, 6), s < 0 ? MAT.nickel : MAT.busbar);
      nt.position.set(s * 0.42, ch / 2 + 0.108, 0); CG.add(nt); tag(nt, info);
    }
    /* 防爆阀（刻痕泄压片） */
    const vv = new T.Mesh(new T.CylinderGeometry(0.055, 0.055, 0.028, 12), MAT.aluDark);
    vv.position.set(0, ch / 2 + 0.046, 0.30); CG.add(vv); tag(vv, info);
    const vr = new T.Mesh(new T.TorusGeometry(0.062, 0.010, 6, 16), MAT.terminal);
    vr.rotation.x = Math.PI / 2; vr.position.set(0, ch / 2 + 0.050, 0.30); CG.add(vr); tag(vr, info);
    /* 个体身份标签（条码 + 二维码） */
    const lb = new T.Mesh(new T.PlaneGeometry(0.62, 0.40), MAT.label);
    lb.position.set(0, -0.05, cd / 2 - 0.018); CG.add(lb); tag(lb, info);
    cell.group = CG; cell.baseY = CG.position.y;
    mod.cellGroup.add(CG);
  });
  return G;
}

/* --- 4.4 模组汇流采样层 --- */
function busbarLayer(deck, by, info) {
  const G = new T.Group(); root.add(G);
  MODULES.filter(m => m.deck === deck).forEach(function (m) {
    for (const s of [-1, 1]) {
      box(0.16, 0.055, MOD_BLOCK_Z * 0.92, MAT.busbar, m.x + s * (MOD_BLOCK_X / 2 + 0.10), by, m.z, G, info);
    }
    box(MOD_BLOCK_X * 0.96, 0.05, 0.15, MAT.busbar, m.x, by, m.z + MOD_BLOCK_Z / 2 + 0.12, G, info);
    const pts = [];
    for (let i = 0; i <= 6; i++) {
      pts.push(new T.Vector3(m.x - MOD_BLOCK_X / 2 + i * (MOD_BLOCK_X / 6), by + 0.07 + Math.sin(i) * 0.02, m.z + MOD_BLOCK_Z / 2 + 0.16));
    }
    const cv = new T.CatmullRomCurve3(pts);
    const w = new T.Mesh(new T.TubeGeometry(cv, 40, 0.017, 6, false), MAT.wire);
    w.castShadow = true; G.add(w); tag(w, info);
    box(0.30, 0.14, 0.20, MAT.plastic, m.x + MOD_BLOCK_X * 0.18, by + 0.08, m.z + MOD_BLOCK_Z / 2 + 0.20, G, info);
  });
  return G;
}

/* --- 4.5 层间汇流采样板（透空走线槽结构，保持模组可视） --- */
function buildInterconnect() {
  const G = new T.Group(); root.add(G); layerGroups.inter = G;
  const info = { type: 'layer', layer: 'inter' };
  /* 纵向走线槽（模组行列之间的间隙） */
  [0, -4.95, 4.95].forEach(function (z) { box(15.0, 0.05, 0.70, MAT.pcb, -0.4, 1.085, z, G, info); });
  /* 横向连接梁 */
  box(0.70, 0.05, 9.90, MAT.pcb, -7.30, 1.085, 0, G, info);
  box(0.70, 0.05, 9.90, MAT.pcb, 2.20, 1.085, 0, G, info);
  /* 上层模组 M6 的承托板 */
  box(2.00, 0.05, 4.30, MAT.pcb, 5.00, 1.100, 0, G, info);
  /* 下层模组汇流铜排与采样线 */
  MODULES.filter(m => m.deck === 1).forEach(function (m) {
    for (const s of [-1, 1]) box(0.14, 0.05, MOD_BLOCK_Z * 0.90, MAT.busbar, m.x + s * (MOD_BLOCK_X / 2 + 0.10), 1.16, m.z, G, info);
    box(MOD_BLOCK_X * 0.94, 0.045, 0.14, MAT.busbar, m.x, 1.16, m.z + MOD_BLOCK_Z / 2 + 0.12, G, info);
    const pts = [];
    for (let i = 0; i <= 6; i++) {
      pts.push(new T.Vector3(m.x - MOD_BLOCK_X / 2 + i * (MOD_BLOCK_X / 6), 1.22 + Math.sin(i) * 0.03, m.z - MOD_BLOCK_Z / 2 - 0.10));
    }
    const cv = new T.CatmullRomCurve3(pts);
    const w = new T.Mesh(new T.TubeGeometry(cv, 40, 0.017, 6, false), MAT.wire);
    w.castShadow = true; G.add(w); tag(w, info);
  });
  return G;
}

/* --- 4.6 高压线束层 --- */
function buildHarness() {
  const G = new T.Group(); root.add(G); layerGroups.harn = G;
  const info = { type: 'layer', layer: 'harn' };
  const y = 2.00;
  /* M6 模组的汇流排（位于线束支架下方） */
  (function () {
    const m = sim.modules['M6'], by = 1.955;
    for (const s of [-1, 1]) box(0.16, 0.055, MOD_BLOCK_Z * 0.92, MAT.busbar, m.x + s * (MOD_BLOCK_X / 2 + 0.10), by, m.z, G, info);
    box(MOD_BLOCK_X * 0.96, 0.05, 0.15, MAT.busbar, m.x, by, m.z + MOD_BLOCK_Z / 2 + 0.12, G, info);
  })();
  /* 线束支架：两条纵向线槽 + 两道横梁（透空结构） */
  box(PACK_HX * 1.80, 0.055, 0.70, MAT.pcb, 0, y, -2.2, G, info);
  box(PACK_HX * 1.80, 0.055, 0.70, MAT.pcb, 0, y, 2.2, G, info);
  box(0.70, 0.055, 9.90, MAT.pcb, -7.10, y, 0, G, info);
  box(0.70, 0.055, 9.90, MAT.pcb, 2.20, y, 0, G, info);
  box(1.60, 0.055, 4.60, MAT.pcb, 5.00, y - 0.075, 0, G, info);
  /* 主正 / 主负铜排 */
  box(PACK_HX * 1.72, 0.075, 0.30, MAT.busbar, 0, y + 0.075, -2.2, G, info);
  box(PACK_HX * 1.72, 0.075, 0.30, MAT.busbar, 0, y + 0.075, 2.2, G, info);
  /* 橙色高压线束 */
  const routes = [
    [[-6.8, y + 0.14, -2.2], [-4.0, y + 0.32, -3.3], [0.5, y + 0.58, -3.8], [4.4, y + 0.44, -2.6], [6.3, y + 0.24, -0.6]],
    [[-6.8, y + 0.14, 2.2], [-3.4, y + 0.36, 3.2], [1.2, y + 0.60, 3.5], [4.8, y + 0.40, 2.4], [6.3, y + 0.24, 0.6]],
    [[6.3, y + 0.24, -0.6], [7.0, y + 0.34, 0.0], [6.3, y + 0.24, 0.6]],
  ];
  routes.forEach(function (rt) {
    const cv = new T.CatmullRomCurve3(rt.map(p => new T.Vector3(p[0], p[1], p[2])));
    const tb = new T.Mesh(new T.TubeGeometry(cv, 90, 0.115, 10, false), MAT.wireOrange);
    tb.castShadow = true; G.add(tb); tag(tb, info);
  });
  box(0.62, 0.30, 0.50, MAT.plastic, 5.5, y + 0.22, -2.4, G, info);
  const sw = new T.Mesh(new T.CylinderGeometry(0.24, 0.24, 0.40, 18), MAT.plastic);
  sw.position.set(6.5, y + 0.26, 0); sw.castShadow = true; G.add(sw); tag(sw, info);
  const swTop = new T.Mesh(new T.CylinderGeometry(0.30, 0.30, 0.10, 18), MAT.busbar);
  swTop.position.set(6.5, y + 0.49, 0); G.add(swTop); tag(swTop, info);
  box(0.50, 0.36, 0.34, MAT.plastic, -5.8, y + 0.24, -2.2, G, info);
  return G;
}

/* --- 4.7 BMS 主控 BMU + 高压配电盒 PDU --- */
function buildBMS() {
  const G = new T.Group(); root.add(G); layerGroups.bms = G;
  const info = { type: 'layer', layer: 'bms' };

  /* ---- 主控 BMU：MCU + 隔离 CAN + 电源 + 绝缘监测 IMC ---- */
  box(2.70, 0.055, 1.90, MAT.pcb, -2.10, 2.075, 1.90, G, info);
  /* MCU 主控芯片与外围 */
  box(0.42, 0.09, 0.42, MAT.plastic, -2.55, 2.145, 1.75, G, info);
  box(0.26, 0.07, 0.26, MAT.plastic, -1.70, 2.135, 1.55, G, info);   /* 隔离 CAN 收发器 */
  box(0.22, 0.07, 0.22, MAT.plastic, -1.70, 2.135, 2.05, G, info);   /* 数字隔离器 */
  for (let i = 0; i < 12; i++) box(0.15, 0.06, 0.11, MAT.plastic, -3.05 + (i % 6) * 0.33, 2.13, 1.35 + Math.floor(i / 6) * 1.05, G, info);
  /* 绝缘监测模块 IMC */
  box(0.90, 0.30, 0.70, MAT.imc, -0.55, 2.25, 1.10, G, info);
  box(0.62, 0.05, 0.42, MAT.aluDark, -0.55, 2.42, 1.10, G, info);
  /* 低压 32pin 接插件 + 散热片 */
  box(1.10, 0.34, 0.46, MAT.conn, -2.10, 2.24, 2.70, G, info);
  box(1.50, 0.09, 0.50, MAT.aluDark, -2.10, 2.15, 0.95, G, info);

  /* ---- 高压配电盒 PDU 外壳 ---- */
  box(2.90, 0.34, 2.30, MAT.plastic, 3.90, 2.19, -2.60, G, info);
  box(2.40, 0.06, 1.80, MAT.aluDark, 3.90, 2.38, -2.60, G, info);
  /* 主正 / 主负 / 预充 继电器 ×3（含线圈与触点柱） */
  [[-0.85, -0.55], [0.05, -0.55], [0.90, -0.55]].forEach(function (p, i) {
    box(0.60, 0.26, 0.52, MAT.alu, 3.90 + p[0], 2.44, -2.60 + p[1], G, info);
    const c1 = new T.Mesh(new T.CylinderGeometry(0.075, 0.075, 0.10, 12), MAT.terminal);
    c1.position.set(3.90 + p[0] - 0.17, 2.60, -2.60 + p[1]); G.add(c1); tag(c1, info);
    const c2 = c1.clone(); c2.position.x = 3.90 + p[0] + 0.17; G.add(c2); tag(c2, info);
    box(0.36, 0.06, 0.30, MAT.plastic, 3.90 + p[0], 2.31, -2.60 + p[1], G, info);
  });
  /* 预充电阻（陶瓷绕线） */
  const pr = new T.Mesh(new T.CylinderGeometry(0.13, 0.13, 0.62, 14), MAT.ceramic);
  pr.rotation.z = Math.PI / 2; pr.position.set(3.05, 2.44, -1.55); pr.castShadow = true;
  G.add(pr); tag(pr, info);
  box(0.20, 0.10, 0.20, MAT.aluDark, 2.70, 2.44, -1.55, G, info);
  box(0.20, 0.10, 0.20, MAT.aluDark, 3.42, 2.44, -1.55, G, info);
  /* 主熔断器 500 A / 700 VDC */
  const fz = new T.Mesh(new T.CylinderGeometry(0.16, 0.16, 0.86, 16), MAT.ceramic);
  fz.rotation.z = Math.PI / 2; fz.position.set(4.70, 2.44, -1.55); fz.castShadow = true;
  G.add(fz); tag(fz, info);
  [[-0.44], [0.44]].forEach(function (d) {
    const e = new T.Mesh(new T.CylinderGeometry(0.175, 0.175, 0.14, 16), MAT.fuse);
    e.rotation.z = Math.PI / 2; e.position.set(4.70 + d[0], 2.44, -1.55); G.add(e); tag(e, info);
  });
  /* 霍尔电流传感器（开口磁环套装在母线上） */
  const hall = new T.Mesh(new T.TorusGeometry(0.34, 0.11, 10, 24, Math.PI * 1.55), MAT.hall);
  hall.rotation.y = Math.PI / 2; hall.rotation.z = Math.PI * 0.22;
  hall.position.set(2.55, 2.20, -3.45); hall.castShadow = true; G.add(hall); tag(hall, info);
  box(0.40, 0.26, 0.30, MAT.plastic, 2.55, 2.20, -3.85, G, info);
  /* 总正 / 总负引出铜排与接插件 */
  [[-1.15], [1.15]].forEach(function (d) {
    const c = new T.Mesh(new T.CylinderGeometry(0.19, 0.19, 0.34, 16), MAT.busbar);
    c.rotation.x = Math.PI / 2; c.position.set(3.90 + d[0], 2.20, -3.80);
    c.castShadow = true; G.add(c); tag(c, info);
  });
  box(1.30, 0.22, 0.40, MAT.conn, 3.90, 2.26, -4.05, G, info);
  return G;
}

/* --- 圆角矩形轮廓（盖板与密封条共用） --- */
function roundRect(w, d, r) {
  const s = new T.Shape();
  s.moveTo(-w / 2 + r, -d / 2);
  s.lineTo(w / 2 - r, -d / 2); s.quadraticCurveTo(w / 2, -d / 2, w / 2, -d / 2 + r);
  s.lineTo(w / 2, d / 2 - r); s.quadraticCurveTo(w / 2, d / 2, w / 2 - r, d / 2);
  s.lineTo(-w / 2 + r, d / 2); s.quadraticCurveTo(-w / 2, d / 2, -w / 2, d / 2 - r);
  s.lineTo(-w / 2, -d / 2 + r); s.quadraticCurveTo(-w / 2, -d / 2, -w / 2 + r, -d / 2);
  return s;
}

/* --- 4.8 上盖板 --- */
function buildCover() {
  const G = new T.Group(); root.add(G); layerGroups.cover = G;
  const info = { type: 'layer', layer: 'cover' };
  const y = 2.36;
  const W = PACK_HX * 2 * 1.005, D = PACK_HZ * 2 * 1.005;
  const g1 = new T.ExtrudeGeometry(roundRect(W, D, 0.9), { depth: 0.10, bevelEnabled: true, bevelThickness: 0.035, bevelSize: 0.035, bevelSegments: 3, curveSegments: 8 });
  g1.rotateX(-Math.PI / 2);
  const cover = new T.Mesh(g1, MAT.cover);
  cover.position.y = y + 0.10; cover.castShadow = true; cover.receiveShadow = true;
  G.add(cover); tag(cover, info);
  const g2 = new T.ExtrudeGeometry(roundRect(W * 0.50, D * 0.58, 0.5), { depth: 0.14, bevelEnabled: true, bevelThickness: 0.04, bevelSize: 0.05, bevelSegments: 3, curveSegments: 8 });
  g2.rotateX(-Math.PI / 2);
  const dome = new T.Mesh(g2, MAT.aluBright);
  dome.position.y = y + 0.20; dome.castShadow = true;
  G.add(dome); tag(dome, info);
  /* 防爆阀 + 低压接插件 */
  box(1.20, 0.26, 0.95, MAT.plastic, 5.3, y + 0.20, -2.9, G, info);
  for (let i = 0; i < 4; i++) box(0.20, 0.14, 0.46, MAT.aluDark, 5.0 + i * 0.24, y + 0.34, -2.9, G, info);
  box(1.05, 0.20, 0.56, MAT.plastic, -6.0, y + 0.18, -4.2, G, info);
  const bg = new T.CylinderGeometry(0.075, 0.075, 0.09, 12);
  for (let i = -5; i <= 5; i++) {
    for (const zz of [-1, 1]) {
      const b = new T.Mesh(bg, MAT.bolt);
      b.position.set(i * 1.28, y + 0.20, zz * (PACK_HZ * 0.84));
      b.castShadow = true; G.add(b); tag(b, info);
    }
  }
  return G;
}

/* =========================================================================
   4.9 ~ 4.12 新增实体：温度采集 / 电压温度采集 / 灭火装置 / 包外密封条
   ========================================================================= */

/* 从控 CSC 采集板安装位（由模组位置派生，供 CSC 与 NTC 引线共用） */
function cscSlotOf(m) {
  return {
    x: m.x,
    y: DECK_Y[m.deck] + CFG.cellH + 0.26,
    z: m.z - MOD_BLOCK_Z / 2 + 0.32,
    w: MOD_BLOCK_X * 0.80,
  };
}

/* --- 4.9 温度采集单元：24 只 NTC 热敏电阻 + 引线 --- */
function buildNTC() {
  const G = new T.Group(); root.add(G); layerGroups.ntc = G;
  const info = { type: 'layer', layer: 'ntc' };
  const beadGeo = new T.SphereGeometry(0.062, 12, 10);
  const clipGeo = new T.BoxGeometry(0.20, 0.022, 0.16);
  const stemGeo = new T.CylinderGeometry(0.020, 0.020, 0.10, 8);

  MODULES.forEach(function (m) {
    const by = DECK_Y[m.deck] + CFG.cellH;
    const slot = cscSlotOf(m);
    /* 4 只/模组：2 只贴电芯顶面，2 只贴极柱铜排 */
    const spots = [
      { x: m.x + (-1 * (CFG.cellW + CFG.gapX)), y: by + 0.035, z: m.z + (-1.5 * (CFG.cellD + CFG.gapZ)) },
      { x: m.x + (1 * (CFG.cellW + CFG.gapX)), y: by + 0.035, z: m.z + (1.5 * (CFG.cellD + CFG.gapZ)) },
      { x: m.x + MOD_BLOCK_X / 2 + 0.10, y: by + 0.145, z: m.z - 1.19 },
      { x: m.x - MOD_BLOCK_X / 2 - 0.10, y: by + 0.145, z: m.z + 1.19 },
    ];
    spots.forEach(function (p) {
      const clip = new T.Mesh(clipGeo, MAT.nickel);
      clip.position.set(p.x, p.y - 0.028, p.z); G.add(clip); tag(clip, info);
      const st = new T.Mesh(stemGeo, MAT.ntcLead);
      st.position.set(p.x, p.y + 0.010, p.z); G.add(st); tag(st, info);
      const bead = new T.Mesh(beadGeo, MAT.ntc);
      bead.scale.set(1, 0.72, 1.35); bead.position.set(p.x, p.y + 0.045, p.z);
      bead.castShadow = true; G.add(bead); tag(bead, info);
      /* 引线：NTC → 本模组 CSC 采集板 */
      const cv = new T.CatmullRomCurve3([
        new T.Vector3(p.x, p.y + 0.050, p.z),
        new T.Vector3(p.x + (slot.x - p.x) * 0.30, p.y + 0.055, p.z + (slot.z - p.z) * 0.32),
        new T.Vector3(slot.x + (p.x - slot.x) * 0.16, slot.y - 0.03, slot.z + 0.06),
        new T.Vector3(slot.x, slot.y + 0.02, slot.z + 0.22),
      ]);
      const ld = new T.Mesh(new T.TubeGeometry(cv, 24, 0.016, 6, false), MAT.ntcLead);
      G.add(ld); tag(ld, info);
    });
  });
  return G;
}

/* --- 4.10 电压温度采集单元：6 块 CSC 板 + 72 路采样镍片 + 隔离 SPI 菊花链 --- */
function buildSense() {
  const G = new T.Group(); root.add(G); layerGroups.sense = G;
  const info = { type: 'layer', layer: 'sense' };
  const tabGeo = new T.BoxGeometry(0.30, 0.016, 0.11);

  MODULES.forEach(function (m) {
    const slot = cscSlotOf(m);
    /* CSC 采集板本体 */
    box(slot.w, 0.05, 0.62, MAT.pcb, slot.x, slot.y, slot.z, G, info);
    /* AFE 采样芯片 + MCU */
    box(0.40, 0.075, 0.40, MAT.plastic, slot.x - slot.w * 0.26, slot.y + 0.062, slot.z, G, info);
    box(0.22, 0.06, 0.22, MAT.plastic, slot.x + slot.w * 0.16, slot.y + 0.055, slot.z - 0.16, G, info);
    /* 被动均衡电阻阵列 12 路 */
    for (let i = 0; i < 12; i++) {
      box(0.13, 0.055, 0.10, MAT.ceramic, slot.x + slot.w * 0.06 + (i % 6) * 0.20, slot.y + 0.050, slot.z + (i < 6 ? -0.21 : 0.21), G, info);
    }
    /* 低压接插件 + 温度端子 */
    box(0.46, 0.16, 0.26, MAT.conn, slot.x + slot.w * 0.40, slot.y + 0.10, slot.z, G, info);
    box(0.30, 0.10, 0.18, MAT.plastic, slot.x - slot.w * 0.44, slot.y + 0.075, slot.z + 0.18, G, info);

    /* 采样镍片：每只电芯正极柱 → 采集板 */
    const by = DECK_Y[m.deck] + CFG.cellH;
    m.cells.forEach(function (cell) {
      const cx = (cell.col - (CFG.modCols - 1) / 2) * (CFG.cellW + CFG.gapX);
      const cz = (cell.row - (CFG.modRows - 1) / 2) * (CFG.cellD + CFG.gapZ);
      const tb = new T.Mesh(tabGeo, MAT.nickel);
      tb.position.set(m.x + cx + 0.42, by + 0.135, m.z + cz);
      tb.castShadow = true; G.add(tb); tag(tb, info);
    });
    /* 采样排线沿列间走线槽汇入采集板 */
    for (const sx of [-0.73, 0.73]) {
      const cv = new T.CatmullRomCurve3([
        new T.Vector3(m.x + sx, by + 0.16, m.z + MOD_BLOCK_Z / 2 - 0.30),
        new T.Vector3(m.x + sx, by + 0.19, m.z),
        new T.Vector3(m.x + sx * 0.55, by + 0.21, m.z - MOD_BLOCK_Z / 2 + 0.55),
        new T.Vector3(slot.x + sx * 0.30, slot.y + 0.03, slot.z + 0.24),
      ]);
      const rb = new T.Mesh(new T.TubeGeometry(cv, 34, 0.026, 6, false), MAT.wire);
      rb.castShadow = true; G.add(rb); tag(rb, info);
    }
  });
  /* 隔离 SPI 菊花链：M1→M2→M3→M4→M5→M6→BMU */
  const chain = MODULES.map(cscSlotOf);
  chain.push({ x: -2.10, y: 2.10, z: 1.35 });
  for (let i = 1; i < chain.length; i++) {
    const a = chain[i - 1], b = chain[i];
    const cv = new T.CatmullRomCurve3([
      new T.Vector3(a.x, a.y + 0.06, a.z - 0.30),
      new T.Vector3((a.x + b.x) / 2, Math.max(a.y, b.y) + 0.30, (a.z + b.z) / 2 - 0.60),
      new T.Vector3(b.x, b.y + 0.06, b.z - 0.30),
    ]);
    const w = new T.Mesh(new T.TubeGeometry(cv, 40, 0.022, 6, false), MAT.wire);
    G.add(w); tag(w, info);
  }
  return G;
}

/* --- 4.11 小型灭火装置：储压罐 + 电磁阀 + 管网 + 雾化喷头 + 探测线 --- */
function buildFire() {
  const G = new T.Group(); root.add(G); layerGroups.fire = G;
  const info = { type: 'layer', layer: 'fire' };
  const y = 1.72;                       /* 储压罐中心：包内中央通道上方、线束支架之下 */
  /* 全氟己酮储压罐（1.2 L，横置于模组间纵向通道） */
  const tank = new T.Mesh(new T.CylinderGeometry(0.26, 0.26, 1.30, 20), MAT.fire);
  tank.rotation.z = Math.PI / 2; tank.position.set(-6.05, y, 0);
  tank.castShadow = true; G.add(tank); tag(tank, info);
  [[-0.65], [0.65]].forEach(function (d) {
    const cap = new T.Mesh(new T.SphereGeometry(0.26, 18, 12, 0, Math.PI * 2, 0, Math.PI / 2), MAT.fireCap);
    cap.rotation.z = d[0] > 0 ? -Math.PI / 2 : Math.PI / 2;
    cap.position.set(-6.05 + d[0], y, 0); G.add(cap); tag(cap, info);
  });
  /* 罐身标识环 + 固定抱箍 */
  box(0.52, 0.52, 0.53, MAT.fireCap, -6.05, y, 0, G, info);
  for (const d of [-0.40, 0.40]) {
    const bd = new T.Mesh(new T.TorusGeometry(0.272, 0.035, 8, 20), MAT.aluDark);
    bd.rotation.y = Math.PI / 2; bd.position.set(-6.05 + d, y, 0); G.add(bd); tag(bd, info);
    box(0.10, 0.46, 0.18, MAT.aluDark, -6.05 + d, y - 0.34, 0, G, info);
  }
  /* 电磁阀 + 压力表 + 电启动线 */
  box(0.36, 0.34, 0.34, MAT.fireCap, -5.08, y, 0, G, info);
  const sol = new T.Mesh(new T.CylinderGeometry(0.11, 0.11, 0.30, 14), MAT.nozzle);
  sol.rotation.x = Math.PI / 2; sol.position.set(-5.08, y - 0.28, 0); G.add(sol); tag(sol, info);
  const gauge = new T.Mesh(new T.CylinderGeometry(0.15, 0.15, 0.09, 16), MAT.aluBright);
  gauge.rotation.z = Math.PI / 2; gauge.position.set(-6.05, y + 0.30, 0); G.add(gauge); tag(gauge, info);
  box(0.24, 0.16, 0.20, MAT.plastic, -6.05, y + 0.30, 0.28, G, info);

  /* 不锈钢灭火管网：下层主干（中央通道）+ 立管 + 上层支路（覆盖 M6） */
  const x0 = -4.78, xm = 2.42, x1 = 6.55;
  const py = 1.62, by2 = 2.28;
  const pipePts = [];
  for (let i = 0; i <= 7; i++) pipePts.push(new T.Vector3(x0 + (xm - x0) * i / 7, py + Math.sin(i * 1.1) * 0.012, 0));
  const pipe = new T.Mesh(new T.TubeGeometry(new T.CatmullRomCurve3(pipePts), 130, 0.058, 10, false), MAT.firePipe);
  pipe.castShadow = true; G.add(pipe); tag(pipe, info);
  /* 立管 */
  const riser = new T.Mesh(new T.CylinderGeometry(0.058, 0.058, by2 - py, 10), MAT.firePipe);
  riser.position.set(xm, (py + by2) / 2, 0); riser.castShadow = true; G.add(riser); tag(riser, info);
  /* 上层支路（位于 M6 上方） */
  const brPts = [];
  for (let i = 0; i <= 5; i++) brPts.push(new T.Vector3(xm + (x1 - xm) * i / 5, by2 + Math.sin(i * 0.8) * 0.010, 0));
  const br = new T.Mesh(new T.TubeGeometry(new T.CatmullRomCurve3(brPts), 90, 0.052, 10, false), MAT.firePipe);
  br.castShadow = true; G.add(br); tag(br, info);
  /* 管夹立柱：主干立于下层模组顶面，支路立于 M6 顶面 */
  for (let i = 0; i <= 6; i += 2) {
    const px = x0 + (xm - x0) * i / 6;
    box(0.09, 0.58, 0.20, MAT.aluDark, px, 1.33, 0, G, info);
    box(0.15, 0.045, 0.26, MAT.aluDark, px, py + 0.075, 0, G, info);
  }
  for (const px of [3.4, 4.6, 5.8]) {
    box(0.09, 0.30, 0.20, MAT.aluDark, px, 2.14, 0, G, info);
    box(0.15, 0.045, 0.26, MAT.aluDark, px, by2 + 0.070, 0, G, info);
  }
  /* 雾化喷头 ×6（正对电芯防爆阀方向） */
  [[-3.70, py - 0.16, 0.15], [-1.50, py - 0.16, 0.15], [0.60, py - 0.16, 0.15], [1.90, py - 0.16, 0.15],
  [4.10, by2 - 0.10, 0.10], [5.80, by2 - 0.10, 0.10]].forEach(function (n) {
    const st = new T.Mesh(new T.CylinderGeometry(0.045, 0.045, n[2], 10), MAT.firePipe);
    st.position.set(n[0], n[1], 0); G.add(st); tag(st, info);
    const nz = new T.Mesh(new T.CylinderGeometry(0.052, 0.105, 0.13, 12), MAT.nozzle);
    nz.position.set(n[0], n[1] - n[2] / 2 - 0.05, 0); nz.castShadow = true; G.add(nz); tag(nz, info);
    const tp = new T.Mesh(new T.CylinderGeometry(0.028, 0.028, 0.05, 8), MAT.fireCap);
    tp.position.set(n[0], n[1] - n[2] / 2 - 0.14, 0); G.add(tp); tag(tp, info);
  });
  /* 热敏探测线（沿主干管网敷设，遇 170 ℃ 熔断点火） */
  const detPts = [];
  for (let i = 0; i <= 10; i++) detPts.push(new T.Vector3(x0 + (xm - x0) * i / 10, py - 0.14 - Math.sin(i * 0.9) * 0.045, 0.20));
  const det = new T.Mesh(new T.TubeGeometry(new T.CatmullRomCurve3(detPts), 80, 0.017, 6, false), MAT.fireWire);
  G.add(det); tag(det, info);
  /* 探测线回接控制盒 */
  box(0.30, 0.22, 0.26, MAT.plastic, -5.08, y - 0.34, 0.28, G, info);
  return G;
}

/* --- 4.12 包外密封条：整周 EPDM 胶条 + 压合筋 + 拐角接角 --- */
function buildSeal() {
  const G = new T.Group(); root.add(G); layerGroups.seal = G;
  const info = { type: 'layer', layer: 'seal' };
  const y = 2.335;                      /* 压合于箱体法兰上沿 (2.36)，与盖板下沿贴合 */
  const W = PACK_HX * 2 * 1.005, D = PACK_HZ * 2 * 1.005;
  const tw = 0.20;
  const sh = roundRect(W, D, 0.9);
  sh.holes.push(roundRect(W - tw * 2, D - tw * 2, 0.72));
  const g = new T.ExtrudeGeometry(sh, {
    depth: 0.085, bevelEnabled: true, bevelThickness: 0.022,
    bevelSize: 0.020, bevelSegments: 2, curveSegments: 10,
  });
  g.rotateX(-Math.PI / 2);
  const ring = new T.Mesh(g, MAT.seal);
  ring.position.y = y; ring.castShadow = true; ring.receiveShadow = true;
  G.add(ring); tag(ring, info);

  /* 压合筋：沿整周间隔排布的微凸起（模拟螺栓压紧后的压缩印痕） */
  const ribGeo = new T.BoxGeometry(0.16, 0.030, 0.10);
  const ribMat = MAT.sealRib;
  const hz = D / 2 - tw / 2, hx = W / 2 - tw / 2;
  const nLong = 15, nShort = 11;
  for (let i = 0; i < nLong; i++) {
    const px = -W / 2 + tw + (W - 2 * tw) * (i + 0.5) / nLong;
    for (const zz of [-1, 1]) {
      const r = new T.Mesh(ribGeo, ribMat);
      r.position.set(px, y + 0.090, zz * hz); G.add(r); tag(r, info);
    }
  }
  for (let i = 0; i < nShort; i++) {
    const pz = -D / 2 + tw + (D - 2 * tw) * (i + 0.5) / nShort;
    for (const xx of [-1, 1]) {
      const r = new T.Mesh(ribGeo, ribMat);
      r.rotation.y = Math.PI / 2; r.position.set(xx * hx, y + 0.090, pz); G.add(r); tag(r, info);
    }
  }
  /* 四角硫化接角 */
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      box(0.34, 0.100, 0.34, ribMat, sx * (W / 2 - tw / 2), y + 0.045, sz * (D / 2 - tw / 2), G, info);
    }
  }
  return G;
}

/* --- 4.13 检测探针 --- */
const probe = new T.Group();
(function buildProbe() {
  const rod = new T.Mesh(new T.CylinderGeometry(0.035, 0.035, 2.2, 10), MAT.probe);
  probe.add(rod);
  const head = new T.Mesh(new T.CylinderGeometry(0.14, 0.09, 0.28, 14), MAT.probe);
  head.position.y = 1.24; probe.add(head);
  const ring = new T.Mesh(new T.TorusGeometry(0.62, 0.022, 8, 44),
    new T.MeshBasicMaterial({ color: 0x2563eb, transparent: true, opacity: 0.9 }));
  ring.rotation.x = Math.PI / 2; ring.position.y = -1.10; probe.add(ring);
  probe.visible = false; scene.add(probe);
})();

/* --- 4.10 总装 --- */
function buildModel() {
  buildCells();
  buildTray();
  buildCooling();
  MODULES.forEach(buildModule);
  layerGroups.bb1 = busbarLayer(1, 1.16, { type: 'layer', layer: 'inter' });
  buildInterconnect();
  buildNTC();
  buildSense();
  buildHarness();
  buildFire();
  buildBMS();
  buildSeal();
  buildCover();
  /* 分层归组：deck1（M1–M5）/ deck2（M6） */
  layerGroups.deck1 = new T.Group(); root.add(layerGroups.deck1);
  ['M1', 'M2', 'M3', 'M4', 'M5'].forEach(function (id) { layerGroups.deck1.add(sim.modules[id].group); });
  layerGroups.deck2 = sim.modules['M6'].group;
}
