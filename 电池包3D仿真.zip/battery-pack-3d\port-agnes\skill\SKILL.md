---
name: build-exploded-3d-sim
description: 从零构建「可拆解 + 分层 + 指标动态仿真」的 three.js 单文件网页应用，并保证后期可持续改模。触发词：可拆解三维界面、爆炸图、设备拆解仿真、分层模型、电池包/发动机/设备三维仿真、做个能拆的 3D 页面、后期还要改模型。
agent_created: true
portable: true
---

# 可拆解三维仿真应用：从需求到可持续维护的交付

> **本技能不绑定任何 harness / 模型。** 已在 WorkBuddy 上验证；移植到 Agnes Harness、
> DeepSeek Harness (dsh) 或任何「有文件读写 + shell + Skill 机制」的 agent 均可直接使用。
> 配套完整规格见同级 `port-agnes/SPEC.md`（参数表、公式、验收断言全在里面，照抄即可）。

## 何时用

用户要一个能"拆开看"的三维页面：分层结构、可爆炸、可点选到最小单元、每个单元有随物理/数据规律变化的指标。
典型对象：电池包、发动机、电机、手机、建筑、机械总成。

## 核心原则（决定后期能不能改）

**不要只交一个打包好的 HTML。** 1.4 MB 的单文件一旦成为唯一真相，后续 AI 每次都要读全文、改全文，慢且易崩。
必须同时交付：

```
vendor/           three.js r160 build/three.module.js + OrbitControls.js（本地）
src/index.html    模板，含 /*__APP_JS__*/ 占位符
src/app.part1.js  CFG 配置 + 仿真/数据层
src/app.part2.js  三维建模层（LAYERS + buildXxx 函数）
src/app.part3.js  交互与仪表盘
build.js          vendor + src → 单文件 HTML
SPEC.md           完整复现规格（换 AI / 换 harness 时的唯一真相）
tools/verify.js   无头 Chrome 自动验收器
```

写 part 文件时**每片控制在 500 行以内**——超过就会被写入工具截断，导致半成品。宁可拆成 part4/part5。

## 现成工具（直接用，不要重写）

- `init.js` —— `node tools/init.js <新目录> --name X --api X`：复制 three.js、生成 src 三片骨架 + build.js + verify.js + SPEC.md。
- `verify.js` —— `node tools/verify.js <html> --api X --wait 8000 [--exec "JS"] [--shot a.png] [--json]`：无头 Chrome 自检，输出 PASS/FAIL、JS 错误、canvas、DOM、stats()，退出码 0/1。
  把它拷进新项目的 `tools/`，即可让任何新项目具备自验收能力。

## 全自动模式（用户只给一句话、不想干预时）

按此循环自行执行到底，除主题完全不明外不要中途提问：

0. 跑 `init.js` 生成骨架。
1. 按主题补全 `SPEC.md` 五问（缺公式就用工程经验模型，并在 CFG 注释标注「估算值」）。
2. 写 part1 → part2 → part3，每片 <500 行。
3. `node build.js` 打包。
4. `node tools/verify.js 产物.html --api X --wait 8000`，并用 `--exec` 跑关键链路做数值断言、`--shot` 截图自查。
5. FAIL → 读错误行自行改源码 → 回到第 3 步，最多迭代 8 轮；仍失败则带错误摘要交付并说明卡在哪。
6. PASS → 把验收输出原文给用户，并交代源码目录、重新打包命令、改模入口。

要点：
- 自验收不能只看 PASS，必须用 `--exec` 推进 N 步后取 stats() 确认数值合理（数量级、单调性、守恒）。
- 无头环境 rAF 极稀疏，仿真推进必须走暴露的 `step(dt,n)`，不能等真实时间。
- `verify.js` 在 Git Bash 下用 `spawnSync` 会报 EBUSY，已改异步 `spawn`，不要改回去。

## 流程

### 1. 先问清五件事（用户没说就按常识给默认值并注明）
① 主题 ② 从外到内的层清单 ③ 最小可拆单元 ④ 每个单元要显示的指标 ⑤ 指标的计算规律。
用户 0 基础时不要追问公式，用工程经验模型建模，并在 CFG 注释里标注"估算值，可校准"。

### 2. 建模层：Group 套娃是"能拆解"的全部秘密
- 层级：`root → 层 Group → 子部件 Group → 最小单元 Mesh`。
- 每层一个 `buildXxx()` 函数，内部统一走辅助函数 `box(w,h,d,mat,x,y,z,parent,info)`，方便增删零件。
- 每个 Mesh 用 `userData` 挂 `{type, layer, module, cellId}` 之类的标签，拾取后反查归属全靠它。
- 几何体与材质**必须共享实例**（同类电芯共用一个 geometry / 各单元独立 material），否则帧率崩。

### 3. 拆解：不要做 CSG 切割
爆炸 = 滑块值 t(0~1) × 每层预设抬升系数 → 写入 `layerGroup.position.y`。
上层系数大、底层系数 0。这样可原样收回、可动画、零成本。

### 4. 数据/仿真层：配置与逻辑分离
- 所有物理参数、尺寸、阈值集中在 `CFG`，**禁止魔法数字散落**。
- 主循环固定步长（100 ms）推进，与渲染帧率解耦；渲染只画不算。
- 单元状态 = 对象实例字段；着色只改 `material.color/emissive`，绝不重建几何体。
- 暴露 `window.XXX` 调试接口（`selectCell/test/sweep/step(dt,n)/stats/pick`），既方便用户批量仿真，也是自动化验收的抓手。

### 5. 打包与验收
- 依赖全内联，禁用 `type="module"` / importmap（file:// 下 CORS 会拦）。
- 验收必须跑完整交互链路并把数值回传给用户，不能只说"已完成"。

### 6. 交付时一并给出
- 单文件 HTML 路径 + 源码目录 + `node build.js` 这条命令。
- 一次性复刻提示词（换主题可复用）。
- 改模指令库 + 每次改模要先发的"开场白"（声明工程结构、只改 src、改完重新打包、最小改动）。
- 提醒备份 `cp -r src src.bak-$(date +%m%d)`，一次只提一个改动。

## 后期改模（用户说"改一下"时）

1. 先确认工程目录与分片职责，读**对应那一片**即可，不要通读全文。
2. 改参数 → 只动 CFG；改结构 → 动 part2 的 LAYERS 与对应 build 函数；改界面 → 动 part3。
3. 改完执行 `node build.js` 重新打包，并说明改了哪个文件的哪一段。
4. 绝不直接编辑生成的 HTML。

## 新增实体/部件的标准做法（用户说"再加上 XX 的模型实体"）

1. **先升格为「结构层」，再建模**。在 `LAYERS` 加一条 `{id,name,color,explode,y,note}`，在 `buildXxx()` 里 `layerGroups[id] = G`（并 `root.add(G)`），再在 `buildModel()` 里调用。这样**显隐勾选、爆炸分离、射线拾取、详情面板**四件事自动生效，交互层一行都不用改。若新实体需要跟随某层移动（如模组汇流层跟随模组），在 `applyExplode()`/`applyVisibility()` 里从 `LAYERS` **派生**系数而不是硬编码数字。
2. **爆炸系数要整体重排**。新增层会挤占原有间距，把所有 `explode` 重新分配一遍并保持单调递增。同时更新 `VIEWS` 与相机初始位——总高从 9.4 涨到 10.4 就会把最上面的层裁出画面。改完用 `--shot` 确认**最顶层与最底层的标注都在画面内**。
3. **详情面板补分支**。`renderDetail()` 的 `extra` 映射按 layer id 加指标表（含 `sim.xxx` 实时量），否则点新层得到空面板。
4. **包内空间必须逐层核对干涉**。新增零件前先列出已有层的 y 区间（模组电芯顶面、模组框架顶、线束支架、CSC 板、盖板底面），新实体坐标逐个对照。典型坑：灭火管网放在"看起来空"的中央通道，实际穿过上层模组的电芯；储压罐撞上线束横梁；喷嘴悬在下层电池上方却伸进上层模组。**先定 y 区间，再定 x/z**。
5. 多函数共用的几何工具（如 `roundRect`）要提到模块作用域，别留在某个 `buildXxx` 内部。
6. 新增**随状态着色**的材质（如电芯侧面绝缘膜）：在 `applyColors()` 里一并处理——结构模式取固定底色，其它模式取状态色再 `lerp` 回底色（保留自身色调，避免盖住热力图）；同时同步 `ghost/isolate` 的 `opacity`，否则半透明隔离时会"底色不透明"地卡在场景里。
7. 新增实体的 Mesh 要 `tag(m, {type:'layer', layer:id})`，否则点不到；电芯细节件要 `tag` 成 `{type:'cell', cell}`，点它仍能选中该单体。
8. 加一个 `focus([x,y,z], dist)` 调试接口（直接把相机对准世界坐标点），否则无头截图只能靠固定视角，没法近距核查新零件。

## 可复现性的隐藏杀手：共用随机序列

新增任何**程序化纹理/装饰**（标签、条码、噪点贴图）时，若调用主 PRNG `rnd()`，会整体平移后续随机数 → 电芯离散性分布、老化标定、历史验收数值全部变化，"可复现"就断了。
做法：在新增模块内 `const lr = mulberry32(独立种子)`，绝不碰主序列。改完重跑既有数值断言，确认没有漂移。

## 物理量建模的三条硬规则（血泪）

1. **反馈项要做分母时必须限幅**。例：冷却液温升 `ΔT = 净换热 / 流量`，流量趋小时 ΔT 被放大甚至变负，温度场会跑飞（实测跌到 −30 ℃ 下限）。必须 `clamp(ΔT, 0, 上界)` 且给分母设下限（`max(pump, pumpMin)`），同时明确物理约束（冷却液局部温度只能从入口单调升高）。
2. **状态量要满足可断言的恒等式**。做完数值模型，用 `verify.js --exec` 断言内部恒等式，例如 `V_pack − (OCV − I·R_pack) < 1e-9`。通过说明模型自洽，比"看起来对"可靠得多。
3. **老化/寿命类模型必须交叉标定**。写下系数后立刻手算校核：如 `kCyc=0.0045, z=0.55` → 1000 次等效循环损失 `0.0045×1000^0.55 = 20.1%`，与 EOL 定义（80%）对齐；日历项同理（10 年 → 10.9%）。断言这两个数，防止系数拍脑袋。

衍生指标的做法（SOH / SOP / OCV / Vnom）：
- SOH 至少给三个口径：`SOH-C = 1 − Qloss`（容量）、`SOH-R = (R_EOL − R/R_0)/(R_EOL − 1)`（内阻/功率健康）、`SOH-P ≈ 1/(R/R_0)`（功率能力）。只给一个 SOH 会被质疑。
- 老化内阻增长要与容量损失联动：`R = R₀·(1 + kR·Qloss)`，kR 由"Qloss=20% 时 R 增长 60%"反解。
- SOP 是**前瞻性**量：电压约束用 OCV 而非端电压，再叠加倍率、温度（低温禁充、深冷限放）、SOC 末端软拐点，取四者最小值并**记录主导限制因素**（可诊断性强，用户很吃这一套）。
- 标称电压是常量（`Vnom × series`），开路电压是实时量（`Σ OCV(SOC_i)`），端电压是 `OCV − I·R`。三者必须分开显示，不要混用一个"电压"。

---

## 跨 harness 移植（Agnes Harness / DeepSeek Harness / 其它）

这套工作流**不依赖任何特定 harness 特性**，移植只需三件事：

1. **把 `SPEC.md` 当第一份上下文喂进去。** 它不依赖 Skill 机制——即使目标 harness 的 Skill 加载失败，直接把 SPEC 贴进对话一样能复现。这是最稳的保底路径。
2. **确认三项能力**：文件读写、shell 执行、能 spawn 外部进程（Chrome）。缺任何一项，全自动闭环就断了。
3. **放行命令审批**。Agnes Harness 默认每条命令都要人工确认（allow once / allow for session / deny），必须开 **session 级 allow**，否则"自己改 → 自己验"的循环会被切成碎片。

### 跨环境必改的一处：浏览器路径

`verify.js` 原本硬编码 Windows 路径，已改为三级回退：
`环境变量 CHROME_PATH` → 常见安装路径（Win/macOS/Linux）→ PATH 上的 `google-chrome/chromium/chrome`。

换机器或换 OS 时**不要改代码**，直接：
```bash
CHROME_PATH="/usr/bin/chromium" node tools/verify.js 产物.html --api X
```

### 成本提示（DeepSeek V4 Pro）

峰谷定价：UTC 01:00–04:00 与 06:00–10:00 为峰时（双倍）。
换算北京时间（UTC+8）：**09:00–12:00 与 14:00–18:00 是峰时，18:00–次日 09:00 是谷时**。
长任务（完整复现）排在北京时间 20:00 之后，成本差约 4 倍。
`reasoning_effort`：简单改模用 `low`，建模用 `high`，别全程 `max`。

## 坑

- 写入被截断 → 分片，每片 < 500 行。
- 白屏 → 检查是否残留 module/import 语法或外链 CDN。
- 越改越卡 → geometry/material 没复用。
- 数字不合理 → 单位不一致（Ah vs As、kW vs W），让 CFG 注释写明单位。
- 换环境后 verify.js 报"未找到 Chrome" → 设 `CHROME_PATH`，别去改硬编码数组。
