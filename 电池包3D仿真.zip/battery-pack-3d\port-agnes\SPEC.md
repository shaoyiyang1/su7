# 复现规格 SPEC：动力电池包三维拆解与电热仿真平台

> 这份文件的唯一目的：让**任意 AI + 任意 harness** 不看原工程也能复刻出等价产物。
> 所有数值都是本工程实测标定过的，直接抄，不要重新猜。

---

## 0. 主题与交付形态（不可妥协）

| 项 | 要求 |
|---|---|
| 主题 | 车用动力电池包（CTP，双层模组布置） |
| 技术栈 | three.js r160 + OrbitControls + CSS2DRenderer，**全本地内联** |
| 交付物 | 单个 `.html` 文件，双击即开，**断网、无服务器、无 CDN** |
| 源码形态 | `src/app.part1/2/3.js` + `src/index.html` + `build.js`，**每个分片 < 500 行** |
| 打包命令 | `node build.js`（把 vendor 内联进 HTML 占位符 `/*__APP_JS__*/`） |
| 禁用的东西 | `type="module"`、importmap、外链 CDN、CSS2DRenderer 若不需要可省 |

**为什么必须分片**：写入工具超过约 500 行会截断，产出半成品。宁可拆 part4/part5。

---

## 1. 结构层定义（12 层，爆炸系数必须单调递增）

坐标系：1 scene unit = 125 mm。Y 向上。数组顺序即由下到上。

```js
const LAYERS = [
  { id:'tray',  name:'下箱体 / 托盘总成',      explode:0.00,  y:0.62 },
  { id:'cool',  name:'液冷板总成',              explode:1.45,  y:0.26 },
  { id:'deck1', name:'下层模组 M1–M5',          explode:2.95,  y:0.75 },
  { id:'ntc',   name:'温度采集单元 NTC',        explode:3.85,  y:1.06 },
  { id:'inter', name:'层间汇流采样板',          explode:4.65,  y:1.14 },
  { id:'sense', name:'电压温度采集单元 CSC',    explode:5.25,  y:1.30 },
  { id:'deck2', name:'上层模组 M6',             explode:5.95,  y:1.58 },
  { id:'harn',  name:'高压线束 / 汇流层',       explode:7.05,  y:2.06 },
  { id:'fire',  name:'小型灭火装置',            explode:7.90,  y:2.12 },
  { id:'bms',   name:'BMS 主控 / 高压配电盒',   explode:8.70,  y:2.22 },
  { id:'seal',  name:'包外密封条',              explode:9.75,  y:2.34 },
  { id:'cover', name:'上盖板总成',              explode:10.35, y:2.46 },
];
```

每层还要有 `color`（图层列表色块）与 `note`（详情面板说明文字）。

**爆炸实现**：`layerGroups[id].position.y = ui.explode * LAYERS[i].explode`，滑块 0~1。
**不要做 CSG 切割**——位移即可原样收回、可动画、零成本。

---

## 2. 参数表 CFG（原样抄，单位已注明）

```js
const CFG = {
  UMM: 125,                       /* 1 scene unit = 125 mm */
  cellW:1.40, cellH:0.72, cellD:1.14, gapX:0.06, gapZ:0.05,
  modCols:3, modRows:4,           /* 每模组 3×4 = 12 只 */

  Vnom:3.70, CapAh:320, series:72, parallel:1,
  R0:0.00042,                     /* 25℃/50%SOC/SOH100% 直流内阻 Ω */
  Ea:25000,                       /* 内阻活化能 J/mol */
  dUdT:-0.00025,                  /* 熵变系数 V/K */

  ocvX:[0,.02,.05,.10,.20,.30,.40,.50,.60,.70,.80,.90,.95,1.0],
  ocvY:[3.00,3.32,3.44,3.54,3.64,3.70,3.76,3.81,3.87,3.95,4.05,4.14,4.175,4.20],

  Cth:4600,                       /* 单电芯热容 J/K */
  hA:2.60,                        /* 液冷等效换热 W/K */
  hAair:0.45,                     /* 停泵自然对流 W/K */
  kA:0.19,                        /* 相邻电芯导热 W/K */

  TcoolIn:28, mCp:320, pumpRef:320, pumpMin:60,

  massCell:5.4, massPack:509,
  packL:1.9625, packW:1.375, packH:0.325,

  Vmax:4.20, Vmin:2.80, TmaxWarn:50, TmaxFault:60, dVwarn:0.10, dTwarn:8,

  EolCap:0.80, EolRes:1.60,
  kCyc:0.0045, zCyc:0.55, EaCyc:30000,
  kCal:0.0017, EaCal:40000, qLossCal0:0.008,
  kRgrowth:3.0, kmPerCycle:400,

  hysV:0.004, hysTau:8,           /* OCV 充放电滞回 */

  CcontD:1.0, CpeakD:3.0, CcontC:0.5, CpeakC:2.0,
  TchgMin:0, TdisMin:-20,
  socEndD:0.03, socEndC:0.97,
};
```

---

## 3. 物理模型（公式必须照抄，这是"科学"的全部来源）

### 3.1 内阻（三重耦合）
```
fT   = exp(Ea/R · (1/T − 1/298.15))        // Arrhenius，越冷越大
fSoc = 1 + 0.35·(0.5 − SOC)²  /0.25        // SOC 两端上翘
fAge = 1 + kRgrowth·Qloss                  // Qloss=20% → 1.60 倍
R    = R0 · fT · fSoc · fAge · resFactor   // resFactor = 1+gauss·0.04（离散性 σ=4%）
```

### 3.2 产热与散热
```
Q_gen  = I²·R − I·(T+273.15)·dUdT          // 焦耳热 + 可逆熵变热
ΔTcool = clamp(Q_net / max(pump, pumpMin), 0, 30)   // 【必须限幅，见坑1】
T_cell' = T + (Q_gen − hA_eff·(T − Tcool_local) + Σ kA·(T_neighbor − T)) / Cth · dt
hA_eff = pump>0 ? hA·(0.35 + 0.65·pump/pumpRef) : hAair
Tcool_local = TcoolIn + mod.flow · ΔTcool   // 沿流程升温，flow∈[0,1]
```

### 3.3 三个电压必须分开显示
```
Vnom      = 3.70 × 72 = 266.4 V            // 常量
OCV_pack  = Σ OCV(SOC_i)  （含滞回 hysV，一阶滞后 hysTau）
V_terminal= OCV_pack − I·R_pack
```
**恒等式断言**：`|V_terminal − (OCV_pack − I·R_pack)| < 1e-9`

### 3.4 老化（Bloom 双通道）
```
Qloss_cyc = kCyc · cycDose^zCyc · exp(EaCyc/R·(1/298.15 − 1/T))
Qloss_cal = kCal·√t_days · exp(EaCal/R·(1/298.15 − 1/T)) + qLossCal0
Qloss     = Qloss_cyc + Qloss_cal
SOH-C = 1 − Qloss
SOH-R = (EolRes − R/R0) / (EolRes − 1)
SOH-P = 1 / (R/R0)
```

### 3.5 SOP（前瞻性，用 OCV 不用端电压）
四重约束取最小，**并记录主导限制因素**：
1. 电压：`(OCV_i − Vmin)/R_i`（放电）、`(Vmax − OCV_i)/R_i`（充电）
2. 倍率：`Cpeak/ Ccont × CapAh`
3. 温度：`T<TchgMin → 充电 0`（析锂）；`T>TmaxWarn → 线性降额到 TmaxFault`
4. SOC 末端软拐点

输出：`PdCont / PdPeak / PcCont / PcPeak` + `limD` / `limC` 字符串。

---

## 4. 交互要求（缺一不可）

- 爆炸滑条 0~100%；12 层逐层勾选显隐；剖切；外壳半透明；6 组视角预设
- 射线拾取：点模组 → 模组级面板；点电芯 → 单体级 10 项参数
- **单体检测**：25 A / 600 ms 恒流脉冲，`R = ΔV/ΔI` 在线辨识
- **全芯扫描**：72 只依次扫描 → 均值/σ/极差/3σ 离群 + 柱状图 + 一致性评级
- 着色模式 ≥5 种：结构 / 温度 / 电压 / SOC / 内阻
- 工况 ≥7 种：静置、城市、高速、CLTC-P、全油门、赛道 2C、直流快充
- 仪表盘：SOC、SOH(三口径)、SOP充放、Vnom、OCV、端压、功率、单体极值、温差、绝缘电阻
- 2 张实时曲线（电压/电流/OCV；Tmax/Tavg/SOC）+ 滚动报警日志

## 5. 建模性能红线

- 几何体与材质**必须共享实例**（同类电芯共 geometry，各单元独立 material）
- 着色只改 `material.color / emissive`，**绝不重建几何体**
- 主循环固定步长 100 ms，与渲染帧率解耦

## 6. 必须暴露的调试接口（自动化验收的抓手）

```js
window.BatteryPack3D = { sim, CFG, MODULES, LAYERS, ui,
  selectCell, cell, test, sweep, step(dt,n), stats,
  setMode, setPump, setCoolant, setExplode, setLayerVisible,
  setColorMode, setView, focus([x,y,z],dist), reset, layerY(id) };
```
**无头环境 rAF 极稀疏**，推进仿真必须走 `step(dt,n)`，不能等真实时间。

---

## 7. 验收断言（复现后必须逐条跑，写在报告里）

| # | 断言 | 期望值 |
|---|---|---|
| 1 | JS 运行时错误 | 0 |
| 2 | `Vnom` | 266.4 V |
| 3 | `\|V − (OCV − I·R)\|` 残差 | < 1e-9（实测 5.7e-14） |
| 4 | 1000 次等效循环衰减 | ≈20.1%（对齐 80% EOL） |
| 5 | 25 ℃ 存放 10 年衰减 | ≈11% |
| 6 | 赛道 2C 持续 900 s | tmax≈57 ℃，自动降额，limD 标为温度 |
| 7 | 冷却液 −20 ℃ | 充电电流 → 0（析锂保护） |
| 8 | 单体脉冲辨识 vs 模型 | 偏差 < 5% |
| 9 | 12 图层全部存在且可显隐 | 每层详情面板 ≠ 空 |
| 10 | 拆解后最顶层与最底层 | 都在画面内（用截图确认） |

断言工具：`node tools/verify.js 产物.html --api BatteryPack3D --wait 8000 [--exec "JS"] [--shot a.png]`
（脚本在 `tools/verify.js`，换项目时整个 `tools/` 拷过去即可）

---

## 8. 已知坑（照着避，别自己踩）

1. **反馈项做分母必须限幅**：`ΔT = Q/流量` 在流量小时被放大甚至变负，温度场跑飞（实测跌到 −30 ℃）。必须 clamp + 分母下限。
2. **共用随机序列杀可复现性**：新增程序化纹理/条码若调用主 PRNG `rnd()`，会整体平移后续随机数，历史验收数值全变。做法：新增模块内用独立种子 `mulberry32(独立种子)`。
3. **包内干涉必须逐个核算**：新增零件前先列已有层的 Y 区间，先定 Y 再定 X/Z。典型坑：灭火管网放进"看起来空"的中央通道，实际穿过上层模组电芯。
4. **新增层要重排全部爆炸系数 + 更新 VIEWS 与相机初始位**，否则最顶层被裁出画面。
5. **新增实体要 `tag(mesh,{type:'layer',layer:id})`**，否则射线拾取点不到。
6. Git Bash 下 `spawnSync` 启动 Chrome 报 **EBUSY** 且拿不到输出，必须用异步 `spawn`。
