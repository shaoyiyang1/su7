/* =========================================================================
   sim-core.js —— 动力电池包电热仿真内核（纯 Node，无 three.js / 无 DOM）
   ⚠ 本文件由 tools/build-simcore.js 从 src/app.part1.js 自动派生，请勿手改。
     改仿真逻辑请改 src/app.part1.js，然后执行: node tools/build-simcore.js
   派生时间: 2026-10-06T20:01:34.727Z
   ========================================================================= */
'use strict';

/* =========================================================================
   动力电池包三维拆解与电热仿真分析平台
   Pack: 72S1P / 266.4 V / 320 Ah / 85.2 kWh  ·  12 结构层 · 6 模组 · 72 电芯
   Part 1 —— 参数、电芯模型、电热耦合仿真引擎
   ========================================================================= */

'use strict';
/* [sim-core] three.js 引用已移除（本内核不参与渲染） */
const clamp = (v, a, b) => v < a ? a : (v > b ? b : v);
const lerp = (a, b, t) => a + (b - a) * t;
const fmt = (v, n) => (v === null || v === undefined || !isFinite(v)) ? '--' : v.toFixed(n === undefined ? 1 : n);
const $ = () => null;   /* [sim-core] DOM stub：Node 环境无 document */

/* 确定性伪随机：保证每次加载的单体离散性分布一致 */
function mulberry32(a) {
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
const rnd = mulberry32(20261006);
function gauss() {
  let u = 0, v = 0;
  while (u === 0) u = rnd();
  while (v === 0) v = rnd();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

/* =========================================================================
   1. 设计参数
   ========================================================================= */
const CFG = {
  UMM: 125,                                     /* 1 scene unit = 125 mm */

  /* 电芯几何（scene unit） */
  cellW: 1.40, cellH: 0.72, cellD: 1.14, gapX: 0.06, gapZ: 0.05,
  modCols: 3, modRows: 4,                       /* 每模组 3×4 = 12 只 */

  /* 电参数 */
  Vnom: 3.70, CapAh: 320, series: 72, parallel: 1,
  R0: 0.00042,                                  /* 25℃/50%SOC/SOH100% 直流内阻 Ω */
  Ea: 25000,                                    /* 内阻活化能 J/mol */
  dUdT: -0.00025,                               /* 熵变系数 dU/dT V/K */

  /* OCV-SOC 特性（NCM 622，25℃） */
  ocvX: [0, .02, .05, .10, .20, .30, .40, .50, .60, .70, .80, .90, .95, 1.0],
  ocvY: [3.00, 3.32, 3.44, 3.54, 3.64, 3.70, 3.76, 3.81, 3.87, 3.95, 4.05, 4.14, 4.175, 4.20],

  /* 单电芯热参数 */
  Cth: 4600,                                    /* 热容 J/K（4.6 kg × 1000 J/kg·K） */
  hA: 2.60,                                     /* 液冷等效换热系数 W/K（h≈105 W/m²K × 0.0249 m² 底面） */
  hAair: 0.45,                                  /* 停泵自然对流 W/K */
  kA: 0.19,                                     /* 相邻电芯导热 W/K（1.0 W/mK × 0.0249 m² / 0.13 m） */

  /* 冷却回路 */
  TcoolIn: 28, mCp: 320, pumpRef: 320, pumpMin: 60,                        /* 入口温度 ℃，热容流率 W/K */

  /* 结构与质量 */
  massCell: 5.4, massPack: 509,
  packL: 1.9625, packW: 1.375, packH: 0.325,

  /* BMS 保护阈值 */
  Vmax: 4.20, Vmin: 2.80, TmaxWarn: 50, TmaxFault: 60, dVwarn: 0.10, dTwarn: 8,

  /* ---- 老化模型（Bloom 经验式 Qloss = B·exp(−Ea/RT)·A^z，z≈0.55） ---- */
  EolCap: 0.80,          /* 容量保持率降至 80% 判为寿命终止 EOL */
  EolRes: 1.60,          /* 内阻增长至 1.60 倍判为寿命终止 */
  kCyc: 0.0045,          /* 循环老化系数：标定为 1000 次满循环 → 20% 衰减 */
  zCyc: 0.55,            /* 吞吐量幂律指数 */
  EaCyc: 30000,          /* 循环老化活化能 J/mol */
  kCal: 0.0017,          /* 日历老化系数：25 ℃ 存放 10 年 → 约 10% 衰减 */
  EaCal: 40000,          /* 日历老化活化能 J/mol */
  qLossCal0: 0.008,      /* 出厂初始容量损失（对应 SOH₀ = 99.2%） */
  kRgrowth: 3.0,         /* 内阻增长 R = R₀·(1 + kR·Qloss)，Qloss=20% → 1.60 倍 */
  kmPerCycle: 400,       /* 等效满循环对应里程 km（用于剩余寿命折算） */

  /* ---- 开路电压 OCV ---- */
  hysV: 0.004,           /* 充放电 OCV 滞回幅值 V（NCM 典型 4~10 mV） */
  hysTau: 8,             /* 滞回一阶滞后时间常数 s */

  /* ---- SOP 功率状态限值 ---- */
  CcontD: 1.0, CpeakD: 3.0,   /* 放电持续 / 10 s 峰值倍率 C */
  CcontC: 0.5, CpeakC: 2.0,   /* 充电持续 / 10 s 峰值倍率 C */
  TchgMin: 0, TdisMin: -20,   /* 充电下限（0 ℃ 以下析锂）/ 放电下限 ℃ */
  socEndD: 0.03, socEndC: 0.97, /* 放电 / 充电末端 SOC 软拐点 */
};

/* 标称量派生：标称电压 = 单体标称 × 串联数；标称能量 = 标称电压 × 额定容量 */
const VNOM_PACK = CFG.Vnom * CFG.series;                       /* 266.4 V */
const ENOM_PACK = VNOM_PACK * CFG.CapAh / 1000;                /* 85.25 kWh */
const VMAX_PACK = CFG.Vmax * CFG.series;                       /* 302.4 V */
const VMIN_PACK = CFG.Vmin * CFG.series;                       /* 201.6 V */

/* 几何派生量 */
const MOD_BLOCK_X = CFG.modCols * CFG.cellW + (CFG.modCols - 1) * CFG.gapX;   /* 4.32 */
const MOD_BLOCK_Z = CFG.modRows * CFG.cellD + (CFG.modRows - 1) * CFG.gapZ;   /* 4.71 */
const PACK_HX = 7.85, PACK_HZ = 5.50;           /* 1u = 125 mm → 1962 × 1375 × 325 mm */
const DECK_Y = { 1: 0.30, 2: 1.22 };            /* 各层电芯底面 Y */

const MODULES = [
  { id: 'M1', name: '模组 1', x: -5.60, z: -2.55, deck: 1, flow: 0.08 },
  { id: 'M2', name: '模组 2', x: -0.70, z: -2.55, deck: 1, flow: 0.22 },
  { id: 'M3', name: '模组 3', x: -5.60, z: 2.55, deck: 1, flow: 0.38 },
  { id: 'M4', name: '模组 4', x: -0.70, z: 2.55, deck: 1, flow: 0.52 },
  { id: 'M5', name: '模组 5', x: 5.00, z: 0.00, deck: 1, flow: 0.74 },
  { id: 'M6', name: '模组 6', x: 5.00, z: 0.00, deck: 2, flow: 0.92 },
];

const LAYERS = [
  { id: 'tray', name: '下箱体 / 托盘总成', color: '#94a3b8', explode: 0.00, y: 0.62, note: '铝型材边梁 + 冲压底板 + 加强筋；承担 12 处悬置安装点与整车碰撞传力路径，上沿法兰为密封条压合面。' },
  { id: 'cool', name: '液冷板总成', color: '#3b82f6', explode: 1.45, y: 0.26, note: '口琴管蛇形流道覆盖全部 72 只电芯底面；入口 28 ℃，出口温度随实时热负荷变化。' },
  { id: 'deck1', name: '下层模组 M1–M5', color: '#1d4ed8', explode: 2.95, y: 0.75, note: '5 个模组 60 只电芯，每模组 12S1P；模组内电芯经导热结构胶与铝端板耦合。' },
  { id: 'ntc', name: '温度采集单元 NTC', color: '#0ea5e9', explode: 3.85, y: 1.06, note: '24 只 NTC 热敏电阻（10 kΩ / B=3435 K），分布于 6 个模组的电芯表面与极柱铜排，测温精度 ±0.5 ℃，引线汇入 CSC 采集板。' },
  { id: 'inter', name: '层间汇流采样板', color: '#6d28d9', explode: 4.65, y: 1.14, note: '下层模组正负极互联铜排与 12 路/模组电压采样镍片，采样精度 ±1.5 mV。' },
  { id: 'sense', name: '电压温度采集单元 CSC', color: '#7c3aed', explode: 5.25, y: 1.30, note: '6 块从控 CSC 采集板（AFEI：12 路电压 + 4 路温度 / 板），含 AFE 采样芯片、被动均衡电阻阵列、隔离 SPI 与低压接插件。' },
  { id: 'deck2', name: '上层模组 M6', color: '#0284c7', explode: 5.95, y: 1.58, note: '层叠布置的第 6 模组（12S1P），位于托盘右侧高位，处于液冷流程末端。' },
  { id: 'harn', name: '高压线束 / 汇流层', color: '#ef6a1e', explode: 7.05, y: 2.06, note: '600 V 级橙色高压线束、主熔断器、总正总负铜排与手动维修开关接口。' },
  { id: 'fire', name: '小型灭火装置', color: '#dc2626', explode: 7.90, y: 2.12, note: '车载全氟己酮灭火装置：1.2 L 储压罐 + 电磁阀 + 不锈钢管网 + 6 只雾化喷头 + 热敏探测线，触发温度 170 ℃，喷放时间 ≤ 10 s。' },
  { id: 'bms', name: 'BMS 主控 / 高压配电盒', color: '#334155', explode: 8.70, y: 2.22, note: '1 主控 BMU（SOC/SOH/SOP 估算 + 绝缘监测）+ 高压配电 PDU：主正/主负/预充继电器、预充电阻、500 A 熔断器、霍尔电流传感器。' },
  { id: 'seal', name: '包外密封条', color: '#475569', explode: 9.75, y: 2.34, note: 'EPDM 发泡密封胶条（截面 12×9 mm），沿箱体法兰整周压合，配合盖板螺栓实现 IP68；拐角处硫化接角。' },
  { id: 'cover', name: '上盖板总成', color: '#c7ccd6', explode: 10.35, y: 2.46, note: '1.2 mm 铝板冲压上盖，集成防爆阀与低压接插件，压合于包外密封条之上。' },
];

const COLOR_MODES = [
  { id: 'struct', name: '结构', hint: '结构着色：铝制壳体（银灰）+ 电芯顶盖绝缘板（橙）。' },
  { id: 'temp', name: '温度', hint: '电芯温度热力图：由液冷回路与电芯产热实时求解，体现冷却末端温度梯度。' },
  { id: 'volt', name: '电压', hint: '单体端电压分布：V = OCV(SOC) − I·R(T,SOC,SOH)，体现一致性差异与极化压降。' },
  { id: 'soc', name: 'SOC', hint: '荷电状态分布：安时积分求解，单体容量差异导致 SOC 缓慢发散。' },
  { id: 'res', name: '内阻', hint: '直流内阻分布：R = R₀·f(T)·f(SOC)·f(SOH)，Arrhenius 温度修正。' },
];

const LEGENDS = {
  struct: { title: '结构视图', bar: 'linear-gradient(90deg,#e8ecf2,#a9b3c1 45%,#ef6a1e)', scale: ['铝壳体', '绝缘顶盖'], note: '橙 = 电芯顶盖 / 高压件；银灰 = 铝合金结构件；蓝 = 电芯侧面 PET 绝缘膜；红 = 灭火装置；黑 = 密封条 / NTC。' },
  temp: { title: '电芯温度 (℃)', bar: 'linear-gradient(90deg,#1e3a8a,#0ea5e9,#22c55e,#eab308,#f97316,#dc2626)', scale: ['≤10', '25', '40', '≥60'], note: '冷却液入口温度 = 边界条件；流程末端电芯偏高 1~4 K。' },
  volt: { title: '单体电压 (V)', bar: 'linear-gradient(90deg,#dc2626,#f97316,#eab308,#22c55e,#0ea5e9,#7c3aed)', scale: ['3.00', '3.70', '4.20'], note: '极化压降 ∝ I·R，大电流工况下内阻偏大的单体电压更低。' },
  soc: { title: '荷电状态 (%)', bar: 'linear-gradient(90deg,#dc2626,#f97316,#eab308,#84cc16,#16a34a)', scale: ['0', '50', '100'], note: '安时积分 + 单体容量离散性，长时间运行后出现 SOC 发散。' },
  res: { title: '直流内阻 (mΩ)', bar: 'linear-gradient(90deg,#16a34a,#84cc16,#eab308,#f97316,#dc2626)', scale: ['0.25', '0.45', '0.90'], note: '低温、高 SOC 与老化均使内阻显著上升。' },
};

/* =========================================================================
   2. 电芯与仿真状态
   ========================================================================= */
function ocvOf(soc) {
  const X = CFG.ocvX, Y = CFG.ocvY, s = clamp(soc, 0, 1);
  for (let i = 1; i < X.length; i++) if (s <= X[i]) return lerp(Y[i - 1], Y[i], (s - X[i - 1]) / (X[i] - X[i - 1]));
  return Y[Y.length - 1];
}

class Cell {
  constructor(mod, r, c, serial) {
    this.mod = mod; this.row = r; this.col = c; this.serial = serial;
    this.id = mod.id + '-C' + String(r * CFG.modCols + c + 1).padStart(2, '0');
    this.capFactor = 1 + gauss() * 0.012;      /* 容量离散性 σ=1.2% */
    this.resFactor = 1 + gauss() * 0.030;      /* 内阻离散性 σ=3% */
    this.soc = 0.62; this.T = 26; this.R = CFG.R0; this.V = ocvOf(this.soc);
    this.ocv = ocvOf(this.soc); this.ocvH = 0;      /* 开路电压与滞回项 */
    this.heat = 0; this.throughAh = 0; this.Tcool = CFG.TcoolIn;
    this.neighbors = []; this.flash = 0; this.Rmeas = null; this.detectT = 0;
    this.baseY = 0;
  }
  /* 动态直流内阻：Arrhenius 温度项 × SOC 项 × SOH 项 × 制造离散性 */
  computeR() {
    const Tk = this.T + 273.15;
    const fT = Math.exp(CFG.Ea / 8.314 * (1 / Tk - 1 / 298.15));
    const s = this.soc;
    const fSoc = 1 + 0.30 * (Math.exp(-s / 0.10) + Math.exp(-(1 - s) / 0.08));
    const fAge = 1 + CFG.kRgrowth * sim.qLoss;      /* 老化内阻增长（Qloss=20% → 1.6 倍） */
    this.R = CFG.R0 * fT * fSoc * fAge * this.resFactor;
    return this.R;
  }
}

const sim = {
  t: 0, playing: true, speed: 5, mode: 'cltc',
  cells: [], modules: {}, soh: 0.992,
  Ipack: 0, Vpack: 265, P: 0, speedKmh: 0, odo: 0,
  vmax: 0, vmin: 1, tmax: 0, tmin: 99, tavg: 25, ravg: 0, socAvg: 0.62,
  cVmax: null, cVmin: null, cTmax: null, cTmin: null,
  coolOut: 28, heat: 0, qnet: 0, iso: 620, pump: 320, hA: CFG.hA,
  throughput: 0, derate: 1, PlimitD: 0, PlimitC: 0,

  /* ---- SOH / 老化 ---- */
  cycDose: 0, calDose: 0,                       /* 温度加权等效循环数 / 等效天 */
  qLossCyc: 0, qLossCal: CFG.qLossCal0, qLoss: CFG.qLossCal0,
  sohC: 1 - CFG.qLossCal0, sohR: 1, sohP: 1,    /* 容量 / 功率(内阻) / 功率能力 SOH */
  rulCyc: Infinity, rulDays: Infinity, rulKm: Infinity, rulLimit: '--',
  /* ---- 电压 ---- */
  ocvPack: VNOM_PACK, ocvAvg: CFG.Vnom, rPack: CFG.R0 * CFG.series,
  /* ---- SOP ---- */
  sop: {
    IdCont: 0, IdPeak: 0, IcCont: 0, IcPeak: 0,
    PdCont: 0, PdPeak: 0, PcCont: 0, PcPeak: 0,
    limD: '--', limC: '--', fTD: 1, fTC: 1, fSD: 1, fSC: 1,
  },
};
let SOC0 = 0.62;

function buildCells() {
  sim.cells = [];
  let serial = 0;
  MODULES.forEach(m => {
    m.cells = [];
    for (let r = 0; r < CFG.modRows; r++) {
      for (let c = 0; c < CFG.modCols; c++) {
        const cell = new Cell(m, r, c, ++serial);
        /* 初始状态：沿冷却流程方向 SOC 略高、温度略低，叠加离散性 */
        const spatial = (1 - m.flow) * 0.012 - 0.004;
        cell.soc = clamp(SOC0 + spatial + gauss() * 0.006, 0.02, 1);
        cell.T = 25 + (1 - m.flow) * 1.2 + gauss() * 0.35;
        cell.computeR();
        cell.V = ocvOf(cell.soc);
        sim.cells.push(cell); m.cells.push(cell);
      }
    }
    /* 模组内 4 邻域导热网络 */
    const g = m.cells;
    for (let r = 0; r < CFG.modRows; r++) {
      for (let c = 0; c < CFG.modCols; c++) {
        const cur = g[r * CFG.modCols + c];
        if (r > 0) cur.neighbors.push(g[(r - 1) * CFG.modCols + c]);
        if (r < CFG.modRows - 1) cur.neighbors.push(g[(r + 1) * CFG.modCols + c]);
        if (c > 0) cur.neighbors.push(g[r * CFG.modCols + c - 1]);
        if (c < CFG.modCols - 1) cur.neighbors.push(g[r * CFG.modCols + c + 1]);
      }
    }
  });
  sim.modules = {};
  MODULES.forEach(m => { sim.modules[m.id] = m; });
}

/* ---------- 行驶 / 充电工况 ---------- */
const VEH = { m: 2280, CdA: 0.68, fr: 0.011, eta: 0.90, etaR: 0.65, aux: 900 };
const CLTC = (function () {
  const arr = []; let tt = 0, i = 0;
  const sp = [0, 15, 30, 45, 60, 70, 80, 90, 110, 45, 30, 0, 20, 50, 75, 100, 60, 35, 0, 25, 55, 85, 40, 65, 0];
  while (tt < 1800) { const dur = 24 + (i * 37) % 42; arr.push({ t0: tt, t1: tt + dur, v: sp[i % sp.length] }); tt += dur; i++; }
  return arr;
})();
function cltcPower(t) {
  const tt = t % 1800;
  let idx = 0;
  while (idx < CLTC.length - 1 && CLTC[idx].t1 < tt) idx++;
  const cur = CLTC[idx], prevV = idx > 0 ? CLTC[idx - 1].v : 0;
  const dur = cur.t1 - cur.t0, el = tt - cur.t0, rampT = dur * 0.45;
  const vKmh = el < rampT ? lerp(prevV, cur.v, el / rampT) : cur.v;
  let a = el < rampT ? (cur.v - prevV) / 3.6 / rampT : 0;
  a = clamp(a, -3.5, 2.4);
  const v = vKmh / 3.6;
  const Pw = VEH.m * a * v + 0.5 * 1.2 * VEH.CdA * v * v * v + VEH.m * 9.81 * VEH.fr * v;
  const Pb = Pw >= 0 ? Pw / VEH.eta : Pw * VEH.etaR;
  return { P: Pb + VEH.aux, vKmh: vKmh };
}
const MODES = [
  { id: 'idle', name: '静置', fn: () => ({ P: 0, vKmh: 0 }) },
  { id: 'city', name: '城市巡航', fn: () => ({ P: 8.5e3, vKmh: 32 }) },
  { id: 'high', name: '高速巡航', fn: () => ({ P: 23e3, vKmh: 110 }) },
  { id: 'cltc', name: 'CLTC-P 工况', fn: cltcPower },
  { id: 'accel', name: '全油门加速', fn: t => ({ P: (t % 22) < 4.5 ? 190e3 : 0, vKmh: (t % 22) < 4.5 ? 145 : 0 }) },
  { id: 'track', name: '赛道 2C 持续', fn: () => ({ P: 220e3, vKmh: 165 }) },
  { id: 'charge', name: '直流快充', fn: () => ({ P: -1, vKmh: 0 }) },
];

/* ---------- 单体内阻脉冲检测 ---------- */
const test = { active: false, cell: null, phase: 0, t: 0, V0: 0, I0: 0, V1: 0, I1: 0, result: null };

/* ---------- 全电芯扫描 ---------- */
const sweep = { active: false, i: 0, t: 0, results: [] };

/* =========================================================================
   3. 仿真主步进
   ========================================================================= */
function stepSim(dt) {
  const mode = MODES.find(m => m.id === sim.mode) || MODES[0];
  const rq = mode.fn(sim.t);
  let Preq = rq.P;

  /* 直流快充（CC-CV，120 kW 桩，按最高单体电压收敛） */
  if (sim.mode === 'charge') {
    let Vmax = 0;
    for (const c of sim.cells) if (c.V > Vmax) Vmax = c.V;
    const taper = clamp((CFG.Vmax - Vmax) / 0.25, 0, 1);
    Preq = -120e3 * taper;
    if (Vmax < 3.9) Preq *= clamp((Vmax - 3.50) / 0.40, 0.35, 1);
  }
  Preq *= sim.derate;

  const Vprev = Math.max(120, sim.Vpack || 265);
  const I = Preq / Vprev;
  const Ipulse = (test.active && test.phase === 1) ? 25 : 0;

  let sumV = 0, heatTot = 0, sumR = 0, sumOcv = 0;
  const hk = 1 - Math.exp(-dt / CFG.hysTau);      /* OCV 滞回一阶趋近系数 */
  for (const c of sim.cells) {
    c.computeR();
    /* 开路电压 = 平衡 OCV(SOC) + 滞回项；放电走低压支、充电走高压支、静置保持 */
    const hTgt = I > 0.5 ? -CFG.hysV : (I < -0.5 ? CFG.hysV : c.ocvH);
    c.ocvH += (hTgt - c.ocvH) * hk;
    const ocv = ocvOf(c.soc) + c.ocvH;
    c.ocv = ocv;
    const Icell = I + (c === test.cell ? Ipulse : 0);
    c.Icell = Icell;
    c.V = ocv - Icell * c.R;
    /* 产热 = 焦耳热 + 可逆熵变热  Q = I²R − I·T·(∂U/∂T) */
    c.heat = Icell * Icell * c.R - Icell * (c.T + 273.15) * CFG.dUdT;
    sumV += c.V; sumOcv += ocv; heatTot += c.heat; sumR += c.R;
  }
  sim.Ipack = I; sim.Vpack = sumV; sim.P = sumV * I; sim.heat = heatTot;
  /* 包级：OCV 为各单体开路电压之和，端电压 V = OCV − I·Rpack（严格成立） */
  sim.ocvPack = sumOcv;
  sim.ocvAvg = sumOcv / CFG.series;
  sim.rPack = sumR;

  /* 冷却液沿流程温升：由「上一步电芯→冷却液净换热」决定（能量守恒）
     约束：局部冷却液温度只能沿流程升高，不得低于入口温度（入口由 chiller 恒温） */
  const dTcool = sim.pump > 0 ? clamp(sim.qnet / Math.max(sim.pump, CFG.pumpMin), 0, 30) : 0;
  sim.coolOut = CFG.TcoolIn + dTcool;
  /* 对流换热系数随流量变化：hA ∝ 流量（泵停转时退化为自然对流） */
  sim.hA = sim.pump > 0 ? CFG.hA * (0.35 + 0.65 * clamp(sim.pump / CFG.pumpRef, 0, 1.2)) : CFG.hAair;
  let qnetNow = 0;

  /* 温度场与安时积分推进 */
  for (const c of sim.cells) {
    c.Tcool = CFG.TcoolIn + c.mod.flow * dTcool;
    const qout = sim.hA * (c.T - c.Tcool);
    qnetNow += qout;
    let qn = 0;
    for (let i = 0; i < c.neighbors.length; i++) qn += CFG.kA * (c.neighbors[i].T - c.T);
    c.T = clamp(c.T + (c.heat - qout + qn) / CFG.Cth * dt, -30, 95);
    c.soc = clamp(c.soc + (-I) * dt / 3600 / (CFG.CapAh * c.capFactor), 0, 1);
    c.throughAh += Math.abs(I) * dt / 3600;
  }
  sim.qnet = qnetNow;

  /* ---- 老化：循环（Ah 吞吐量幂律） + 日历（√t），均按 Arrhenius 温度加速 ---- */
  let st = 0;
  for (const c of sim.cells) st += c.T;
  const Tavg = st / sim.cells.length;
  const accCyc = Math.exp(-CFG.EaCyc / 8.314 * (1 / (Tavg + 273.15) - 1 / 298.15));
  const accCal = Math.exp(-CFG.EaCal / 8.314 * (1 / (Tavg + 273.15) - 1 / 298.15));
  const dAh = Math.abs(I) * dt / 3600;
  sim.cycDose += (dAh / (2 * CFG.CapAh)) * accCyc;     /* 温度加权等效满循环数 */
  sim.calDose += (dt / 86400) * accCal;                /* 温度加权等效天数 */
  sim.qLossCyc = CFG.kCyc * Math.pow(Math.max(sim.cycDose, 0), CFG.zCyc);
  sim.qLossCal = CFG.qLossCal0 + CFG.kCal * (Math.sqrt(sim.calDose + 1) - 1);
  sim.qLoss = clamp(sim.qLossCyc + sim.qLossCal, 0, 0.60);
  sim.sohC = clamp(1 - sim.qLoss, 0.40, 1);
  const fAge = 1 + CFG.kRgrowth * sim.qLoss;           /* 老化导致的内阻倍率 */
  sim.sohR = clamp((CFG.EolRes - fAge) / (CFG.EolRes - 1), 0, 1);
  sim.sohP = clamp(1 / fAge, 0, 1);                    /* 功率能力 ∝ 1/R */
  sim.soh = sim.sohC;
  /* 剩余寿命：容量衰减至 EolCap 的循环数 / 日历天数，取先到者 */
  const qTgt = 1 - CFG.EolCap;
  if (sim.qLoss >= qTgt) {
    sim.rulCyc = 0; sim.rulDays = 0; sim.rulKm = 0; sim.rulLimit = '已达 EOL';
  } else {
    const needDose = Math.pow(Math.max(qTgt - sim.qLossCal, 0) / CFG.kCyc, 1 / CFG.zCyc);
    sim.rulCyc = Math.max(0, needDose - sim.cycDose);
    const vv = (qTgt - sim.qLossCyc - CFG.qLossCal0) / CFG.kCal + 1;
    sim.rulDays = Math.max(0, vv * vv - sim.calDose);
    sim.rulKm = sim.rulCyc * CFG.kmPerCycle;
    const kmByCal = sim.rulDays / 365 * 15000;         /* 按 1.5 万 km/年折算 */
    sim.rulLimit = sim.rulKm <= kmByCal ? '循环老化主导' : '日历老化主导';
  }

  /* 绝缘监测（随湿度与温度缓慢波动） */
  sim.iso = clamp(600 - sim.throughput * 0.02 + Math.sin(sim.t * 0.05) * 12 + Tavg * 0.4, 120, 900);

  sim.t += dt;
  sim.throughput += Math.abs(I) * dt / 3600;
  if (rq.vKmh !== undefined) sim.speedKmh = rq.vKmh;
  sim.odo += (sim.speedKmh / 3.6) * dt;

  updateExtremes();
  computeLimits();
  checkProtection();
  if (test.active) updateTest(dt);
  if (sweep.active) updateSweep(dt);
}

/* ---------------------------------------------------------------------------
   SOP（State of Power）：前瞻性功率限值
   约束链 —— ① 单体电压极限（用 OCV 而非端电压，因 SOP 是对未来的预判）
             ② 电芯倍率限值（持续 / 10 s 峰值）
             ③ 温度降额（过温线性收窄、低温禁充、深冷限放）
             ④ SOC 末端软拐点（低 SOC 限放、高 SOC 限充）
   取四者最小值，并记录当前的主导限制因素。
   --------------------------------------------------------------------------- */
function computeLimits() {
  const s = sim.sop;
  /* ① 电压约束电流：放电 I ≤ (OCV − Vmin)/R ；充电 I ≤ (Vmax − OCV)/R */
  let IvD = Infinity, IvC = Infinity;
  for (const c of sim.cells) {
    const R = Math.max(c.R, 1e-5);
    IvD = Math.min(IvD, (c.ocv - CFG.Vmin) / R);
    IvC = Math.min(IvC, (CFG.Vmax - c.ocv) / R);
  }
  /* ② 倍率约束电流：按当前可用容量（含老化）折算 */
  const capEff = CFG.CapAh * sim.sohC;
  const IrDc = CFG.CcontD * capEff, IrDp = CFG.CpeakD * capEff;
  const IrCc = CFG.CcontC * capEff, IrCp = CFG.CpeakC * capEff;
  /* ③ 温度降额 */
  let fTD = 1, fTC = 1;
  if (sim.tmax > CFG.TmaxWarn) {
    fTD = clamp((CFG.TmaxFault - sim.tmax) / (CFG.TmaxFault - CFG.TmaxWarn), 0, 1);
    fTC = fTD;
  }
  if (sim.tmin < CFG.TchgMin) fTC = 0;            /* 0 ℃ 以下禁止充电（析锂风险） */
  if (sim.tmin < CFG.TdisMin) fTD *= 0.30;        /* −20 ℃ 以下大幅限放 */
  /* ④ SOC 末端软拐点 */
  let fSD = 1, fSC = 1;
  if (sim.socAvg < 0.10) fSD = clamp((sim.socAvg - CFG.socEndD) / (0.10 - CFG.socEndD), 0, 1);
  if (sim.socAvg > 0.90) fSC = clamp((CFG.socEndC - sim.socAvg) / (CFG.socEndC - 0.90), 0, 1);

  s.fTD = fTD; s.fTC = fTC; s.fSD = fSD; s.fSC = fSC;
  s.IdCont = Math.max(0, Math.min(IvD, IrDc) * fTD * fSD);
  s.IdPeak = Math.max(0, Math.min(IvD, IrDp) * fTD * fSD);
  s.IcCont = Math.max(0, Math.min(IvC, IrCc) * fTC * fSC);
  s.IcPeak = Math.max(0, Math.min(IvC, IrCp) * fTC * fSC);

  /* 主导限制因素（用于诊断显示） */
  function limiter(Ivolt, Irate, fT, fS, isDis) {
    if (fT <= 0.001) return '温度';
    if (fS <= 0.001) return isDis ? 'SOC 末端' : 'SOC 满充';
    if (Ivolt <= Irate) return isDis ? '单体欠压' : '单体过压';
    if (fT < 0.999) return '温度降额';
    if (fS < 0.999) return 'SOC 软限';
    return '电芯倍率';
  }
  s.limD = limiter(IvD, IrDp, fTD, fSD, true);
  s.limC = limiter(IvC, IrCp, fTC, fSC, false);

  /* 功率 = 限值电流 × 当前包端电压 */
  const V = Math.max(120, sim.Vpack);
  s.PdCont = s.IdCont * V; s.PdPeak = s.IdPeak * V;
  s.PcCont = s.IcCont * V; s.PcPeak = s.IcPeak * V;
  sim.PlimitD = Math.min(s.PdPeak, 600e3);         /* 兼容旧字段（= 10 s 峰值） */
  sim.PlimitC = Math.min(s.PcPeak, 400e3);

  /* 保护软降额 */
  sim.derate = 1;
  if (sim.tmax > CFG.TmaxFault) sim.derate = 0.2;
  else if (sim.tmax > CFG.TmaxWarn) sim.derate = lerp(1, 0.35, (sim.tmax - CFG.TmaxWarn) / 10);
  if (sim.vmax > CFG.Vmax || sim.vmin < CFG.Vmin) sim.derate = Math.min(sim.derate, 0.15);
}

function updateExtremes() {
  let vmax = -1e9, vmin = 1e9, tmax = -1e9, tmin = 1e9, sr = 0, st = 0, ss = 0;
  let cVmax = null, cVmin = null, cTmax = null, cTmin = null;
  for (const c of sim.cells) {
    if (c.V > vmax) { vmax = c.V; cVmax = c; }
    if (c.V < vmin) { vmin = c.V; cVmin = c; }
    if (c.T > tmax) { tmax = c.T; cTmax = c; }
    if (c.T < tmin) { tmin = c.T; cTmin = c; }
    sr += c.R; st += c.T; ss += c.soc;
  }
  const n = sim.cells.length;
  sim.vmax = vmax; sim.vmin = vmin; sim.cVmax = cVmax; sim.cVmin = cVmin;
  sim.tmax = tmax; sim.tmin = tmin; sim.cTmax = cTmax; sim.cTmin = cTmin;
  sim.ravg = sr / n; sim.tavg = st / n; sim.socAvg = ss / n;
}

/* ---------- 报警 ---------- */
const alarms = [];
const alarmCool = {};
function pushAlarm(lvl, msg) {
  const key = msg.slice(0, 12);
  if (alarmCool[key] && sim.t - alarmCool[key] < 25) return;
  alarmCool[key] = sim.t;
  alarms.unshift({ lvl: lvl, msg: msg, t: sim.t });
  if (alarms.length > 40) alarms.pop();
  if (typeof renderAlarms === 'function') renderAlarms();
}
function checkProtection() {
  const dv = (sim.vmax - sim.vmin) * 1000;
  const dt = sim.tmax - sim.tmin;
  if (sim.vmax > CFG.Vmax) pushAlarm('e', '单体过压 ' + fmt(sim.vmax, 3) + ' V（' + sim.cVmax.id + '）超上限，已限制充电功率');
  if (sim.vmin < CFG.Vmin) pushAlarm('e', '单体欠压 ' + fmt(sim.vmin, 3) + ' V（' + sim.cVmin.id + '）达放电截止，已限制输出');
  if (sim.tmax > CFG.TmaxFault) pushAlarm('e', '电芯过温 ' + fmt(sim.tmax, 1) + ' ℃（' + sim.cTmax.id + '），请求保护降功率');
  else if (sim.tmax > CFG.TmaxWarn) pushAlarm('w', '电芯高温预警 ' + fmt(sim.tmax, 1) + ' ℃（' + sim.cTmax.id + '），进入功率降额区');
  if (dv > CFG.dVwarn * 1000) pushAlarm('w', '单体压差 ' + fmt(dv, 1) + ' mV 超限，一致性异常，建议执行均衡');
  if (dt > CFG.dTwarn) pushAlarm('w', '模组温差 ' + fmt(dt, 1) + ' K 超限，冷却流道可能存在偏流');
  if (sim.iso < 500) pushAlarm('e', '绝缘电阻 ' + fmt(sim.iso, 0) + ' MΩ 低于安全阈值');
}

function startTest(cell) {
  test.active = true; test.cell = cell; test.phase = 0; test.t = 0;
  test.result = null; test.V0 = cell.V; test.I0 = cell.Icell || 0;
  cell.flash = 0.6;
  pushAlarm('i', '对单体 ' + cell.id + ' 施加 25 A / 600 ms 恒流脉冲，开始内阻辨识');
  if (typeof renderDetail === 'function') renderDetail();
}
function updateTest(dt) {
  test.t += dt;
  const c = test.cell;
  if (test.phase === 0 && test.t > 0.45) { test.V0 = c.V; test.I0 = c.Icell || 0; test.phase = 1; test.t = 0; }
  else if (test.phase === 1 && test.t > 0.60) { test.V1 = c.V; test.I1 = c.Icell || 0; test.phase = 2; test.t = 0; }
  else if (test.phase === 2 && test.t > 0.40) {
    const dV = Math.abs(test.V1 - test.V0);
    const dI = Math.abs(test.I1 - test.I0);
    const Rm = dI > 1 ? dV / dI : c.R;
    c.Rmeas = Rm;
    test.result = { Rm: Rm, Rmodel: c.R, err: (Rm - c.R) / c.R * 100, dv: dV, di: dI };
    test.phase = 3;
    pushAlarm('i', '单体 ' + c.id + ' 内阻辨识完成：' + fmt(Rm * 1000, 4) + ' mΩ（ΔV=' + fmt(dV * 1000, 3) + ' mV / ΔI=' + fmt(dI, 2) + ' A）');
    if (typeof renderDetail === 'function') renderDetail();
  }
  if (test.phase < 3) c.flash = 0.55;
}
function startSweep() {
  sweep.active = true; sweep.i = 0; sweep.t = 0; sweep.results = [];
  pushAlarm('i', '启动全电芯直流内阻同步扫描（25 A 脉冲法，72 只单体）');
}
function updateSweep(dt) {
  sweep.t += dt;
  while (sweep.t > 0.022 && sweep.i < sim.cells.length) {
    sweep.t -= 0.022;
    const c = sim.cells[sweep.i++];
    c.computeR();
    const Rm = c.R * (1 + gauss() * 0.018);
    c.Rmeas = Rm; c.flash = 0.5;
    sweep.results.push({ cell: c, R: Rm });
  }
  if (sweep.i >= sim.cells.length) {
    sweep.active = false;
    if (typeof showSweepReport === 'function') showSweepReport();
  }
}

/* =========================================================================
   [sim-core] Node 侧补充层 —— 由 tools/build-simcore.js 追加，请勿手改
   作用：补齐浏览器里由 UI 层承担的职责（复位、取值、批量推进、检测、扫描）
   ========================================================================= */

/* ---- 复位（等价于界面上的 resetSim，去掉全部 UI 调用） ---- */
function resetSim() {
  sim.t = 0; sim.throughput = 0; sim.odo = 0;
  sim.cycDose = 0; sim.calDose = 0;
  sim.qLossCyc = 0; sim.qLossCal = CFG.qLossCal0; sim.qLoss = CFG.qLossCal0;
  sim.sohC = 1 - CFG.qLossCal0; sim.sohR = 1; sim.sohP = 1; sim.soh = sim.sohC;
  sim.iso = 620; sim.Vpack = 265; sim.Ipack = 0; sim.P = 0; sim.derate = 1;
  sim.coolOut = CFG.TcoolIn; sim.qnet = 0; sim.heat = 0; sim.hA = CFG.hA;
  test.active = false; test.cell = null; test.result = null; test.phase = 0;
  sweep.active = false; sweep.results = []; sweep.i = 0;
  alarms.length = 0;
  const r2 = mulberry32(20261006);
  function g2() {
    let u = 0, v = 0;
    while (u === 0) u = r2();
    while (v === 0) v = r2();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }
  sim.cells.forEach(function (c) {
    c.capFactor = 1 + g2() * 0.012;
    c.resFactor = 1 + g2() * 0.040;
    const spatial = (1 - c.mod.flow) * 0.012 - 0.004;
    c.soc = clamp(SOC0 + spatial + g2() * 0.006, 0.02, 1);
    c.T = 25 + (1 - c.mod.flow) * 1.2 + g2() * 0.35;
    c.throughAh = 0; c.Rmeas = null; c.flash = 0; c.ocvH = 0;
    c.computeR(); c.ocv = ocvOf(c.soc); c.V = c.ocv;
  });
  let so = 0, sr = 0;
  for (const c of sim.cells) { so += c.ocv; sr += c.R; }
  sim.ocvPack = so; sim.ocvAvg = so / CFG.series; sim.rPack = sr;
  updateExtremes();
  return getStats();
}

/* ---- 取全量状态（等价于界面 API 的 stats()，去掉 DOM 项） ---- */
function getStats() {
  const r = {
    t: sim.t, soc: sim.socAvg, vpack: sim.Vpack, ipack: sim.Ipack, power: sim.P,
    soh: sim.sohC, sohC: sim.sohC, sohR: sim.sohR, sohP: sim.sohP,
    qLossCyc: sim.qLossCyc, qLossCal: sim.qLossCal, qLoss: sim.qLoss,
    cycDose: sim.cycDose, calDose: sim.calDose,
    rulCyc: sim.rulCyc, rulKm: sim.rulKm, rulDays: sim.rulDays, rulLimit: sim.rulLimit,
    vnom: VNOM_PACK, vminPack: VMIN_PACK, vmaxPack: VMAX_PACK,
    ocv: sim.ocvPack, ocvAvg: sim.ocvAvg, rpack: sim.rPack,
    sop: sim.sop,
    vmax: sim.vmax, vmin: sim.vmin, dv: (sim.vmax - sim.vmin) * 1000,
    tmax: sim.tmax, tmin: sim.tmin, tavg: sim.tavg, dt: sim.tmax - sim.tmin,
    ravg: sim.ravg * 1000, heat: sim.heat, coolOut: sim.coolOut, iso: sim.iso,
    pd: sim.PlimitD, pc: sim.PlimitC, throughput: sim.throughput,
    derate: sim.derate, mode: sim.mode, pump: sim.pump,
    energies: { nom: CFG.CapAh * CFG.series * CFG.Vnom / 1000 },
    test: test.result ? {
      cell: test.cell.id, phase: test.phase, R: test.result.Rm,
      model: test.result.Rmodel, err: test.result.err,
      dv: test.result.dv, di: test.result.di,
    } : { phase: 0 },
    sweep: sweep.results.length,
    alarms: alarms.slice(0, 12).map(a => ({ lvl: a.lvl, t: a.t, msg: a.msg })),
  };
  return r;
}

/* ---- 参数设定 ---- */
function setMode(id) {
  const m = MODES.find(x => x.id === id);
  if (!m) return { ok: false, err: '未知工况: ' + id, available: MODES.map(x => x.id) };
  sim.mode = id; return { ok: true, mode: id, name: m.name };
}
function setPump(v) { sim.pump = Math.max(0, +v || 0); return { ok: true, pump: sim.pump }; }
function setCoolant(v) { CFG.TcoolIn = +v; return { ok: true, TcoolIn: CFG.TcoolIn }; }

/* ---- 推进仿真（dt 默认 0.1 s，与前端主循环一致） ---- */
function runSteps(n, dt) {
  dt = dt || 0.1; n = Math.max(1, Math.min(200000, +n || 1));
  for (let i = 0; i < n; i++) stepSim(dt);
  return getStats();
}

/* ---- 单体定位 ---- */
function cellById(id) {
  return sim.cells.find(c => c.id === id) || null;
}
function cellInfo(c) {
  return {
    id: c.id, module: c.mod.id, row: c.row, col: c.col,
    V: c.V, ocv: c.ocv, soc: c.soc, T: c.T, R: c.R, Rmeas: c.Rmeas,
    heat: c.heat, throughAh: c.throughAh, capFactor: c.capFactor, resFactor: c.resFactor,
    neighbors: c.neighbors.length,
  };
}
function listCells(moduleId) {
  return sim.cells.filter(c => !moduleId || c.mod.id === moduleId).map(cellInfo);
}

/* ---- 单体内阻脉冲辨识（同步推进到出结果） ---- */
function runTest(cellId) {
  const c = cellById(cellId);
  if (!c) return { ok: false, err: '未找到电芯: ' + cellId };
  startTest(c);
  for (let i = 0; i < 60 && test.phase < 3; i++) stepSim(0.1);
  if (!test.result) return { ok: false, err: '辨识未完成（phase=' + test.phase + '）' };
  return {
    ok: true, cell: cellId,
    Rmeas_mOhm: +(test.result.Rm * 1000).toFixed(4),
    Rmodel_mOhm: +(test.result.Rmodel * 1000).toFixed(4),
    err_pct: +test.result.err.toFixed(2),
    dV_mV: +(test.result.dv * 1000).toFixed(3),
    dI_A: +test.result.di.toFixed(2),
  };
}

/* ---- 全芯内阻扫描（同步跑完 72 只） ---- */
function runSweep() {
  startSweep();
  for (let i = 0; i < 4000 && sweep.active; i++) stepSim(0.1);
  const rs = sweep.results.map(r => r.R);
  if (!rs.length) return { ok: false, err: '扫描未产出结果' };
  const mean = rs.reduce((a, b) => a + b, 0) / rs.length;
  const sd = Math.sqrt(rs.reduce((a, b) => a + (b - mean) * (b - mean), 0) / rs.length);
  const sorted = rs.slice().sort((a, b) => a - b);
  const out3 = sweep.results
    .map(r => ({ id: r.cell.id, R: r.R }))
    .filter(r => Math.abs(r.R - mean) > 3 * sd);
  return {
    ok: true, count: rs.length,
    mean_mOhm: +(mean * 1000).toFixed(4),
    sd_mOhm: +(sd * 1000).toFixed(4),
    cv_pct: +(sd / mean * 100).toFixed(2),
    min_mOhm: +(sorted[0] * 1000).toFixed(4),
    max_mOhm: +(sorted[sorted.length - 1] * 1000).toFixed(4),
    range_mOhm: +((sorted[sorted.length - 1] - sorted[0]) * 1000).toFixed(4),
    outliers_3sigma: out3,
    grade: (sd / mean) < 0.02 ? '优' : ((sd / mean) < 0.04 ? '良' : '关注'),
  };
}

/* ---- 自检：断言内部恒等式，确认内核自洽 ---- */
function selfCheck() {
  const out = [];
  resetSim();
  runSteps(5, 0.1);
  let s1 = getStats();
  out.push({ name: 'Vnom', got: +s1.vnom.toFixed(1), want: 266.4, pass: Math.abs(s1.vnom - 266.4) < 0.05 });
  const r1 = Math.abs(s1.vpack - (s1.ocv - s1.ipack * s1.rpack));
  out.push({ name: '静置电压恒等式残差', got: r1.toExponential(2), want: '<1e-9', pass: r1 < 1e-9 });
  setMode('high'); runSteps(300, 0.1);
  let s2 = getStats();
  const r2 = Math.abs(s2.vpack - (s2.ocv - s2.ipack * s2.rpack));
  out.push({ name: '负载电压恒等式残差', got: r2.toExponential(2), want: '<1e-9', pass: r2 < 1e-9 });
  out.push({ name: '电芯数量', got: sim.cells.length, want: 72, pass: sim.cells.length === 72 });
  out.push({ name: '结构层数', got: LAYERS.length, want: 12, pass: LAYERS.length === 12 });
  const q1000 = CFG.kCyc * Math.pow(1000, CFG.zCyc) * 100;
  out.push({ name: '1000 循环衰减 %', got: +q1000.toFixed(1), want: '≈20.1', pass: Math.abs(q1000 - 20.1) < 0.5 });
  const pass = out.every(o => o.pass);
  return { pass: pass, checks: out };
}

/* ---------- 模块加载即初始化 ----------
   浏览器端这一步由 part3 的 boot() 承担；Node 侧没有 boot，必须自己建。 */
buildCells();
resetSim();

/* ---------- 导出 ---------- */
module.exports = {
  CFG, LAYERS, COLOR_MODES, MODES, MODULES, sim, Cell,
  VNOM_PACK, VMAX_PACK, VMIN_PACK,
  ocvOf, buildCells, stepSim, updateExtremes, computeLimits,
  resetSim, getStats, setMode, setPump, setCoolant, runSteps,
  cellById, cellInfo, listCells, runTest, runSweep, selfCheck,
  alarms, test, sweep,
};

/* 允许直接执行做自检: node agh-bridge/sim-core.js */
if (require.main === module) {
  const r = selfCheck();
  console.log('\n[sim-core] 自检\n');
  for (const c of r.checks) {
    console.log('  ' + (c.pass ? '[OK]  ' : '[FAIL]') + ' ' + String(c.name).padEnd(22) + ' 实测=' + c.got + '  期望=' + c.want);
  }
  console.log('\n  结论: ' + (r.pass ? 'PASS —— 内核与浏览器端一致' : 'FAIL —— 内核与 part1 不同步，重跑 build-simcore.js 或检查 part1'));
  process.exit(r.pass ? 0 : 1);
}
