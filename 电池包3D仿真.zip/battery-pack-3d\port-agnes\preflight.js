#!/usr/bin/env node
/* 环境自检：跑一下就知道迁移到 Agnes Harness 还缺什么。
   用法: node port-agnes/preflight.js            (可读报告)
         node port-agnes/preflight.js --json     (机器可读)
*/
'use strict';
const fs = require('fs'), path = require('path'), cp = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const R = [];
/* level: 'fail' 计入阻塞项；'warn' 仅提示，不影响是否就绪 */
function add(name, ok, val, fix, level) {
  R.push({ name, ok, val, fix: ok ? '' : (fix || ''), level: level || (ok ? 'ok' : 'fail') });
}

/* ---------- 版本比较 ---------- */
function vge(a, b) {
  const pa = String(a).replace(/^v/, '').split('.').map(Number);
  const pb = String(b).replace(/^v/, '').split('.').map(Number);
  for (let i = 0; i < 3; i++) { if ((pa[i] || 0) > (pb[i] || 0)) return true; if ((pa[i] || 0) < (pb[i] || 0)) return false; }
  return true;
}
function tryExec(cmd, args) {
  /* 绝对路径（可能含空格，如 C:\Program Files\...）→ 直连，不要用 shell，否则空格会被拆开。
     裸命令名（npm / pnpm / git）→ Windows 下它们是 .cmd，必须走 shell 才能解析。 */
  const isPath = /[\\/]/.test(cmd) || /^[A-Za-z]:/.test(cmd);
  const useShell = process.platform === 'win32' && !isPath;
  const base = { encoding: 'utf8', timeout: 15000, windowsHide: true, shell: useShell };
  try {
    let r = cp.spawnSync(cmd, args, base);
    if (r.error || r.status !== 0) {
      /* 回退 1：裸名补 .cmd；回退 2：换 shell 开关 */
      if (process.platform === 'win32' && !/\.cmd$/i.test(cmd)) {
        r = cp.spawnSync(cmd + '.cmd', args, base);
      }
      if (r.error || r.status !== 0) {
        r = cp.spawnSync(cmd, args, Object.assign({}, base, { shell: !useShell }));
      }
    }
    return (r.error || r.status !== 0) ? null : (r.stdout || '').trim().split(/\r?\n/)[0].trim();
  } catch (e) { return null; }
}

/* ---------- 1. Node（AGH 要求 >= 24.10） ---------- */
const CANDIDATES = [
  { tag: '系统 Node', p: 'C:\\Program Files\\nodejs\\node.exe' },
  { tag: 'PATH node', p: 'node' },
  { tag: '托管 Node', p: process.execPath },
];
let bestNode = null;
const found = [];
for (const c of CANDIDATES) {
  const v = tryExec(c.p, ['-v']);
  if (!v) continue;
  const ok = vge(v, '24.10.0');
  found.push({ tag: c.tag, v, ok, p: c.p });
  if (!bestNode || (ok && !bestNode.ok)) bestNode = { tag: c.tag, v, ok, p: c.p };
}
/* 只要有一个 Node >= 24.10 就够 —— 其余仅作信息，不算阻塞 */
if (bestNode && bestNode.ok) {
  add('Node (>=24.10)', true, bestNode.v + '  ' + bestNode.tag);
  for (const f of found) if (!f.ok) add('  · 其它 Node ' + f.tag, true, f.v + '（版本偏低，AGH 用不上但无害）');
} else {
  add('Node (>=24.10)', false, bestNode ? bestNode.v + '（全部低于 24.10）' : '未找到',
    '安装 Node.js 24 LTS，并让 PATH 指向它（托管版 22.x 不满足 AGH）');
}

/* ---------- 2. pnpm / npm / git ---------- */
const pnpm = tryExec('pnpm', ['-v']);
add('pnpm', !!pnpm && vge(pnpm, '10.34.5'), pnpm || '未安装',
  'npm i -g pnpm@10.34.5  （AGH 用 pnpm --frozen-lockfile 构建）');
const npm = tryExec('npm', ['-v']);
add('npm', !!npm, npm || '未安装', '随 Node 附带，若缺失重装 Node');
const git = tryExec('git', ['--version']);
add('git', !!git, git || '未安装', '安装 Git 用于 clone agnes-harness');

/* ---------- 3. Chrome（verify.js 依赖） ---------- */
const CHROME = [
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
];
const chrome = CHROME.find(p => fs.existsSync(p));
add('无头浏览器', !!chrome, chrome || '未找到', '安装 Chrome —— verify.js 靠它做数值与视觉验收');

/* ---------- 4. 本工程源码完整性 ---------- */
const NEED = [
  ['src/app.part1.js', '配置 + 仿真层'],
  ['src/app.part2.js', '三维建模层'],
  ['src/app.part3.js', '交互与界面层'],
  ['src/index.html', 'HTML 模板'],
  ['build.js', '打包脚本'],
  ['tools/verify.js', '自动验收器'],
  ['tools/init.js', '脚手架生成器'],
  ['vendor/three.module.js', 'three.js r160'],
  ['vendor/OrbitControls.js', '轨道控制器'],
  ['battery-pack-3d.html', '打包产物'],
];
for (const [f, desc] of NEED) {
  const p = path.join(ROOT, f);
  const ex = fs.existsSync(p);
  const sz = ex ? (fs.statSync(p).size / 1024).toFixed(0) + ' KB' : '缺失';
  add(desc + ' (' + f + ')', ex, sz, '从原工程补齐 ' + f);
}

/* 分片行数 —— 仅警告。
   500 行是「单次写入」的截断红线，不是文件大小上限：
   文件经多次 Edit 累积超过 500 行完全正常（本工程就是）。
   真正要防的是：新写一片时一次性输出超过 500 行。 */
for (const f of ['src/app.part1.js', 'src/app.part2.js', 'src/app.part3.js']) {
  const p = path.join(ROOT, f);
  if (!fs.existsSync(p)) continue;
  const n = fs.readFileSync(p, 'utf8').split('\n').length;
  add('分片行数 ' + path.basename(f), n < 500, n + ' 行',
    n < 500 ? '' : '现状可接受（累积所致）。但若让 AI 整片重写此文件，须先拆成 part4/part5 再写',
    n < 500 ? 'ok' : 'warn');
}

/* ---------- 5. 网络（DeepSeek API / GitHub） ---------- */
function reach(url) {
  try {
    const r = cp.spawnSync('curl', ['-s', '-o', '/dev/null', '-w', '%{http_code}', '--max-time', '12', url],
      { encoding: 'utf8', timeout: 20000, windowsHide: true });
    return r.stdout ? r.stdout.trim() : 'ERR';
  } catch (e) { return 'ERR'; }
}
const ds = reach('https://api.deepseek.com');
add('DeepSeek API 可达', ds !== 'ERR' && ds !== '000', 'HTTP ' + ds,
  '检查网络或代理；V4 Pro 通过 OpenAI 兼容端点调用');
const gh = reach('https://github.com');
add('GitHub 可达', gh !== 'ERR' && gh !== '000', 'HTTP ' + gh, '需要 clone agnes-harness');

/* ---------- 输出 ---------- */
const fail = R.filter(r => !r.ok && r.level !== 'warn');
const warn = R.filter(r => !r.ok && r.level === 'warn');
if (process.argv.includes('--json')) {
  console.log(JSON.stringify({ ok: fail.length === 0, blocking: fail, warnings: warn, checks: R }, null, 2));
  process.exit(fail.length ? 1 : 0);
}
console.log('');
console.log('══════ Agnes Harness 迁移环境自检 ══════');
console.log('工程根目录: ' + ROOT);
console.log('');
for (const r of R) {
  const tag = r.ok ? '[OK]  ' : (r.level === 'warn' ? '[注意]' : '[缺失]');
  const pad = r.name.padEnd(34);
  console.log('  ' + tag + ' ' + pad + ' : ' + r.val);
}
console.log('');
if (bestNode) {
  console.log('  建议用于 AGH 的 Node: ' + bestNode.tag + ' (' + bestNode.v + ') ' + bestNode.p);
  if (!bestNode.ok) console.log('  ⚠ 该版本低于 AGH 要求的 24.10');
}
console.log('');
if (warn.length) {
  console.log('  ⚠ 注意事项（不阻塞）：');
  for (const w of warn) console.log('     · ' + w.name + ' → ' + (w.fix || w.val));
  console.log('');
}
if (fail.length === 0) {
  console.log('  ✅ 环境就绪，可以按 port-agnes/README.md 的 Step 0 开始装 AGH。');
} else {
  console.log('  ❌ 有 ' + fail.length + ' 项待处理：');
  for (const f of fail) console.log('     · ' + f.name + ' → ' + (f.fix || '需处理'));
}
console.log('');
console.log('  提示：DeepSeek V4 Pro 北京时 18:00–次日 09:00 为谷时（半价），');
console.log('        长任务排在该时段可省约 4 倍成本。');
console.log('');
process.exit(fail.length ? 1 : 0);
