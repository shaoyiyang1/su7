/* 构建：把 three.js + OrbitControls + 应用代码内联进单文件 HTML（离线双击可用） */
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const read = p => fs.readFileSync(path.join(ROOT, p), 'utf8');

/* ---------- 1. three.js：把结尾的 export 语句改成 return，包进 IIFE ---------- */
let three = read('vendor/three.module.js');
const exportRe = /^export\s*\{([\s\S]*?)\};\s*$/m;
const m = three.match(exportRe);
if (!m) throw new Error('未找到 three.js 的 export 语句');
const names = m[1].split(',').map(s => s.trim()).filter(Boolean);
three = three.replace(exportRe, '');
const threeIife =
  'window.THREE = (function(){\n' + three +
  '\nreturn {' + names.map(n => n + ':' + n).join(',') + '};\n})();\n';

/* ---------- 2. OrbitControls：去掉 import/export，从全局 THREE 解构 ---------- */
let oc = read('vendor/OrbitControls.js');
const imp = oc.match(/import\s*\{([\s\S]*?)\}\s*from\s*'three';/);
if (!imp) throw new Error('未找到 OrbitControls 的 import 语句');
const impNames = imp[1].split(',').map(s => s.trim()).filter(Boolean);
oc = oc.replace(imp[0], 'const {' + impNames.join(',') + '} = THREE;');
oc = oc.replace(/^export\s*\{[\s\S]*?\};\s*$/m, '');
const ocIife = '(function(){\n' + oc + '\nTHREE.OrbitControls = OrbitControls;\n})();\n';

/* ---------- 3. 应用代码 ---------- */
const app = ['src/app.part1.js', 'src/app.part2.js', 'src/app.part3.js']
  .map(read).join('\n\n');

/* ---------- 4. 组装 ---------- */
let html = read('src/index.html');
if (html.indexOf('/*__APP_JS__*/') < 0) throw new Error('模板缺少 APP_JS 占位符');
const bundle =
  '/* ===== three.js r' + (three.match(/const REVISION = '([^']+)'/) || [, '?'])[1] + ' (MIT) ===== */\n' +
  threeIife + '\n' + ocIife + '\n' +
  '/* ===== 应用代码 ===== */\n' + app;

html = html.replace('/*__APP_JS__*/', () => bundle);

const out = path.join(ROOT, 'battery-pack-3d.html');
fs.writeFileSync(out, html, 'utf8');
console.log('✓ 输出：' + out);
console.log('  大小：' + (fs.statSync(out).size / 1024).toFixed(0) + ' KB');
console.log('  应用代码行数：' + app.split('\n').length);
