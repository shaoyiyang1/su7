#!/usr/bin/env node
/* =========================================================================
   AGH 闭环演示 —— 同时充当「运行与验证证据」

   模拟一个完整的智能体任务闭环：
     任务（诊断并处置过热）→ 工具调用 → 执行反馈 → 结果验证 → 异常处理 → 复检

   用法: node tools/mcp-demo.js [输出文件]
   默认输出: agh-bridge/DEMO-OUTPUT.md

   ⚠ 这个脚本直接 spawn MCP 服务并走真实 JSON-RPC，不是伪造的日志。
   ========================================================================= */
'use strict';
const cp = require('child_process'), fs = require('fs'), path = require('path');

const ROOT = path.resolve(__dirname, '..');
const SERVER = path.join(ROOT, 'agh-bridge', 'server.js');
const OUT = process.argv[2] || path.join(ROOT, 'agh-bridge', 'DEMO-OUTPUT.md');

const p = cp.spawn(process.execPath, [SERVER], { stdio: ['pipe', 'pipe', 'pipe'] });
let buf = '';
const pending = new Map();
let seq = 0;

p.stdout.setEncoding('utf8');
p.stdout.on('data', c => {
  buf += c; let i;
  while ((i = buf.indexOf('\n')) >= 0) {
    const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
    if (!line) continue;
    try {
      const o = JSON.parse(line);
      if (o.id && pending.has(o.id)) { pending.get(o.id)(o); pending.delete(o.id); }
    } catch (e) { /* ignore */ }
  }
});
p.stderr.on('data', () => { });   /* server 的启动提示走 stderr，不干扰 stdout 解析 */

function rpc(method, params) {
  const id = ++seq;
  return new Promise(res => {
    pending.set(id, res);
    p.stdin.write(JSON.stringify({ jsonrpc: '2.0', id, method, params }) + '\n');
    setTimeout(() => { if (pending.has(id)) { pending.get(id)({ error: 'timeout' }); pending.delete(id); } }, 120000);
  });
}
async function call(name, args) {
  const r = await rpc('tools/call', { name, arguments: args || {} });
  if (r.error) return { ok: false, err: JSON.stringify(r.error) };
  const c = r.result && r.result.content && r.result.content[0];
  try { return JSON.parse(c.text); } catch (e) { return { raw: c && c.text }; }
}

/* ---------------- 记录 ---------------- */
const L = [];
function say(s) { L.push(s); process.stderr.write(s + '\n'); }
function kv(o, keys) {
  return keys.filter(k => o[k] !== undefined && o[k] !== null).map(k => k + '=' + o[k]).join(', ');
}

(async function main() {
  await rpc('initialize', {});
  await rpc('tools/list', {});   /* 触发 notifications 流程 */

  say('## 场景：赛道持续 2C 放电后电池包过热 —— 智能体诊断与处置\n');
  say('> 以下每一步都是通过 MCP 协议真实调用仿真内核产生的结果，非人工填写。\n');

  /* 1. 复位 */
  let r = await call('pack_reset');
  say('**步骤 1 · pack_reset（建立可复现起点）**');
  say('```\n' + JSON.stringify(r) + '\n```\n');

  /* 2. 施加压力工况 */
  r = await call('pack_step', { mode: 'track', steps: 9000, dt: 0.1 });
  const st1 = r.status;
  say('**步骤 2 · pack_step（赛道工况，推进 900 s）**');
  say('反馈：t=' + st1.t_s + ' s，SOC=' + st1.soc_pct + '%，最高温度=' + st1.temperature.max_C +
    ' ℃，温差=' + st1.temperature.delta_K + ' K，放电峰值功率=' + st1.sop.discharge_peak_kW +
    ' kW，主导限制=' + st1.sop.limiting_discharge + '，降额系数=' + st1.derate_factor + '\n');

  /* 3. 体检 → 发现异常 */
  r = await call('pack_health_report');
  const verdict1 = r.conclusion, issues1 = r.issues.length;
  say('**步骤 3 · pack_health_report（发现异常）**');
  say('结论：**' + verdict1 + '**，问题项 ' + issues1 + ' 条');
  (r.issues || []).forEach(i => say('  - [' + i.level + '] ' + i.item + ' = ' + i.value + '（限值 ' + i.limit + '）— ' + i.note));
  say('\n建议：');
  (r.advice || []).forEach(a => say('  - ' + a));
  say('');

  /* 4. 定位最热单体 */
  const hotList = await call('cell_list');
  let hottest = null;
  (hotList.cells || []).forEach(c => { if (!hottest || c.T_C > hottest.T_C) hottest = c; });
  say('**步骤 4 · cell_list（定位异常单体）**');
  say('全包最热单体：' + hottest.id + '，温度 ' + hottest.T_C + ' ℃，电压 ' + hottest.V + ' V，内阻 ' + hottest.R_mOhm + ' mΩ\n');

  /* 5. 处置：降功率 + 强冷却（两者缺一不可 —— 实测只强冷却不降功率压不住 2C 产热） */
  r = await call('pack_set_cooling', { pump: 600, tcoolIn: 22 });
  say('**步骤 5 · pack_set_cooling（处置①：提高泵流量至 600 W/K + 冷却液入口降至 22 ℃）**');
  say('```\n' + JSON.stringify(r) + '\n```\n');

  /* 处置②：卸载到静置。热时间常数 Cth/hA ≈ 1100 s，观察窗口必须够长才能看到收敛 */
  r = await call('pack_step', { mode: 'idle', steps: 20000, dt: 0.1 });
  const st2 = r.status;
  say('**步骤 6 · pack_step（处置②：卸载至静置 + 强冷，推进 2000 s 观察收敛）**');
  say('反馈：最高温度=' + st2.temperature.max_C + ' ℃（处置前 ' + st1.temperature.max_C + ' ℃），温差=' +
    st2.temperature.delta_K + ' K（处置前 ' + st1.temperature.delta_K + ' K），单体压差=' + st2.cell_V.delta_mV +
    ' mV（处置前 ' + st1.cell_V.delta_mV + ' mV），放电峰值功率=' + st2.sop.discharge_peak_kW +
    ' kW（处置前 ' + st1.sop.discharge_peak_kW + ' kW），主导限制=' + st2.sop.limiting_discharge + '\n');

  /* 7. 复检 */
  r = await call('pack_health_report');
  say('**步骤 7 · pack_health_report（复检）**');
  say('结论：**' + r.conclusion + '**（处置前为「' + verdict1 + '」，问题项 ' + issues1 + ' → ' + r.issues.length + ' 条）');
  (r.issues || []).forEach(i => say('  - [' + i.level + '] ' + i.item + ' = ' + i.value + '（限值 ' + i.limit + '）'));
  say('');

  /* 8. 单体检测 */
  r = await call('cell_test', { cellId: hottest.id });
  say('**步骤 8 · cell_test（对最热单体做脉冲内阻辨识）**');
  say('```\n' + JSON.stringify(r) + '\n```\n');

  /* 9. 全芯扫描 */
  r = await call('pack_sweep');
  say('**步骤 9 · pack_sweep（全 72 只电芯一致性扫描）**');
  say('均值 ' + r.mean_mOhm + ' mΩ，σ=' + r.sd_mOhm + ' mΩ，CV=' + r.cv_pct + '%，极差 ' + r.range_mOhm +
    ' mΩ，评级「' + r.grade + '」，3σ 离群 ' + r.outliers_3sigma.length + ' 只\n');

  /* 10. 自洽性 */
  r = await call('self_check');
  say('**步骤 10 · self_check（证明结果可信）**');
  (r.checks || []).forEach(c => say('  - ' + (c.pass ? '✅' : '❌') + ' ' + c.name + '：实测 ' + c.got + '，期望 ' + c.want));
  say('\n内核自洽性：**' + (r.pass ? 'PASS' : 'FAIL') + '**\n');

  const md = L.join('\n');
  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  fs.writeFileSync(OUT, md, 'utf8');
  process.stderr.write('\n[demo] 已写入 ' + OUT + '\n');
  p.stdin.end();
  setTimeout(() => process.exit(0), 300);
})().catch(e => { process.stderr.write('[demo] 失败: ' + (e && e.stack || e) + '\n'); try { p.kill(); } catch (x) { } process.exit(1); });
