#!/usr/bin/env node
/* ---------------------------------------------------------------------------
 * 通用「单文件 HTML」无头验收器
 *
 * 用途：AI 写完代码后自己跑这条命令，读取结果；不通过就自行修改源码重跑，
 *       直到 PASS 才交付给用户。无需人工打开浏览器。
 *
 * 用法：
 *   node tools/verify.js <html文件> [选项]
 *     --wait 8000     等待毫秒数（虚拟时间，默认 8000）
 *     --api  NAME     检测全局对象 window[NAME] 是否存在，并尝试调用其 stats()
 *     --exec "JS"     注入自定义 JS（可用 return），结果放在 custom 字段
 *     --shot out.png  同时截图
 *     --json          输出原始 JSON（便于程序解析）
 *
 * 退出码：0 = 通过，1 = 未通过，2 = 参数/环境问题
 * ------------------------------------------------------------------------- */
const fs = require('fs');
const path = require('path');
const cp = require('child_process');

/* ---------- 参数 ---------- */
const raw = process.argv.slice(2);
const positional = raw.filter(a => !a.startsWith('--'));
function opt(name, def) {
  const i = raw.indexOf('--' + name);
  return i >= 0 && raw[i + 1] !== undefined ? raw[i + 1] : def;
}
const target = positional[0];
if (!target) {
  console.error('用法: node tools/verify.js <html文件> [--wait 8000] [--api NAME] [--exec "JS"] [--shot out.png] [--json]');
  process.exit(2);
}
const WAIT = parseInt(opt('wait', '8000'), 10);
const API = opt('api', '');
const EXEC = opt('exec', '');
const SHOT = opt('shot', '');
const AS_JSON = raw.includes('--json');

const htmlPath = path.resolve(target);
if (!fs.existsSync(htmlPath)) { console.error('[verify] 找不到文件: ' + htmlPath); process.exit(2); }

/* ---------- 找浏览器 ----------
   优先级：环境变量 CHROME_PATH > 常见安装路径 > PATH 上的可执行文件。
   换机器 / 换 OS / 换 harness 时，用 CHROME_PATH 显式指定即可，不必改代码。 */
const CANDIDATES = [];
if (process.env.CHROME_PATH) CANDIDATES.push(process.env.CHROME_PATH);
CANDIDATES.push(
  'C:/Program Files/Google/Chrome/Application/chrome.exe',
  'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
  'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
  '/usr/bin/chromium-browser',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge'
);
let BROWSER = CANDIDATES.find(p => fs.existsSync(p));
if (!BROWSER) {
  /* 最后兜底：PATH 上找 */
  for (const bin of ['google-chrome', 'chromium', 'chromium-browser', 'chrome', 'msedge']) {
    try {
      const r = cp.spawnSync(process.platform === 'win32' ? 'where' : 'which', [bin],
        { encoding: 'utf8', timeout: 8000, windowsHide: true });
      if (!r.error && r.status === 0 && r.stdout && r.stdout.trim()) { BROWSER = r.stdout.trim().split(/\r?\n/)[0].trim(); break; }
    } catch (e) { /* ignore */ }
  }
}
if (!BROWSER) {
  console.error('[verify] 未找到 Chrome / Edge。请在环境变量 CHROME_PATH 中指定浏览器绝对路径，例如：');
  console.error('        CHROME_PATH="C:/Path/To/chrome.exe" node tools/verify.js 产物.html');
  process.exit(2);
}

/* ---------- 注入探针 ---------- */
let html = fs.readFileSync(htmlPath, 'utf8');

const probe = [
  '<script>',
  'window.__VE=[];window.__VC=[];',
  "window.addEventListener('error',function(e){window.__VE.push((e.message||'?')+' @line'+(e.lineno||0));});",
  "window.addEventListener('unhandledrejection',function(e){window.__VE.push('unhandled: '+((e.reason&&e.reason.message)||e.reason));});",
  "(function(){var oe=console.error;console.error=function(){",
  "  var m=[].slice.call(arguments).map(function(x){try{return typeof x==='object'?JSON.stringify(x):String(x);}catch(_){return '?';}}).join(' ');",
  "  window.__VC.push(m);oe.apply(console,arguments);};})();",
  '</script>',
].join('\n');

const apiSnippet = API
  ? "try{var A=window['" + API + "'];if(A){r.api={keys:Object.keys(A)};" +
    "if(typeof A.stats==='function'){r.api.stats=A.stats();}" +
    "if(typeof A.step==='function'){A.step(0.1,10);r.api.afterStep=A.stats?null:null;}" +
    "}}catch(e){r.apiError=String(e&&e.message||e);}"
  : '';

const execSnippet = EXEC
  ? "try{r.custom=new Function(" + JSON.stringify(EXEC) + ")();}catch(e){r.customError=String(e&&e.message||e);}"
  : '';

const check = [
  '<script>',
  'setTimeout(function(){',
  '  var r={errors:window.__VE||[],consoleErrors:window.__VC||[],info:{}};',
  '  try{',
  "    var c=document.querySelector('canvas');",
  "    r.info.canvas=c?(c.width+'x'+c.height):null;",
  "    r.info.canvasCss=c?(Math.round(c.clientWidth)+'x'+Math.round(c.clientHeight)):null;",
  "    r.info.three=(typeof window.THREE!=='undefined')?(window.THREE.REVISION||'yes'):null;",
  '    r.info.domNodes=document.querySelectorAll("*").length;',
  '    r.info.text=document.body.innerText.slice(0,300);',
  '    ' + apiSnippet,
  '    ' + execSnippet,
  "  }catch(e){r.fatal=String((e&&e.message)||e);}",
  "  document.title='VRFY'+JSON.stringify(r);",
  '},' + WAIT + ');',
  '</script>',
].join('\n');

const headIdx = html.search(/<head[^>]*>/i);
html = headIdx >= 0
  ? html.slice(0, headIdx) + '<head>' + probe + html.slice(headIdx + html.match(/<head[^>]*>/i)[0].length)
  : probe + html;
const bodyIdx = html.lastIndexOf('</body>');
html = bodyIdx >= 0 ? html.slice(0, bodyIdx) + check + html.slice(bodyIdx) : html + check;

const tmpDir = path.join(os_tmp(), 'verify-' + Date.now());
fs.mkdirSync(tmpDir, { recursive: true });
const tmpFile = path.join(tmpDir, 't.html');
fs.writeFileSync(tmpFile, html, 'utf8');

function os_tmp() {
  return process.env.TEMP || process.env.TMP || require('os').tmpdir();
}

/* ---------- 运行无头浏览器 ---------- */
const fileUrl = 'file:///' + tmpFile.replace(/\\/g, '/');
const args = [
  '--headless=new', '--no-sandbox', '--disable-dev-shm-usage',
  '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader',
  '--allow-file-access-from-files',
  '--virtual-time-budget=' + (WAIT + 4000),
  '--window-size=1440,900',
  '--dump-dom',
];
if (SHOT) args.push('--screenshot=' + path.resolve(SHOT));

function runBrowser() {
  return new Promise(function (resolve) {
    let out = '', err = '';
    let p;
    try { p = cp.spawn(BROWSER, args.concat([fileUrl]), { windowsHide: true }); }
    catch (e) { resolve({ stdout: '', stderr: '', error: e }); return; }
    const timer = setTimeout(function () {
      try { p.kill(); } catch (e) {}
      resolve({ stdout: out, stderr: err, error: new Error('浏览器超时（240s）') });
    }, 240000);
    p.stdout.on('data', function (d) { out += d.toString(); });
    p.stderr.on('data', function (d) { err += d.toString(); });
    p.on('error', function (e) { clearTimeout(timer); resolve({ stdout: out, stderr: err, error: e }); });
    p.on('close', function () { clearTimeout(timer); resolve({ stdout: out, stderr: err }); });
  });
}

runBrowser().then(function (res) {
const dom = res.stdout || '';
const m = dom.match(/<title>VRFY([\s\S]*?)<\/title>/);

if (!m) {
  console.log('[verify] 未取到探针结果（页面可能崩溃或超时）');
  console.log('[verify] stdout 长度 = ' + dom.length);
  if (res.error) console.log('[verify] spawn error: ' + res.error.message);
  if (res.stderr) console.log('[verify] stderr: ' + String(res.stderr).slice(0, 600));
  if (dom) console.log('[verify] dom 片段: ' + dom.slice(0, 300));
  if (AS_JSON) console.log(JSON.stringify({ ok: false, reason: 'no-probe', stderr: String(res.stderr || '').slice(0, 600) }));
  process.exit(1);
}

let r;
try { r = JSON.parse(m[1]); }
catch (e) { console.log('[verify] 探针结果解析失败: ' + m[1].slice(0, 400)); process.exit(1); }

/* ---------- 判定 ---------- */
const hardErrors = r.errors.filter(e => !/favicon|Failed to load resource/i.test(e));
const ok = hardErrors.length === 0
  && !r.fatal
  && !!r.info.canvas
  && r.info.canvas !== '0x0'
  && r.info.three !== null;

const out = {
  ok: ok,
  file: htmlPath,
  errors: hardErrors,
  consoleErrors: r.consoleErrors,
  fatal: r.fatal || null,
  info: r.info,
  api: r.api || null,
  apiError: r.apiError || null,
  custom: r.custom !== undefined ? r.custom : null,
  customError: r.customError || null,
  shot: SHOT ? path.resolve(SHOT) : null,
};

if (AS_JSON) {
  console.log(JSON.stringify(out, null, 2));
} else {
  console.log('='.repeat(60));
  console.log('验收对象: ' + htmlPath);
  console.log('结果:     ' + (ok ? 'PASS' : 'FAIL'));
  console.log('-'.repeat(60));
  console.log('three.js:      ' + (r.info.three || '缺失'));
  console.log('canvas:        ' + (r.info.canvas || '缺失') + '  (CSS ' + (r.info.canvasCss || '-') + ')');
  console.log('DOM 节点数:    ' + r.info.domNodes);
  console.log('JS 运行时错误: ' + hardErrors.length);
  hardErrors.slice(0, 10).forEach(e => console.log('   ! ' + e));
  console.log('console.error: ' + (r.consoleErrors || []).length);
  (r.consoleErrors || []).slice(0, 10).forEach(e => console.log('   ! ' + e));
  if (r.fatal) console.log('致命异常: ' + r.fatal);
  if (r.api) {
    console.log('调试接口:      ' + r.api.keys.join(', '));
    if (r.api.stats) console.log('stats():       ' + JSON.stringify(r.api.stats).slice(0, 400));
  }
  if (r.apiError) console.log('接口调用异常:  ' + r.apiError);
  if (r.custom !== undefined) console.log('自定义探针:    ' + JSON.stringify(r.custom));
  if (r.customError) console.log('自定义探针异常:' + r.customError);
  if (SHOT) console.log('截图:          ' + path.resolve(SHOT));
  console.log('='.repeat(60));
}

try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch (e) {}
process.exit(ok ? 0 : 1);
});
