#!/usr/bin/env node
/* =========================================================================
   电池包数字孪生 —— MCP 服务（stdio，JSON-RPC 2.0，零外部依赖）

   作用：把电热仿真内核暴露成一组工具，供 Agnes Harness（AGH）通过 MCP 连接。
   这样 Agnes 模型就能真正"操作"这个电池包数字孪生体：
       任务规划 → 工具调用 → 执行反馈 → 结果验证 → 异常处理
   而不是只生成一段代码。

   启动: node agh-bridge/server.js
   自检: echo '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | node agh-bridge/server.js

   ⚠ stdout 只允许输出 JSON-RPC 报文，日志一律走 stderr。
   ========================================================================= */
'use strict';
const S = require('./sim-core.js');

/* ---------------- 工具定义 ---------------- */
const TOOLS = [
  {
    name: 'pack_status',
    description: '读取电池包当前全量状态：SOC、SOH(容量/内阻/功率三口径)、标称电压、开路电压OCV、端电压、包电阻、电流、功率、单体电压极值、温度极值、SOP充放电功率限值及主导限制因素、累计吞吐、最近报警。',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'pack_reset',
    description: '将电池包复位到确定性初始状态（固定随机种子，保证可复现）。',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'pack_step',
    description: '推进仿真若干步。默认步长 0.1 s（与前端主循环一致）。可同时切换工况。',
    inputSchema: {
      type: 'object',
      properties: {
        steps: { type: 'integer', description: '推进步数，1~200000', default: 100 },
        dt: { type: 'number', description: '步长（秒），默认 0.1', default: 0.1 },
        mode: { type: 'string', description: '可选，同时切换工况：idle/city/high/cltc/accel/track/charge' },
      },
      additionalProperties: false,
    },
  },
  {
    name: 'pack_set_cooling',
    description: '设定冷却回路参数。pump=0 即冷却失效（可用于注入热故障）；tcoolIn 可设为极端温度以模拟高温/低温环境。',
    inputSchema: {
      type: 'object',
      properties: {
        tcoolIn: { type: 'number', description: '冷却液入口温度 ℃' },
        pump: { type: 'number', description: '泵热容流率 W/K，0 = 停泵' },
      },
      additionalProperties: false,
    },
  },
  {
    name: 'cell_list',
    description: '列出电芯。可按模组过滤，返回每只电芯的电压/OCV/SOC/温度/内阻。',
    inputSchema: {
      type: 'object',
      properties: { module: { type: 'string', description: '模组 id，如 M1..M6；留空返回全部 72 只' } },
      additionalProperties: false,
    },
  },
  {
    name: 'cell_inspect',
    description: '查看单只电芯详情，并给出它与包内均值/极值的相对位置（判断是否为异常单体）。',
    inputSchema: {
      type: 'object', properties: { cellId: { type: 'string', description: '电芯 id，如 M3-C05' } },
      required: ['cellId'], additionalProperties: false,
    },
  },
  {
    name: 'cell_test',
    description: '对指定电芯施加 25 A / 600 ms 恒流脉冲，按 R=ΔV/ΔI 在线辨识直流内阻，并与模型内阻比对（含采样噪声）。相当于台架上的 DCIR 测试。',
    inputSchema: {
      type: 'object', properties: { cellId: { type: 'string', description: '电芯 id，如 M3-C05' } },
      required: ['cellId'], additionalProperties: false,
    },
  },
  {
    name: 'pack_sweep',
    description: '对全部 72 只电芯依次执行内阻扫描，输出均值/标准差/变异系数CV/极差/3σ 离群单体/一致性评级。',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'pack_health_report',
    description: '生成电池包健康体检报告：电压一致性、温度一致性、SOH 三口径、SOP 可用功率、主导限制因素、活性报警，并给出综合结论等级（正常/关注/异常）与处置建议。',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'alarm_list',
    description: '读取当前报警列表（含级别 e/w/i 与发生时刻）。',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'self_check',
    description: '内核自洽性自检：断言标称电压、OCV-端电压恒等式残差、电芯数量、结构层数、老化标定系数。用于证明仿真结果可信。',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
];

/* ---------------- 工具实现 ---------------- */
function n(v, d) { return (v === null || v === undefined || !isFinite(v)) ? null : +(+v).toFixed(d === undefined ? 3 : d); }

function tStatus() {
  const s = S.getStats();
  return {
    t_s: n(s.t, 1), mode: s.mode,
    soc_pct: n(s.soc * 100, 2),
    soh: { capacity_pct: n(s.sohC * 100, 3), resistance_pct: n(s.sohR * 100, 3), power_pct: n(s.sohP * 100, 3) },
    voltage: { nominal_V: n(s.vnom, 1), ocv_V: n(s.ocv, 3), terminal_V: n(s.vpack, 3), pack_R_mOhm: n(s.rpack * 1000, 2) },
    cell_V: { max: n(s.vmax, 4), min: n(s.vmin, 4), delta_mV: n(s.dv, 1) },
    temperature: { max_C: n(s.tmax, 2), min_C: n(s.tmin, 2), avg_C: n(s.tavg, 2), delta_K: n(s.dt, 2), coolant_out_C: n(s.coolOut, 2) },
    current_A: n(s.ipack, 1), power_kW: n(s.power / 1000, 2),
    sop: {
      discharge_cont_kW: n(s.sop.PdCont / 1000, 1), discharge_peak_kW: n(s.sop.PdPeak / 1000, 1),
      charge_cont_kW: n(s.sop.PcCont / 1000, 1), charge_peak_kW: n(s.sop.PcPeak / 1000, 1),
      limiting_discharge: s.sop.limD, limiting_charge: s.sop.limC,
    },
    aging: { equivalent_cycles: n(s.cycDose, 4), throughput_kAh: n(s.throughput / 1000, 4), rul_cycles: n(s.rulCyc, 0), rul_km: n(s.rulKm, 0) },
    derate_factor: n(s.derate, 3), alarm_count: s.alarms_count !== undefined ? s.alarms_count : S.alarms.length,
  };
}

function tHealth() {
  const s = S.getStats();
  const sw = S.runSweep();
  const issues = [];
  /* 低 SOC 区 OCV-SOC 曲线斜率显著变陡（本模型 0.02→0.05 区间约 4 V/SOC，
     是中段的 8 倍以上），同样的 SOC 离散会放大成更大的压差。
     真实 BMS 据此按 SOC 分段放宽阈值，这里照此处理，避免误报。 */
  const lowSoc = s.soc < 0.20;
  const dvErr = lowSoc ? 180 : 100, dvWarn = lowSoc ? 90 : 50;
  const dvNote = lowSoc ? '（当前 SOC ' + n(s.soc * 100, 1) + '%，处于 OCV 陡峭区，阈值按 BMS 惯例放宽至 ' + dvErr + ' mV）' : '';
  if (s.dv > dvErr) issues.push({ level: 'e', item: '单体压差', value: n(s.dv, 1) + ' mV', limit: '≤' + dvErr + ' mV' + dvNote, note: '压差过大，存在一致性劣化或单体异常' });
  else if (s.dv > dvWarn) issues.push({ level: 'w', item: '单体压差', value: n(s.dv, 1) + ' mV', limit: '≤' + dvErr + ' mV' + dvNote, note: '压差偏高' + (lowSoc ? '，但受低 SOC 区 OCV 斜率放大影响，建议充电至中段 SOC 后复测' : '，建议关注') });
  if (s.dt > 8) issues.push({ level: 'e', item: '温差', value: n(s.dt, 2) + ' K', limit: '≤8 K', note: '温差过大，检查液冷回路与流量' });
  if (s.tmax > 50) issues.push({ level: 'e', item: '最高温度', value: n(s.tmax, 2) + ' ℃', limit: '≤50 ℃（报警）/60 ℃（故障）', note: '过温，已触发功率降额' });
  if (s.sohC < 0.8) issues.push({ level: 'e', item: 'SOH-C', value: n(s.sohC * 100, 2) + ' %', limit: '≥80 %', note: '已达容量寿命终止 EOL' });
  /* 电芯内阻出厂离散 σ=4%（CFG.resFactor），叠加包内温度梯度后 5~6% 属正常工况表现，
     因此判异常阈值取 8% 而不是 4%，避免把固有离散误报成故障。 */
  const cv = sw.cv_pct;
  if (cv > 8) issues.push({ level: 'w', item: '内阻一致性 CV', value: cv + ' %', limit: '≤8 %', note: '离散性显著偏大，建议排查异常单体与温度梯度' });
  const errs = S.alarms.filter(a => a.lvl === 'e');
  const level = (issues.some(i => i.level === 'e') || errs.length) ? '异常' : (issues.length ? '关注' : '正常');
  const advice = [];
  if (level === '异常') {
    advice.push('立即限制功率：当前放电峰值 ' + n(s.sop.PdPeak / 1000, 0) + ' kW、充电峰值 ' + n(s.sop.PcPeak / 1000, 0) + ' kW');
    if (s.tmax > 50) advice.push('提高冷却泵流量（当前 ' + S.sim.pump + ' W/K）并降低冷却液入口温度');
    if (s.dv > 100) advice.push('对压差极值单体执行 cell_test 做内阻辨识，定位异常单体');
    if (errs.length) advice.push('处理未恢复的 error 级报警：' + errs.slice(0, 3).map(a => a.msg).join('；'));
    if (s.soc < 0.20 && s.dv > 90) advice.push('当前处于低 SOC 区，OCV 斜率陡峭会放大大压差观感；建议充电至 50% 左右复测再判定');
  } else if (level === '关注') {
    advice.push('维持当前工况，缩短巡检间隔，关注上述指标趋势');
    if (s.soc < 0.20 && s.dv > 90) advice.push('低 SOC 区压差偏大属 OCV 斜率放大所致，建议充电至中段 SOC 后复测');
  } else {
    advice.push('状态良好，可执行计划性工况；建议定期执行 pack_sweep 跟踪一致性');
  }
  return {
    conclusion: level,
    summary: {
      soc_pct: n(s.soc * 100, 2), sohC_pct: n(s.sohC * 100, 3),
      v_delta_mV: n(s.dv, 1), t_max_C: n(s.tmax, 2), t_delta_K: n(s.dt, 2),
      sop_discharge_peak_kW: n(s.sop.PdPeak / 1000, 1), sop_charge_peak_kW: n(s.sop.PcPeak / 1000, 1),
      limiting_discharge: s.sop.limD,
    },
    consistency: { resistance_cv_pct: cv, grade: sw.grade, outliers_3sigma: sw.outliers_3sigma },
    issues: issues, active_errors: errs.length, advice: advice,
  };
}

function tInspect(cellId) {
  const c = S.cellById(cellId);
  if (!c) return { ok: false, err: '未找到电芯 ' + cellId, hint: 'id 形如 M3-C05（模组 M1~M6，序号 C01~C12）' };
  const s = S.getStats();
  const devs = [];
  if (c.V >= s.vmax - 1e-9) devs.push('当前为全包最高电压');
  if (c.V <= s.vmin + 1e-9) devs.push('当前为全包最低电压');
  if (c.T >= s.tmax - 1e-9) devs.push('当前为全包最高温度');
  if (c.T <= s.tmin + 1e-9) devs.push('当前为全包最低温度');
  return {
    ok: true,
    cell: { id: c.id, module: c.mod.id, position: 'row' + c.row + '/col' + c.col },
    voltage_V: n(c.V, 4), ocv_V: n(c.ocv, 4), soc_pct: n(c.soc * 100, 2),
    temperature_C: n(c.T, 2), R_mOhm: n(c.R * 1000, 4), R_measured_mOhm: c.Rmeas ? n(c.Rmeas * 1000, 4) : null,
    heat_W: n(c.heat, 3), throughput_Ah: n(c.throughAh, 2),
    capacity_factor: n(c.capFactor, 4), resistance_factor: n(c.resFactor, 4),
    deviation_vs_pack: {
      dV_vs_avg_mV: n((c.V - s.vpack / S.CFG.series) * 1000, 2),
      dT_vs_avg_K: n(c.T - s.tavg, 2),
      dR_vs_avg_pct: n((c.R / (s.rpack / S.CFG.series) - 1) * 100, 2),
    },
    flags: devs,
  };
}

const IMPL = {
  pack_status: () => tStatus(),
  pack_reset: () => { const s = S.resetSim(); return { ok: true, message: '已复位到确定性初始状态（种子 20261006）', soc_pct: n(s.soc * 100, 2), vpack_V: n(s.vpack, 2) }; },
  pack_step: (a) => {
    const r = {};
    if (a && a.mode) r.mode = S.setMode(a.mode);
    const steps = (a && a.steps) || 100, dt = (a && a.dt) || 0.1;
    const s = S.runSteps(steps, dt);
    r.advanced_s = n(steps * dt, 1);
    r.status = tStatus();
    return r;
  },
  pack_set_cooling: (a) => {
    const out = {};
    if (a && a.tcoolIn !== undefined) out.coolant = S.setCoolant(a.tcoolIn);
    if (a && a.pump !== undefined) out.pump = S.setPump(a.pump);
    if (!Object.keys(out).length) return { ok: false, err: '至少提供 tcoolIn 或 pump' };
    out.ok = true; return out;
  },
  cell_list: (a) => {
    const list = S.listCells(a && a.module);
    if (!list.length) return { ok: false, err: '无匹配电芯', hint: '模组 id 形如 M1..M6' };
    return { ok: true, count: list.length, cells: list.map(c => ({ id: c.id, V: n(c.V, 4), soc_pct: n(c.soc * 100, 2), T_C: n(c.T, 2), R_mOhm: n(c.R * 1000, 4) })) };
  },
  cell_inspect: (a) => tInspect(a && a.cellId),
  cell_test: (a) => { const r = S.runTest(a && a.cellId); return r; },
  pack_sweep: () => S.runSweep(),
  pack_health_report: () => tHealth(),
  alarm_list: () => ({ count: S.alarms.length, alarms: S.alarms.slice(0, 20).map(a => ({ t: n(a.t, 1), lvl: a.lvl, msg: a.msg })) }),
  self_check: () => S.selfCheck(),
};

/* ---------------- JSON-RPC ---------------- */
let buf = '';
function send(obj) { process.stdout.write(JSON.stringify(obj) + '\n'); }

function handle(msg) {
  const { id, method, params } = msg || {};
  if (method === 'initialize') {
    return send({ jsonrpc: '2.0', id, result: { protocolVersion: '2024-11-05', capabilities: { tools: {} }, serverInfo: { name: 'battery-pack-digital-twin', version: '1.0.0' } } });
  }
  if (method === 'notifications/initialized' || (method || '').startsWith('notifications/')) return;
  if (method === 'tools/list') return send({ jsonrpc: '2.0', id, result: { tools: TOOLS } });
  if (method === 'tools/call') {
    const name = params && params.name, args = (params && params.arguments) || {};
    const fn = IMPL[name];
    if (!fn) return send({ jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: JSON.stringify({ ok: false, err: '未知工具: ' + name, available: Object.keys(IMPL) }) }], isError: true } });
    try {
      const r = fn(args);
      return send({ jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: JSON.stringify(r, null, 2) }] } });
    } catch (e) {
      return send({ jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: JSON.stringify({ ok: false, err: String(e && e.message || e), stack: String(e && e.stack || '').split('\n').slice(0, 3) }) }], isError: true } });
    }
  }
  if (method === 'ping') return send({ jsonrpc: '2.0', id, result: {} });
  send({ jsonrpc: '2.0', id, error: { code: -32601, message: 'Method not found: ' + method } });
}

process.stdin.setEncoding('utf8');
process.stdin.on('data', chunk => {
  buf += chunk;
  let i;
  while ((i = buf.indexOf('\n')) >= 0) {
    const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
    if (!line) continue;
    try { handle(JSON.parse(line)); }
    catch (e) { /* 忽略非 JSON 行 */ }
  }
});
process.stdin.on('end', () => process.exit(0));

process.stderr.write('[battery-pack-mcp] 已启动，工具 ' + TOOLS.length + ' 个，电芯 ' + S.sim.cells.length + ' 只\n');
