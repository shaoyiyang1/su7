# 电池包数字孪生 · AGH 桥接层

把电热仿真引擎变成一个 **AGH 可调用的 MCP 工具集**，让 Agnes 模型真正"操作"电池包，
而不是只生成一段代码。

```
┌─────────────────┐   MCP (stdio, JSON-RPC 2.0)   ┌──────────────────┐
│  Agnes 模型      │ ────── tools/call ──────────▶ │  server.js       │
│  （经 AGH 调度）  │ ◀──── 结构化结果 ──────────── │  11 个工具        │
└─────────────────┘                                └────────┬─────────┘
                                                            │ require
                                                   ┌────────▼─────────┐
                                                   │  sim-core.js     │
                                                   │  纯 Node 仿真内核  │
                                                   │  72 电芯 / 12 层  │
                                                   └────────▲─────────┘
                                                            │ 自动派生
                                                   ┌────────┴─────────┐
                                                   │ src/app.part1.js │ ← 唯一真相
                                                   └──────────────────┘
```

**关键设计**：仿真逻辑只有一份真相（`src/app.part1.js`）。`sim-core.js` 由
`node tools/build-simcore.js` **自动派生**，浏览器端和 AGH 侧共用同一套物理，数值零漂移
（实测 OCV 恒等式残差两端同为 5.68e-14）。

---

## 三个文件，各司其职

| 文件 | 作用 | 是否手改 |
|---|---|---|
| `sim-core.js` | 纯 Node 仿真内核（无 three.js / 无 DOM） | ❌ 自动生成 |
| `server.js` | MCP 服务，暴露 11 个工具 | ✅ 可改 |
| `../tools/build-simcore.js` | 派生器 | ✅ 可改 |
| `../tools/mcp-demo.js` | 闭环演示 + 生成验证证据 | ✅ 可改 |
| `DEMO-OUTPUT.md` | 运行与验证证据（自动生成） | ❌ 自动生成 |

改了 `src/app.part1.js` 的仿真逻辑后，**必须**重跑：
```bash
node tools/build-simcore.js      # 重新派生内核
node agh-bridge/sim-core.js      # 内核自检
node tools/mcp-demo.js           # 重新生成验证证据
```

---

## 快速验证（不接 AGH 也能跑）

```bash
# 1. 内核自检 —— 断言物理自洽
node agh-bridge/sim-core.js
#   ✅ Vnom 266.4 / ✅ 电压恒等式残差 5.68e-14 / ✅ 72 电芯 / ✅ 12 层 / ✅ 1000 循环衰减 20.1%

# 2. MCP 工具列表
printf '{"jsonrpc":"2.0","id":1,"method":"tools/list"}\n' | node agh-bridge/server.js

# 3. 完整闭环演示（同时产出证据文档）
node tools/mcp-demo.js
```

---

## 工具清单（11 个）

| 工具 | 作用 |
|---|---|
| `pack_status` | 全量状态：SOC / SOH 三口径 / Vnom / OCV / 端电压 / 极值 / SOP / 老化 |
| `pack_reset` | 复位到确定性初始态（固定种子，可复现） |
| `pack_step` | 推进仿真（可切换工况 idle/city/high/cltc/accel/track/charge） |
| `pack_set_cooling` | 设定冷却参数（pump=0 即冷却失效，可用于注入热故障） |
| `cell_list` | 列出电芯（可按模组过滤） |
| `cell_inspect` | 单体详情 + 与包内均值/极值的偏离 |
| `cell_test` | 25 A / 600 ms 脉冲内阻辨识（等价台架 DCIR 测试） |
| `pack_sweep` | 全 72 只一致性扫描（均值/σ/CV/极差/3σ 离群/评级） |
| `pack_health_report` | 健康体检 + 结论等级 + 处置建议 |
| `alarm_list` | 报警列表 |
| `self_check` | 内核自洽性自检（证明结果可信） |

---

## 接入 AGH

AGH 支持通过 MCP 连接外部服务（见 AGH README 的 MCP 章节）。把本服务登记为一个 MCP server，
配置形态通常是：

```json
{
  "mcpServers": {
    "battery-pack-digital-twin": {
      "command": "node",
      "args": ["C:/Users/shaoyiyang/WorkBuddy/2026-10-06-13-30-56/battery-pack-3d/agh-bridge/server.js"]
    }
  }
}
```

> ⚠️ AGH 是 pre-alpha，MCP 配置的确切位置和字段以仓库文档为准。
> 配置完成后，先用一句最简单的话验证连通：
> 「调用 pack_status 告诉我电池包当前 SOC 和最高温度。」

**注意 Node 版本**：AGH 要求 Node ≥ 24.10。若 AGH 用系统版 Node 24.21 启动，
它会用同版本 spawn 本服务，没问题；若你手动拉起，请用
`C:\Program Files\nodejs\node.exe` 而不是托管版 22.x。

---

## 给 Agnes 的任务示例（体现闭环）

把这段直接作为任务发给 AGH，即可复现 `DEMO-OUTPUT.md`：

```
电池包在赛道工况下持续放电了 900 秒，请你用 MCP 工具完成以下任务：
1. 读取电池包当前状态，判断是否异常；
2. 若异常，定位到具体是哪只电芯、哪个指标超限；
3. 给出处置措施并执行（可调冷却参数、可切工况）；
4. 处置后复检，确认是否恢复到可接受区间；
5. 对最热的电芯做一次内阻辨识，再对全包做一次一致性扫描；
6. 最后运行 self_check 证明你的结论所依据的仿真是可信的，并给出总结报告。
```

这条任务链正好覆盖赛事评审的「任务规划 → 工具调用 → 执行反馈 → 结果验证 → 异常处理」全闭环。

---

## 已知物理现象（不是 bug，答辩可能被问到）

1. **只加强冷却不降功率，压不住 2C 产热**。2C 放电时包内产热约 11.8 kW，
   提高泵流量后散热仍略低于产热，温度会继续缓升 → 正确处置必须同时降功率。
2. **热时间常数 Cth/hA ≈ 1100 s**，所以降温观察窗口要 1000 s 以上才看得出收敛。
3. **低 SOC 区压差天然变大**：SOC 0.02→0.05 区间 OCV 斜率约 4 V/SOC（是中段的 8 倍以上），
   同样 SOC 离散会放大成更大压差。`pack_health_report` 已按 BMS 惯例在 SOC<20% 时放宽阈值至 180 mV。
4. **内阻 CV 5~6% 属正常**：电芯出厂内阻离散 σ=4%（CFG.resFactor），叠加包内温度梯度后到 5~6%，
   因此判异常阈值取 8% 而非 4%。
