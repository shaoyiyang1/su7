#!/usr/bin/env node
/* ---------------------------------------------------------------------------
 * 脚手架生成器：一句话创建新项目的可维护工程骨架
 *
 * 用法：
 *   node tools/init.js <目标目录> [--name 项目名] [--api 全局接口名]
 *
 * 生成内容：
 *   <dir>/vendor/          three.js r160（优先从本机已有工程复制，否则联网下载）
 *   <dir>/src/index.html   页面模板（含 /*__APP_JS__*​/ 占位符）
 *   <dir>/src/app.part1.js 配置 + 仿真层骨架
 *   <dir>/src/app.part2.js 三维建模层骨架
 *   <dir>/src/app.part3.js 交互与界面层骨架
 *   <dir>/build.js         打包脚本
 *   <dir>/tools/verify.js  无头验收器
 *   <dir>/SPEC.md          需求五问填空（AI 先读这个）
 *
 * 生成后 AI 的下一步：读 SPEC.md → 填 CFG 与建模函数 → node build.js
 *                     → node tools/verify.js 产物.html → 不通过就修
 * ------------------------------------------------------------------------- */
const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const argv = process.argv.slice(2);
const dir = argv.find(a => !a.startsWith('--')) || 'new-3d-app';
function opt(n, d) { const i = argv.indexOf('--' + n); return i >= 0 ? argv[i + 1] : d; }
const NAME = opt('name', path.basename(path.resolve(dir)));
const API = opt('api', 'App3D');

const SRC = path.resolve(dir);
const REF = path.resolve(__dirname, '..');           // battery-pack-3d 作为参考工程
const V = '0.160.0';

function mkdir(p) { fs.mkdirSync(p, { recursive: true }); }
function w(p, s) { const full = path.join(SRC, p); mkdir(path.dirname(full)); fs.writeFileSync(full, s, 'utf8'); console.log('  + ' + p); }

mkdir(SRC);
console.log('创建工程: ' + SRC);

/* ---------- vendor ---------- */
mkdir(path.join(SRC, 'vendor'));
const refVendor = path.join(REF, 'vendor');
const files = ['three.module.js', 'OrbitControls.js'];
files.forEach(function (f) {
  const dst = path.join(SRC, 'vendor', f);
  if (fs.existsSync(path.join(refVendor, f))) {
    fs.copyFileSync(path.join(refVendor, f), dst);
    console.log('  + vendor/' + f + '（本地复制）');
  } else {
    const url = f === 'three.module.js'
      ? 'https://unpkg.com/three@' + V + '/build/three.module.js'
      : 'https://unpkg.com/three@' + V + '/examples/jsm/controls/OrbitControls.js';
    try {
      cp.execSync('curl -sL -o "' + dst + '" ' + url, { stdio: 'ignore' });
      console.log('  + vendor/' + f + '（联网下载）');
    } catch (e) { console.log('  ! vendor/' + f + ' 下载失败，请手动放入或检查网络'); }
  }
});

/* ---------- src/index.html ---------- */
w('src/index.html', `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>${NAME} · 三维可拆解仿真</title>
<style>
  *{box-sizing:border-box}
  html,body{margin:0;height:100%;font:13px/1.6 "Segoe UI","Microsoft YaHei",sans-serif;color:#1f2937;background:#f4f6f9}
  .app{display:flex;height:100vh}
  #stage{position:relative;flex:1;min-width:0;background:#eef1f6}
  #gl{display:block;width:100%;height:100%}
  .panel{width:330px;flex:none;overflow-y:auto;padding:14px;background:#fff;border-left:1px solid #dfe3ea}
  .card{border:1px solid #e5e8ef;border-radius:10px;padding:10px 12px;margin-bottom:10px}
  .card h3{margin:0 0 8px;font-size:13px;font-weight:600;color:#334155}
  .kv{display:flex;justify-content:space-between;padding:2px 0}
  .kv b{font-weight:600;font-variant-numeric:tabular-nums}
  .row{display:flex;align-items:center;gap:8px;margin:6px 0}
  .row label{flex:none;width:76px;color:#64748b}
  input[type=range]{flex:1}
  button{padding:5px 10px;border:1px solid #cbd5e1;border-radius:6px;background:#fff;cursor:pointer}
  button:hover{background:#f1f5f9}
  .muted{color:#94a3b8}
</style>
</head>
<body>
<div class="app">
  <div id="stage"><canvas id="gl"></canvas></div>
  <div class="panel">
    <div class="card"><h3>状态</h3><div id="status" class="muted">加载中…</div></div>
    <div class="card"><h3>控制</h3><div id="controls"></div></div>
    <div class="card"><h3>选中详情</h3><div id="detail" class="muted">未选中</div></div>
    <div class="card"><h3>趋势</h3><canvas id="chart" width="300" height="120"></canvas></div>
    <div class="card"><h3>日志</h3><div id="log" class="muted"></div></div>
  </div>
</div>
<script>
/*__APP_JS__*/
</script>
</body>
</html>
`);

/* ---------- src/app.part1.js ---------- */
w('src/app.part1.js', `/* =========================================================================
   app.part1.js —— 配置 + 数据 / 仿真层
   职责：所有可调参数集中在 CFG；最小单元的数据模型；每个仿真步的推进逻辑。
   TODO：按 SPEC.md 填写 CFG，并实现 stepSim()。
   ========================================================================= */
const CFG = {
  /* --- 几何 --- */
  // TODO: 外形尺寸、单元尺寸、层数、每层单元数
  unitW: 1, unitH: 1, unitD: 1,
  rows: 3, cols: 4,
  /* --- 物理 / 业务参数 --- */
  // TODO: 写成具名常量，禁止在别处出现魔法数字
  k1: 1,
  /* --- 阈值 --- */
  warn: 0, fault: 0,
};

/* 确定性随机（保证每次打开结果一致，便于验收） */
let _s = 20260101;
function rnd() { _s = (_s * 1664525 + 1013904223) % 4294967296; return _s / 4294967296; }
function gauss() { return (rnd() + rnd() + rnd() + rnd() - 2) * 0.7071; }
function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }

/* 最小单元的数据模型 */
class Unit {
  constructor(i) {
    this.id = 'U' + String(i + 1).padStart(2, '0');
    this.value = 0;      // TODO: 主要指标
    this.value2 = 0;     // TODO: 次要指标
    this.bias = 1 + gauss() * 0.02;   // 个体差异
  }
}

const sim = {
  t: 0, playing: true, speed: 1,
  units: [],
  reset: function () {
    sim.t = 0; sim.units = [];
    for (let i = 0; i < CFG.rows * CFG.cols; i++) {
      const u = new Unit(i);
      u.value = 0; u.value2 = 0;
      sim.units.push(u);
    }
  },
};

/* 一个仿真步：固定步长推进，与渲染帧率解耦 */
function stepSim(dt) {
  sim.t += dt;
  // TODO: 在这里按 SPEC.md 的规律更新每个 unit
  for (const u of sim.units) {
    u.value = u.value;  
  }
}

sim.reset();
`);

/* ---------- src/app.part2.js ---------- */
w('src/app.part2.js', `/* =========================================================================
   app.part2.js —— 三维建模层
   职责：场景/相机/渲染器、材质、LAYERS 定义、各层 buildXxx() 建模函数。
   铁律：root → 层 Group → 子部件 Group → 单元 Mesh；几何体与材质必须复用。
   ========================================================================= */
const canvas = document.getElementById('gl');
const renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true });
renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
renderer.shadowMap.enabled = true;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0xeef1f6);
const camera = new THREE.PerspectiveCamera(38, 1, 0.5, 400);
camera.position.set(12, 10, 15);
const controls = new THREE.OrbitControls(camera, canvas);
controls.enableDamping = true;

scene.add(new THREE.HemisphereLight(0xffffff, 0x8899aa, 1.1));
const dl = new THREE.DirectionalLight(0xffffff, 1.6);
dl.position.set(12, 20, 10); dl.castShadow = true; scene.add(dl);

const root = new THREE.Group(); scene.add(root);
const layerGroups = {};

/* 材质库：同类零件共用一个材质实例 */
const MAT = {
  body: new THREE.MeshStandardMaterial({ color: 0x9aa4b2, metalness: 0.35, roughness: 0.55 }),
  dark: new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.5, roughness: 0.45 }),
  accent: new THREE.MeshStandardMaterial({ color: 0xef6a1e, metalness: 0.2, roughness: 0.5 }),
};

/* 层清单：explode = 爆炸抬升系数（外层大、底层 0） */
const LAYERS = [
  // TODO: 按 SPEC.md 从内到外列出各层
  { id: 'base',  name: '底层',   color: '#64748b', explode: 0.0 },
  { id: 'upper', name: '上层',   color: '#0284c7', explode: 2.0 },
  { id: 'cover', name: '上盖',   color: '#c7ccd6', explode: 4.0 },
];

/* 建模辅助：所有零件统一走这里，便于后期增删 */
const _box = new THREE.BoxGeometry(1, 1, 1);
function box(w, h, d, mat, x, y, z, parent, info) {
  const m = new THREE.Mesh(_box, mat);
  m.scale.set(w, h, d); m.position.set(x, y, z);
  m.castShadow = true; m.receiveShadow = true;
  if (info) m.userData = info;
  parent.add(m); return m;
}

/* TODO: 每层一个建模函数，返回/登记到 layerGroups[l.id] */
function buildBase() {
  const G = new THREE.Group(); root.add(G); layerGroups.base = G;
  box(10, 0.4, 8, MAT.body, 0, 0, 0, G, { type: 'layer', layer: 'base' });
  return G;
}
function buildUpper() {
  const G = new THREE.Group(); root.add(G); layerGroups.upper = G;
  for (let r = 0; r < CFG.rows; r++) {
    for (let c = 0; c < CFG.cols; c++) {
      box(CFG.unitW * 0.9, CFG.unitH, CFG.unitD * 0.9, MAT.dark,
        (c - (CFG.cols - 1) / 2) * CFG.unitW, 0.6, (r - (CFG.rows - 1) / 2) * CFG.unitD,
        G, { type: 'unit', unit: r * CFG.cols + c });
    }
  }
  return G;
}
function buildCover() {
  const G = new THREE.Group(); root.add(G); layerGroups.cover = G;
  box(10.2, 0.15, 8.2, MAT.body, 0, 1.6, 0, G, { type: 'layer', layer: 'cover' });
  return G;
}

function buildModel() { buildBase(); buildUpper(); buildCover(); }
`);

/* ---------- src/app.part3.js ---------- */
w('src/app.part3.js', `/* =========================================================================
   app.part3.js —— 交互与界面层
   职责：爆炸拆解、图层显隐、射线拾取、着色、仪表盘、主循环、对外调试接口。
   ========================================================================= */
const ui = { explode: 0, visible: {}, colorMode: 'struct', ghost: false };
LAYERS.forEach(l => ui.visible[l.id] = true);

/* --- 爆炸拆解：滑块值 × 每层系数，写进 Group.position.y（不做真切割） --- */
function applyExplode() {
  LAYERS.forEach(l => { if (layerGroups[l.id]) layerGroups[l.id].position.y = ui.explode * l.explode; });
}
function applyVisibility() {
  LAYERS.forEach(l => { if (layerGroups[l.id]) layerGroups[l.id].visible = ui.visible[l.id]; });
}

/* --- 射线拾取 --- */
const ray = new THREE.Raycaster();
const ndc = new THREE.Vector2();
let selected = null;
function pickAt(cx, cy) {
  const r = canvas.getBoundingClientRect();
  ndc.x = ((cx - r.left) / r.width) * 2 - 1;
  ndc.y = -((cy - r.top) / r.height) * 2 + 1;
  ray.setFromCamera(ndc, camera);
  const hits = ray.intersectObjects(scene.children, true);
  return hits.length ? hits[0] : null;
}
canvas.addEventListener('click', function (e) {
  const h = pickAt(e.clientX, e.clientY);
  selected = h && h.object.userData && h.object.userData.type ? h.object.userData : null;
  renderDetail();
});

/* --- 着色：只改 material，不重建几何体 --- */
function applyColors() {
  // TODO: 按 ui.colorMode 把数值映射成颜色
}

/* --- 界面 --- */
function renderDetail() {
  document.getElementById('detail').textContent =
    selected ? JSON.stringify(selected) : '未选中';
}
function buildUI() {
  const c = document.getElementById('controls');
  const row = document.createElement('div');
  row.className = 'row';
  row.innerHTML = '<label>拆解</label>';
  const s = document.createElement('input');
  s.type = 'range'; s.min = 0; s.max = 100; s.value = 0;
  s.oninput = function () { ui.explode = s.value / 100; applyExplode(); };
  row.appendChild(s); c.appendChild(row);
  LAYERS.forEach(function (l) {
    const d = document.createElement('div'); d.className = 'row';
    const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = true;
    cb.onchange = function () { ui.visible[l.id] = cb.checked; applyVisibility(); };
    d.appendChild(cb); d.appendChild(document.createTextNode(l.name));
    c.appendChild(d);
  });
}

/* --- 主循环：渲染只负责画，仿真用固定步长独立推进 --- */
let lastT = performance.now(), acc = 0;
function loop(now) {
  requestAnimationFrame(loop);
  const dt = Math.min(0.06, (now - lastT) / 1000); lastT = now;
  if (sim.playing) {
    acc += dt * sim.speed;
    let guard = 0;
    while (acc >= 0.1 && guard++ < 20) { stepSim(0.1); acc -= 0.1; }
  }
  applyColors();
  controls.update();
  renderer.render(scene, camera);
}

function resize() {
  const st = document.getElementById('stage');
  camera.aspect = st.clientWidth / st.clientHeight; camera.updateProjectionMatrix();
  renderer.setSize(st.clientWidth, st.clientHeight, false);
}
window.addEventListener('resize', resize);

function boot() {
  resize(); buildModel(); buildUI();
  applyExplode(); applyVisibility();
  document.getElementById('status').textContent = '就绪';
  requestAnimationFrame(loop);
}

/* --- 对外调试接口：AI 自己验收、用户批量仿真都靠它 --- */
window.${API} = {
  sim: sim, CFG: CFG, LAYERS: LAYERS, ui: ui,
  step: function (dt, n) { for (let i = 0; i < (n || 1); i++) stepSim(dt || 0.1); },
  setExplode: function (v) { ui.explode = v; applyExplode(); },
  setLayerVisible: function (id, v) { ui.visible[id] = v; applyVisibility(); },
  reset: function () { sim.reset(); },
  stats: function () {
    let mx = -Infinity, mn = Infinity, sum = 0;
    for (const u of sim.units) { mx = Math.max(mx, u.value); mn = Math.min(mn, u.value); sum += u.value; }
    return { t: sim.t, n: sim.units.length, max: mx, min: mn, avg: sum / Math.max(1, sim.units.length) };
  },
};

boot();
`);

/* ---------- build.js / verify.js ---------- */
const refBuild = path.join(REF, 'build.js');
if (fs.existsSync(refBuild)) {
  let b = fs.readFileSync(refBuild, 'utf8');
  b = b.replace(/path\.join\(ROOT,\s*'battery-pack-3d\.html'\)/, "path.join(ROOT, '" + NAME + ".html')");
  w('build.js', b);
}
w('tools/verify.js', fs.readFileSync(path.join(__dirname, 'verify.js'), 'utf8'));

/* ---------- SPEC.md ---------- */
w('SPEC.md', `# ${NAME} · 需求说明

## 五问（AI 先读这里再动手）

| 项 | 内容 |
|---|---|
| ① 主题 | TODO |
| ② 分层（外→内） | TODO |
| ③ 最小可拆单元 | TODO |
| ④ 每单元显示指标 | TODO |
| ⑤ 指标计算规律 | TODO（没有公式就让 AI 用工程经验模型，并在 CFG 注释里标注"估算值"） |

## 工程约定

- 只改 \`src/\` 下的源码；\`${NAME}.html\` 是生成物，不要手改。
- 改完执行 \`node build.js\` 重新打包。
- 验收执行 \`node tools/verify.js ${NAME}.html --api ${API} --wait 8000\`，必须 PASS 才算完成。
- 分片写入时每片不超过 500 行，防止写入截断。

## 修改位置速查

| 想改什么 | 改哪里 |
|---|---|
| 参数、阈值、数量 | \`src/app.part1.js\` 的 CFG |
| 仿真规律 | \`src/app.part1.js\` 的 stepSim() |
| 加/删结构层 | \`src/app.part2.js\` 的 LAYERS + buildXxx() |
| 拆解、拾取、界面 | \`src/app.part3.js\` |
`);

console.log('\n完成。下一步：');
console.log('  1) 填写 ' + path.join(SRC, 'SPEC.md'));
console.log('  2) 按 SPEC 补全 src/app.part1/2/3.js');
console.log('  3) node build.js');
console.log('  4) node tools/verify.js ' + NAME + '.html --api ' + API + ' --wait 8000');
