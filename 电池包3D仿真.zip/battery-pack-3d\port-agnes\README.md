# 迁移到 Agnes Harness

> ## 🚨 重要更正（2026-10-07）
>
> 上一版我建议"接入 DeepSeek V4 Pro"。**如果你是为了参加江苏省 AI+ 黑客松，这条建议是错的，照做会被取消资格。**
>
> 赛事通知（苏智会〔2026〕60 号）第五条「技术要求」写得很死：
> - **（一）所有作品须使用 Agnes Harness（AGH）作为智能体运行与执行底座**
> - **（二）作品中的所有模型调用仅限 Agnes 模型，不得接入或调用其他厂商、品牌或第三方模型**
>
> 所以：**运行时只能走 AGH + Agnes 模型**，DeepSeek / GPT / Claude 一律不可接入作品。
> 本文下方关于 DeepSeek V4 Pro 的内容已作废，仅作技术背景保留（已加删除线）。
> 真正该怎么接、作品该怎么设计，请看 `../参赛包/README.md`。

## 结论先看

**能迁移。** 但要分清「迁移什么」——这决定成本是 0 还是几天。

| 迁移对象 | 能否 | 成本 | 说明 |
|---|---|---|---|
| **交付物**（那个 HTML） | ✅ 完全能 | **0** | 纯静态 HTML，双击即开，不依赖任何 AI 运行时。拷到哪都能跑 |
| **源码 + 改模能力** | ✅ 能 | **低** | `src/` + `build.js` + `tools/`，只需 Node，与 harness 无关 |
| **自动化生产流程** | ⚠️ 能但需重配 | **中** | 要重新喂 Skill、放行命令审批、放行 spawn Chrome |
| **一键无脑复现** | ❌ 暂时别指望 | — | AGH 仍是 pre-alpha，下面第 4 节有硬约束 |

**核心洞察：这个项目对 AI 的依赖只在"生产阶段"，不在"运行阶段"。**
所以换 harness / 换模型，影响的是"下次让 AI 改模型顺不顺"，而不是"做出来能不能用"。

---

## 1. 两个东西是什么（确认过，不是我编的）

**Agnes Harness (AGH)** — GitHub `AgnesAI-Labs/agnes-harness`，Apache-2.0，TypeScript。
面向 FDE（现场部署工程）的可插拔 agent 运行时：插件承载业务能力、Skills 记录任务方法、CLI/Web/SDK 共享同一后端会话、命令执行默认需审批。
⚠️ 当前状态：**developer preview (pre-alpha)，需从源码构建**。要求 Node.js **24.10+**、pnpm **10.34.5**、平台原生构建工具。
公开 ALE 榜单：AGH + Agnes 2.5 Pro Beta 整体通过率 21.7%。

**DeepSeek-V4-Pro-0813** — 2026-08-13 GA。MoE，总参 1.6T / 激活 49B，上下文 **1M**，最高输出 38.4 万 token，MIT 许可。
原生支持 **OpenAI Responses API** 与 Anthropic API 兼容；带 low/high/max 三档 reasoning effort。
Terminal Bench 2.1 **87.9**、DSBench-FullStack **71.1** —— 端到端开发任务能力是它的强项。

> 有意思的一点：AGH 和官方 DeepSeek Harness (dsh) **都基于 Cordis 元框架**，插件/工具模型同构。所以 V4 Pro 接进 AGH 的路径是通的，不是硬凑。

---

## 2. 你本机的环境体检（已实测）

| 依赖 | AGH 要求 | 你的机器 | 状态 |
|---|---|---|---|
| Node.js | ≥ 24.10 | **v24.21.0**（系统版） | ✅ |
| pnpm | 10.34.5 | 未安装 | ❌ 需装 |
| Git | — | 2.55.0 | ✅ |
| Chrome（验收用） | — | 已安装 | ✅ |

⚠️ 注意：托管版 Node 是 **22.22.2**，不满足 AGH。装 AGH 时**必须用系统版 `C:\Program Files\nodejs\node.exe`（24.21.0）**，别让 PATH 指向 22。

跑 `node port-agnes/preflight.js` 可随时复检。

---

## 3. 迁移步骤

### Step 0 — 装 AGH（一次性）

```bash
# 用系统版 Node 24.21.0
npm i -g pnpm@10.34.5        # 或直接 corepack enable
git clone https://github.com/AgnesAI-Labs/agnes-harness.git
cd agnes-harness
pnpm install --frozen-lockfile
pnpm --filter @agnes/cli build:local
node packages/cli/dist/local/agnes.mjs serve
# 打开输出的 loopback URL
```

> 具体命令以仓库 README 为准 —— pre-alpha 阶段命令会变，我给的是当前 README 记载的版本。

### Step 1 — 接入模型：~~DeepSeek V4 Pro~~ → **只能用 Agnes 模型**

~~AGH 通过 "AI providers" 接模型。V4 Pro 兼容 OpenAI Responses API……~~ **作废。**

按赛事技术要求（二），作品内所有模型调用**仅限 Agnes 模型**。请在 AGH 的模型配置中选择
Agnes 提供的模型（官方页面 https://agnes-ai.cn/hackathon 为准），**不要配置任何第三方
endpoint**（DeepSeek / OpenAI / Anthropic 等都不行）。

配完先让 AGH 跑一句最简单的（"读这个目录并说明结构"）确认通了，再上大任务。

> 开发阶段用别的 AI 辅助写代码本身一般不违规（规则约束的是"作品中的模型调用"，
> 且要求如实说明），但**作品运行时**必须全程走 AGH + Agnes 模型，且要在声明里写清楚。

### Step 2 — 装 Skill（这是最关键的一步）

本目录 `skill/SKILL.md` 是本项目沉淀的工作流（含全部踩过的坑）。放到 AGH 的 Skills 目录。

> ⚠️ AGH 的 Skills 具体落盘路径我没法验证（pre-alpha，文档在变）。请以 AGH 文档的 "Skills" 章节为准；文件格式 `SKILL.md` + YAML frontmatter 是通用约定，通常可直接用。

**如果 AGH 的 Skill 机制不顺，降级方案一样有效**：把 `SPEC.md` 直接贴进对话当第一轮上下文。SPEC 是完整规格，不依赖任何 harness 特性。

### Step 3 — 放行两件事（否则全自动跑不起来）

AGH **默认每条命令都要人工审批**（allow once / allow for session / deny）。这会把"AI 自己做+自己验+自己改"的循环切成碎片。

必须开 **session 级 allow**，并且确认沙箱允许：
- ✅ `node`（跑 build.js / verify.js）
- ✅ **spawn 外部进程 Chrome**（`verify.js` 靠无头 Chrome 做视觉与数值验收 —— 这是最容易被沙箱拦的一环，务必先放行并单独测一次）

### Step 4 — 复现

把 `PROMPT-启动.md` 整段粘进 AGH 任务框。然后不用管，它会自己跑：
生成骨架 → 写三片源码 → 打包 → 无头验收 → 报错自改 → 最多 8 轮 → 出验收报告。

---

## 4. 现实风险（说在前面，免得你踩）

1. **AGH 是 pre-alpha**，60 star 量级，官方自己写"Not finished. APIs, configuration, and plugin interfaces are evolving and may change"。**别拿它跑生产，只当实验。**
2. **命令审批**是最打断体验的一点，务必先配好 session allow。
3. **沙箱可能拦 Chrome**。若 `verify.js` 在无头环境下拿不到输出，先单独跑一次 `--shot` 测试，别等到第 8 轮才发现。
4. **全自动≠省 Token**。V4 Pro 跑完整复现（12 层建模 + 物理层）会消耗大量上下文，1M 窗口够用但**不便宜**。

---

## 5. 省钱：峰谷定价（这条很实在）

DeepSeek **2026-08-16 起实行峰谷定价，峰时双倍**，且 V4-Pro 缓存命中价较预览期最高涨约 1100%。

峰值时段（UTC）：`01:00–04:00` 和 `06:00–10:00`
换算**北京时间（UTC+8）**：

| 时段（北京） | 费率 |
|---|---|
| 09:00 – 12:00 | 🔴 峰值（双倍） |
| 12:00 – 14:00 | 🟢 平峰 |
| 14:00 – 18:00 | 🔴 峰值（双倍） |
| **18:00 – 次日 09:00** | 🟢 **谷时（半价）** |

**做法：把全自动复现这种长任务排在北京时间 20:00 之后跑（或 12:00–14:00 午休），避开白天工作时段。** 同样任务成本差约 4 倍。

另外：`reasoning_effort` 选 `low` 做简单改模、`high` 做建模，别全程 max。

---

## 6. 如果不想折腾 AGH —— 等价路线

坦白讲，如果你只想"换个更强的模型来复现/改模"，AGH 不是必需项：

- **路线 A（推荐）**：任何支持文件读写 + shell 的 AI 客户端（含现在的 WorkBuddy），配一个 OpenAI 兼容的 DeepSeek V4 Pro endpoint，直接把 `SPEC.md` + `skill/SKILL.md` 喂进去。效果和 AGH 几乎一样，成本低得多。
- **路线 B**：本地 `dsh`（官方 DeepSeek Harness）—— 它才是 V4 Pro 的原生搭配，且同样基于 Cordis，Skill 可复用。
- **路线 C**：`battery-pack-3d.html` 直接分发。要"复现"只是给人看的话，发这个文件就够了，零依赖。

---

## 7. 本目录清单

| 文件 | 用途 |
|---|---|
| `SPEC.md` | **复现规格全文**。换任何 AI/harness 都靠它，是最关键的文件 |
| `PROMPT-启动.md` | 可直接粘贴的启动提示词 |
| `preflight.js` | 环境自检，跑一下就知道缺什么 |
| `skill/SKILL.md` | 工作流技能（含全部踩坑），给 AGH 或任何支持 Skill 的 harness |
| `README.md` | 本文件 |

源码与工具仍在上级目录：`src/`（三片 + index.html）、`build.js`、`tools/`（init.js / verify.js）、`vendor/`（three.js 本地副本）。
