/* 只读诊断：切场景后电池是否冻结（不改动任何东西，纯观察）
 * 流程：无 hash 打开（默认 road）→ 油门采样 → transitionTo('city') → 油门采样
 *      → transitionTo('offroad') → 油门采样，每段记录
 *      samples/soc/speed/driveMode + 断言 driving.battery===SU7.battery
 */
const fs = require("fs");
const { spawn } = require("child_process");
const CHROME = "C:/Program Files/Google/Chrome/Application/chrome.exe";
const FILE = "file:///C:/Users/shaoyiyang/Desktop/su7-panel/小米SU7车模-离线驾驶版.html";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const SNAPSHOT = `(function(){
  const S = window.SU7; const d = S.driving; const m = S.battery; const bm = d && d.battery;
  return {
    kind: S.sceneManager ? S.sceneManager.currentKind : '?',
    mode: d ? d.driveMode : '?',
    mSamples: m ? m.historyTotalSamples : -1,
    bmSamples: bm ? bm.historyTotalSamples : -1,
    mSoc: m ? +m.socPct.toFixed(4) : -1,
    bmSoc: bm ? +bm.socPct.toFixed(4) : -1,
    speed: d ? +d.speed.toFixed(3) : -1,
    mSameBm: m && bm ? (d.battery === m) : 'x',
    mUp: m ? (m.__upCalls|0) : -1,
    bmUp: bm ? (bm.__upCalls|0) : -1,
    keyM: m ? m.__dbgKey : 'nomark',
    keyBm: bm ? bm.__dbgKey : 'nomark'
  };
})()`;

async function run() {
  const chrome = spawn(CHROME, [
    "--headless=new", "--no-sandbox", "--no-proxy-server",
    "--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader",
    "--remote-debugging-port=9601",
    "--user-data-dir=" + process.env.TEMP + "/_batt_freeze_" + Date.now(),
    "--window-size=1600,900", "about:blank",
  ], { stdio: "ignore" });
  let list = null;
  for (let i = 0; i < 40; i++) { await sleep(400); try { list = await fetch("http://127.0.0.1:9601/json/list").then(r => r.json()); break; } catch (e) {} }
  if (!list) { console.log("CDP 未就绪"); chrome.kill(); process.exit(2); }
  const page = list.find(t => t.type === "page") || list[0];
  const ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
  let id = 0; const pending = new Map(); const errs = [];
  ws.addEventListener("message", (e) => {
    const m = JSON.parse(e.data);
    if (m.id && pending.has(m.id)) { pending.get(m.id)(m.result); pending.delete(m.id); }
    if (m.method === "Runtime.exceptionThrown") errs.push("EXC " + (m.params.exceptionDetails.exception?.description || m.params.exceptionDetails.text).slice(0, 200));
  });
  function send(method, params) { return new Promise((res) => { const i = ++id; pending.set(i, res); ws.send(JSON.stringify({ id: i, method, params })); }); }
  async function ev(expr, to = 60000) {
    return Promise.race([send("Runtime.evaluate", { expression: expr, returnByValue: true, awaitPromise: true }).then(r => r && r.result && r.result.value), sleep(to).then(() => "TIMEOUT")]);
  }
  await send("Runtime.enable", {}); await send("Page.enable", {});
  await send("Page.navigate", { url: FILE });
  let ready = false; let su7keys = null;
  for (let i = 0; i < 40; i++) {
    await sleep(1500);
    const r = await ev(`(function(){ const S=window.SU7; if(!S) return null; return {ok: !!(S.driving&&S.battery), keys: Object.keys(S).join(',')}; })()`);
    if (r && r.ok) { ready = true; su7keys = r.keys; break; }
  }
  if (!ready) { console.log("NOT READY; last:", await ev(`window.SU7?Object.keys(window.SU7).join(','):'no SU7'`), "; errs:", errs); chrome.kill(); process.exit(3); }
  console.log("READY. SU7 keys:", su7keys);
  await sleep(1500);
  // 暴露 sceneManager 到 window（只读诊断钩子，不影响业务）
  await ev(`(function(){ const S=window.SU7; if(!S.sceneManager){ for (const k in S) { if (S[k] && S[k].transitionTo && S[k].registerCurrent && S[k].currentKind) { S.sceneManager = S[k]; break; } } } return !!S.sceneManager; })()`);
  console.log("sceneManager exposed:", await ev(`!!window.SU7.sceneManager`));

  async function sample(label) {
    const s0 = await ev(SNAPSHOT);
    await ev(`window.SU7.driving.pressW(true)`);
    await sleep(3000);
    await ev(`window.SU7.driving.pressW(false)`);
    const s1 = await ev(SNAPSHOT);
    console.log(`\n== ${label} ==`);
    console.log("  油门前:", JSON.stringify(s0));
    console.log("  油门后:", JSON.stringify(s1));
    const grewM = s1.mSamples > s0.mSamples;
    const grewBm = s1.bmSamples > s0.bmSamples;
    console.log(`  SU7.battery samples ${s0.mSamples} → ${s1.mSamples}（${grewM ? '增长 ✓' : '冻结 ✗'}），driving.battery samples ${s0.bmSamples} → ${s1.bmSamples}（${grewBm ? '增长 ✓' : '冻结 ✗'}），speed ${s0.speed} → ${s1.speed}`);
    return { s0, s1, grewM, grewBm };
  }

  // 注入探针：包裹 SU7.battery.update + 记录身份映射
  async function wrapProbe() {
    return await ev(`(function(){
      const S = window.SU7; const m = S.battery; const bm = S.driving && S.driving.battery;
      const wrap = (x) => { if (x && x.__upCalls === undefined) { x.__upCalls = 0; const o = x.update.bind(x); x.update = function(dt, d){ x.__upCalls++; return o(dt, d); }; } };
      wrap(m); wrap(bm);
      return { m: m?'ok':'null', bm: bm?'ok':'null', mSameBm: !!(m&&bm&&m===bm), mSameBase: !!(S.base&&m&&m===S.base.offroadBattery), bmSameBase: !!(S.base&&bm&&bm===S.base.offroadBattery), mUp: m?(m.__upCalls|0):-1, bmUp: bm?(bm.__upCalls|0):-1 };
    })()`);
  }
  const id1 = await wrapProbe();
  console.log("\n[探针] 场景1 前身份:", JSON.stringify(id1));

  // 场景1 先驱动一段时间（drive 模式），确认第一场景数据正常变化
  await ev(`window.SU7.setDrive(true)`);

  const a = await sample("场景1 road（油门 3s）");

  // 切到 city：用场景切换按钮（应用内切换，不刷新）
  console.log("\n-- 点击「城市」按钮 transitionTo('city') --");
  const clicked = await ev(`(function(){ const b=[...document.querySelectorAll('#scene-switch button')].find(x=>x.dataset.kind==='city'); if(!b) return 'no btn'; b.click(); return 'clicked'; })()`);
  console.log("click:", clicked);
  // 等 transitionTo 完成（淡入淡出约 0.5s）
  await sleep(2500);
  const curKind = await ev(`(function(){ const btns=[...document.querySelectorAll('#scene-switch button')]; const on=btns.find(x=>getComputedStyle(x).background.includes('90,150,255')); return on?on.dataset.kind:'unknown'; })()`);
  console.log("current scene (by active btn):", curKind);
  const b = await sample("场景2 city（油门 3s）");
  const id2 = await wrapProbe();
  console.log("\n[探针] 场景2 后身份:", JSON.stringify(id2));

  // 切回 road（验证数据延续、不清零）
  console.log("\n-- 点击「公路」按钮 transitionTo('road')（切回，验证延续）--");
  const id3pre = await wrapProbe();
  console.log("[探针] 切 road 前身份:", JSON.stringify(id3pre));
  await ev(`(function(){ const b=[...document.querySelectorAll('#scene-switch button')].find(x=>x.dataset.kind==='road'); if(b) b.click(); return 'ok'; })()`);
  await sleep(2500);
  const cKind = await sample("场景3 road（切回，油门 3s）");
  const id3 = await wrapProbe();
  console.log("\n[探针] 场景3 后身份:", JSON.stringify(id3));

  console.log("\n[总结] 三段 SU7.battery.update 调用: road 前 =" + id1.upCalls + ", city 后 =" + id2.upCalls + ", road3 后 =" + id3.upCalls);
  console.log("[总结] 三段 driving.battery.update 调用: road 前 =" + (id1.bmUpCalls|0) + ", city 后 =" + (id2.bmUpCalls|0) + ", road3 后 =" + (id3.bmUpCalls|0));
  console.log("sameBatt 断言:", JSON.stringify({ road: a.s1.mSameBm, city: b.s1.mSameBm, road2: cKind.s1.mSameBm }));
  console.log("SU7.battery soc:", a.s1.mSoc, "→", b.s1.mSoc, "→", cKind.s1.mSoc);
  console.log("driving.battery soc:", a.s1.bmSoc, "→", b.s1.bmSoc, "→", cKind.s1.bmSoc);
  console.log("SU7.battery 样本增长:", a.grewM ? 'Y':'N', b.grewM ? 'Y':'N', cKind.grewM ? 'Y':'N', "| driving.battery 样本增长:", a.grewBm ? 'Y':'N', b.grewBm ? 'Y':'N', cKind.grewBm ? 'Y':'N');

  const shot = await send("Page.captureScreenshot", { format: "png" });
  if (shot && shot.data) fs.writeFileSync("C:/Users/shaoyiyang/WorkBuddy/2026-10-03-18-03-15/agnes-harness/su7-replica/_batt_freeze.png", Buffer.from(shot.data, "base64"));
  console.log("\nERRS:", errs.slice(0, 8));
  chrome.kill(); process.exit(0);
}
run().catch(e => { console.error("FATAL", e.message); process.exit(1); });
