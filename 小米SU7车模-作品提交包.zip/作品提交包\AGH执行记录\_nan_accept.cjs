/* 最终回归验证（用户验收口径）：依次进入 road / city / offroad，每个场景踩一脚油门，
 * 采集 socPct / vPackNow / iPackNow / driving.speed，确认无 NaN、随油门变化、切场景延续。
 */
const { spawn } = require("child_process");
const CHROME = "C:/Program Files/Google/Chrome/Application/chrome.exe";
const FILE = "file:///C:/Users/shaoyiyang/Desktop/su7-panel/小米SU7车模-离线驾驶版.html";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function run() {
  const chrome = spawn(CHROME, [
    "--headless=new","--no-sandbox","--no-proxy-server",
    "--use-gl=angle","--use-angle=swiftshader","--enable-unsafe-swiftshader",
    "--remote-debugging-port=9604",
    "--user-data-dir=" + process.env.TEMP + "/_nan_accept_" + Date.now(),
    "--window-size=1600,900","about:blank",
  ], { stdio: "ignore" });
  let list = null;
  for (let i = 0; i < 40; i++) { await sleep(400); try { list = await fetch("http://127.0.0.1:9604/json/list").then(r=>r.json()); break; } catch(e){} }
  if (!list) { console.log("CDP 未就绪"); chrome.kill(); process.exit(2); }
  const page = list.find(t=>t.type==="page")||list[0];
  const ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((r,j)=>{ws.onopen=r;ws.onerror=j;});
  let id=0; const pending=new Map(); const errs=[];
  ws.addEventListener("message",(e)=>{const m=JSON.parse(e.data); if(m.id&&pending.has(m.id)){pending.get(m.id)(m.result);pending.delete(m.id);} if(m.method==="Runtime.exceptionThrown") errs.push("EXC "+(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text).slice(0,120));});
  function send(method,params){return new Promise(res=>{const i=++id;pending.set(i,res);ws.send(JSON.stringify({id:i,method,params}));});}
  async function ev(expr,to=60000){return Promise.race([send("Runtime.evaluate",{expression:expr,returnByValue:true,awaitPromise:true}).then(r=>r&&r.result&&r.result.value),sleep(to).then(()=>"TIMEOUT")]);}
  await send("Runtime.enable",{}); await send("Page.enable",{});
  await send("Page.navigate",{url:FILE});
  for(let i=0;i<40;i++){await sleep(1500); if(await ev(`!!(window.SU7&&window.SU7.driving&&window.SU7.battery)`)===true)break;}
  await sleep(1500);
  await ev(`window.SU7.setDrive(true)`);

  const fmt = (o) => o ? {
    soc: o.soc, v: o.v, i: o.i, speed: o.speed,
  } : o;
  const read = async () => ev(`(function(){
    const m = window.SU7.battery, d = window.SU7.driving;
    const n = (x)=> { const v = +x; return Number.isFinite(v) ? v : "NaN"; };
    return { soc: n(m.socPct), v: n(m.vPackNow), i: n(m.iPackNow), speed: n(d.speed),
      finite: Number.isFinite(m.socPct) && Number.isFinite(m.vPackNow) && Number.isFinite(m.iPackNow) && Number.isFinite(d.speed) };
  })()`);

  const seq = [
    ["road", null],
    ["city", "city"],
    ["offroad", "offroad"],
  ];
  const rows = [];
  for (const [label, btn] of seq) {
    if (btn) {
      await ev(`(function(){const b=[...document.querySelectorAll('#scene-switch button')].find(x=>x.dataset.kind==='${btn}');if(b)b.click();return b?'ok':'no';})()`);
      await sleep(2500);
    }
    const pre = await read();
    await ev(`window.SU7.driving.pressW(true)`);
    await sleep(3000);
    await ev(`window.SU7.driving.pressW(false)`);
    await sleep(800);
    const post = await read();
    rows.push({ label, pre: fmt(pre), post: fmt(post) });
    const changed = Math.abs(post.speed - pre.speed) > 0.3 || Math.abs(post.soc - pre.soc) > 1e-4;
    console.log(`\n== ${label} ==  finite? pre=${pre.finite} post=${post.finite}  随油门变化? ${changed?"是 ✓":"否 ✗"}`);
    console.log("  油门前:", JSON.stringify(pre));
    console.log("  油门后:", JSON.stringify(post));
  }
  const final = await read();
  const allFinite = rows.every(r => r.pre.finite !== false && r.post.finite !== false) && final.finite;
  const cont = rows.map(r => r.post.soc).concat([final.soc]);
  console.log("\n[结论] 三场景 + 终态 soc 序列:", cont.join(" → "));
  console.log(allFinite ? "全程无 NaN ✓" : "存在 NaN ✗");
  console.log("ERRS:", errs.slice(0,8));
  chrome.kill(); process.exit(allFinite ? 0 : 1);
}
run().catch(e=>{console.error("FATAL",e.message);process.exit(1);});
