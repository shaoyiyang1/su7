/* 复现路径 #2：直接以 hash 进入 #city（初始场景 = 城市，offroadBattery 由 _doSetupCity 创建并注入 driving），
 * 然后应用内切换到 offroad 再切回 road，每段踩油门，全程检测 NaN。
 */
const fs = require("fs");
const { spawn } = require("child_process");
const CHROME = "C:/Program Files/Google/Chrome/Application/chrome.exe";
const FILE = "file:///C:/Users/shaoyiyang/Desktop/su7-panel/小米SU7车模-离线驾驶版.html#city";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function run() {
  const chrome = spawn(CHROME, [
    "--headless=new","--no-sandbox","--no-proxy-server",
    "--use-gl=angle","--use-angle=swiftshader","--enable-unsafe-swiftshader",
    "--remote-debugging-port=9603",
    "--user-data-dir=" + process.env.TEMP + "/_nan_city_" + Date.now(),
    "--window-size=1600,900","about:blank",
  ], { stdio: "ignore" });
  let list = null;
  for (let i = 0; i < 40; i++) { await sleep(400); try { list = await fetch("http://127.0.0.1:9603/json/list").then(r=>r.json()); break; } catch(e){} }
  if (!list) { console.log("CDP 未就绪"); chrome.kill(); process.exit(2); }
  const page = list.find(t=>t.type==="page")||list[0];
  const ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((r,j)=>{ws.onopen=r;ws.onerror=j;});
  let id=0; const pending=new Map(); const errs=[];
  ws.addEventListener("message",(e)=>{const m=JSON.parse(e.data); if(m.id&&pending.has(m.id)){pending.get(m.id)(m.result);pending.delete(m.id);} if(m.method==="Runtime.exceptionThrown") errs.push("EXC "+(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text).slice(0,120));});
  function send(method,params){return new Promise(res=>{const i=++id;pending.set(i,res);ws.send(JSON.stringify({id:i,method,params}));});}
  async function ev(expr,to=60000){return Promise.race([send("Runtime.evaluate",{expression:expr,returnByValue:true,awaitPromise:true}).then(r=>r&&r.result&&r.result.value),sleep(to).then(()=>"TIMEOUT")]);}
  await send("Runtime.enable",{}); await send("Page.enable",{});
  await send("Page.navigate",{url:FILE});
  for(let i=0;i<40;i++){await sleep(1500); if(await ev(`!!(window.SU7&&window.SU7.driving&&window.SU7.battery)`)===true)break;}
  await sleep(2000);

  // 高频 NaN 探测：读 SOC/V/I 的 getter，任何一帧非有限即记录（不依赖 update 调用）
  const snapExpr = `(function(){
    const m = window.SU7.battery; if(!m) return null;
    const num = (x)=> { const n = +x; return Number.isFinite(n)? n : 'NaN('+String(x)+')'; };
    return { soc: num(m.socPct), v: num(m.vPackNow), i: num(m.iPackNow), p: num(m.pKW),
      tmax: num(m.tMaxC), rpack: num(m.rPackM), soh: num(m.sohpct),
      speed: num(window.SU7.driving?window.SU7.driving.speed:'x'),
      sameBm: m && window.SU7.driving ? (window.SU7.driving.battery === m) : 'x' };
  })`;

  const seq = [
    ["#city 初始（油门3s）", null],
    ["切 offroad（油门3s）", "offroad"],
    ["切回 road（油门3s）", "road"],
  ];
  for (const [label, btn] of seq) {
    if (btn) {
      await ev(`(function(){const b=[...document.querySelectorAll('#scene-switch button')].find(x=>x.dataset.kind==='${btn}');if(b)b.click();return b?'ok':'no';})()`);
      await sleep(2500);
    }
    const s0 = await ev(snapExpr);
    await ev(`window.SU7.driving.pressW(true)`);
    await sleep(3000);
    await ev(`window.SU7.driving.pressW(false)`);
    const s1 = await ev(snapExpr);
    const nanHit = JSON.stringify([s0,s1]).includes("NaN(");
    console.log(`\n== ${label} ==  NaN? ${nanHit?"是 ✗":"否 ✓"}`);
    console.log("  前:", JSON.stringify(s0));
    console.log("  后:", JSON.stringify(s1));
  }
  const ident = await ev(`(function(){const S=window.SU7;return{SU7batt:S.battery?'ok':'null',base:S.base&&S.base.offroadBattery?'ok':'null',same:S.battery&&S.base&&S.base.offroadBattery?(S.battery===S.base.offroadBattery):'x'};})()`);
  console.log("\n[终态身份]", JSON.stringify(ident));
  console.log("ERRS:", errs.slice(0,8));
  chrome.kill(); process.exit(0);
}
run().catch(e=>{console.error("FATAL",e.message);process.exit(1);});
