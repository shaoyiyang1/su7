/* 精确定位 NaN：包裹 battery.update，每次调用前后做 NaN 检测，
 * 捕获第一个产生/带入 NaN 的调用，打印其 dt/d 入参与调用后 soc/v/i，以及触发它的前一帧 d。
 */
const fs = require("fs");
const { spawn } = require("child_process");
const CHROME = "C:/Program Files/Google/Chrome/Application/chrome.exe";
const FILE = "file:///C:/Users/shaoyiyang/Desktop/su7-panel/小米SU7车模-离线驾驶版.html";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function run() {
  const chrome = spawn(CHROME, [
    "--headless=new","--no-sandbox","--no-proxy-server",
    "--use-gl=angle","--use-angle=swiftshader","--enable-unsafe-swiftshader",
    "--remote-debugging-port=9602",
    "--user-data-dir=" + process.env.TEMP + "/_nan_src_" + Date.now(),
    "--window-size=1600,900","about:blank",
  ], { stdio: "ignore" });
  let list = null;
  for (let i = 0; i < 40; i++) { await sleep(400); try { list = await fetch("http://127.0.0.1:9602/json/list").then(r=>r.json()); break; } catch(e){} }
  if (!list) { console.log("CDP 未就绪"); chrome.kill(); process.exit(2); }
  const page = list.find(t=>t.type==="page")||list[0];
  const ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((r,j)=>{ws.onopen=r;ws.onerror=j;});
  let id=0; const pending=new Map(); const errs=[];
  ws.addEventListener("message",(e)=>{const m=JSON.parse(e.data); if(m.id&&pending.has(m.id)){pending.get(m.id)(m.result);pending.delete(m.id);} if(m.method==="Runtime.exceptionThrown") errs.push("EXC "+(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text).slice(0,120));});
  function send(method,params){return new Promise(res=>{const i=++id;pending.set(i,res);ws.send(JSON.stringify({id:i,method,params}));});}
  async function ev(expr,to=60000){return Promise.race([send("Runtime.evaluate",{expression:expr,returnByValue:true,awaitPromise:true}).then(r=>r&&r.result&&r.result.value),sleep(to).then(()=>"TIMEOUT")]);}
  await send("Runtime.enable",{}); await send("Page.enable",{});
  await send("Page.navigate",{url:FILE});
  for(let i=0;i<40;i++){await sleep(1500); if(await ev(`!!(window.SU7&&window.SU7.driving&&window.SU7.battery)`)===true)break;}
  await sleep(1500);

  // 高频包裹：每次 update 前后检测 NaN；记录第一个 NaN 出现的调用
  await ev(`(function(){
    const m = window.SU7.battery; if(m.__nanSrcWrap) return 'already';
    m.__nanSrcWrap = true; m.__nanFirst = null; m.__calls = 0;
    const f = (x)=> typeof x==='number' && !Number.isFinite(x);
    const o = m.update.bind(m);
    m.update = function(dt, d){
      m.__calls++;
      const inBad = f(dt) || f(d&&d.speed) || f(d&&d.accel) || f(d&&d.slope);
      const preSoc = f(m.socPct), preV = f(m.vPackNow), preI = f(m.iPackNow);
      const r = o(dt, d);
      const postSoc = f(m.socPct), postV = f(m.vPackNow), postI = f(m.iPackNow), postP = f(m.pKW);
      const badIn = inBad || preSoc || preV || preI;
      const badOut = postSoc || postV || postI || postP;
      if ((badIn || badOut) && !m.__nanFirst) {
        m.__nanFirst = { call: m.__calls, dt, speed:d&&d.speed, accel:d&&d.accel, slope:d&&d.slope, onGravel:d&&d.onGravel,
          pre: {preSoc, preV, preI}, post: {postSoc, postV, postI, postP}, mode: window.SU7.driving?window.SU7.driving.driveMode:'?', kind: window.SU7.cityMap?'city':(window.SU7.map?'offroad':'road') };
      }
      return r;
    };
    return 'wrapped';
  })()`);

  await ev(`window.SU7.setDrive(true)`);
  // 依次踩油门 + 切场景，尽量触发 NaN 路径
  const seq = [
    ["road", null],
    ["city", "city"],
    ["offroad", "offroad"],
    ["road", "road"],
  ];
  let phase = 0;
  for (const [label, btn] of seq) {
    if (btn) {
      await ev(`(function(){const b=[...document.querySelectorAll('#scene-switch button')].find(x=>x.dataset.kind==='${btn}');if(b)b.click();return b?'ok':'no';})()`);
      await sleep(2500);
    }
    await ev(`window.SU7.driving.pressW(true)`);
    await sleep(2000);
    await ev(`window.SU7.driving.pressW(false)`);
    await sleep(500);
    phase++;
  }
  const first = await ev(`window.SU7.battery.__nanFirst`);
  const calls = await ev(`window.SU7.battery.__calls`);
  console.log("\n[update 总调用次数]", calls);
  console.log("[第一个 NaN 调用] (null = 全程无 NaN):");
  console.log(JSON.stringify(first, null, 2));
  const final = await ev(`(function(){const m=window.SU7.battery;return{soc:m.socPct,v:m.vPackNow,i:m.iPackNow,p:m.pKW,speed:window.SU7.driving.speed,qNow:m.qNowAh?m.qNowAh():'noFn'};})()`);
  console.log("[终态]", JSON.stringify(final));
  console.log("ERRS:", errs.slice(0,8));
  chrome.kill(); process.exit(0);
}
run().catch(e=>{console.error("FATAL",e.message);process.exit(1);});
