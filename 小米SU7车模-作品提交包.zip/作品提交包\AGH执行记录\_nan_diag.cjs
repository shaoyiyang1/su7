/* 只读诊断：三场景（road→city→offroad）各踩油门，采集 socPct/vPackNow/iPackNow/driving.speed，
 * 并包裹 battery.update 打印入口 dt/d 参数，定位 NaN 来自入参还是模型内部。
 */
const fs = require("fs");
const { spawn } = require("child_process");
const CHROME = "C:/Program Files/Google/Chrome/Application/chrome.exe";
const FILE = "file:///C:/Users/shaoyiyang/Desktop/su7-panel/小米SU7车模-离线驾驶版.html";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const SNAP = `(function(){
  const S = window.SU7; const m = S.battery; const d = S.driving;
  const num = (x)=> { const n = +x; return Number.isFinite(n)? n : String(x); };
  return {
    soc: num(m ? m.socPct : -1),
    v: num(m ? m.vPackNow : -1),
    i: num(m ? m.iPackNow : -1),
    pKW: num(m ? m.pKW : -1),
    speed: num(d ? d.speed : -1),
    derate: num(m ? m.powerDerate : -1),
    qNowAh: num(m && m.qNowAh ? m.qNowAh() : 'noFn'),
    sameBm: m && d ? (d.battery === m) : 'x'
  };
})()`;

async function run() {
  const chrome = spawn(CHROME, [
    "--headless=new","--no-sandbox","--no-proxy-server",
    "--use-gl=angle","--use-angle=swiftshader","--enable-unsafe-swiftshader",
    "--remote-debugging-port=9601",
    "--user-data-dir=" + process.env.TEMP + "/_nan_diag_" + Date.now(),
    "--window-size=1600,900","about:blank",
  ], { stdio: "ignore" });
  let list = null;
  for (let i = 0; i < 40; i++) { await sleep(400); try { list = await fetch("http://127.0.0.1:9601/json/list").then(r=>r.json()); break; } catch(e){} }
  if (!list) { console.log("CDP 未就绪"); chrome.kill(); process.exit(2); }
  const page = list.find(t=>t.type==="page")||list[0];
  const ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((r,j)=>{ws.onopen=r;ws.onerror=j;});
  let id=0; const pending=new Map(); const errs=[];
  ws.addEventListener("message",(e)=>{const m=JSON.parse(e.data); if(m.id&&pending.has(m.id)){pending.get(m.id)(m.result);pending.delete(m.id);} if(m.method==="Runtime.exceptionThrown") errs.push("EXC "+(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text).slice(0,160));});
  function send(method,params){return new Promise(res=>{const i=++id;pending.set(i,res);ws.send(JSON.stringify({id:i,method,params}));});}
  async function ev(expr,to=60000){return Promise.race([send("Runtime.evaluate",{expression:expr,returnByValue:true,awaitPromise:true}).then(r=>r&&r.result&&r.result.value),sleep(to).then(()=>"TIMEOUT")]);}
  await send("Runtime.enable",{}); await send("Page.enable",{});
  await send("Page.navigate",{url:FILE});
  let ready=false;
  for(let i=0;i<40;i++){await sleep(1500); if(await ev(`!!(window.SU7&&window.SU7.driving&&window.SU7.battery)`)===true){ready=true;break;}}
  if(!ready){console.log("NOT READY; SU7keys=",await ev(`window.SU7?Object.keys(window.SU7).join(','):'none'`),"; errs=",errs);chrome.kill();process.exit(3);}
  await sleep(1500);
  await ev(`window.SU7.setDrive(true)`);

  // 包裹 battery.update 打印入口参数（每 30 次打一次，避免刷屏）
  await ev(`(function(){
    const m = window.SU7.battery; if(m && m.__nanWrap)return;
    m.__nanWrap = true; m.__call=0; m.__bad=[];
    const o = m.update.bind(m);
    m.update = function(dt, d){ m.__call++; if(m.__call%30===1){ m.__bad.push({dt, s:d&&d.speed, a:d&&d.accel, sl:d&&d.slope, g:d&&d.onGravel, soc:m.socPct, v:m.vPackNow, i:m.iPackNow}); } return o(dt, d); };
    return 'wrapped';
  })()`);

  async function throttle3(label){
    const s0 = await ev(SNAP);
    await ev(`window.SU7.driving.pressW(true)`);
    await sleep(3000);
    await ev(`window.SU7.driving.pressW(false)`);
    const s1 = await ev(SNAP);
    console.log(`\n== ${label} ==`);
    console.log("  前:", JSON.stringify(s0));
    console.log("  后:", JSON.stringify(s1));
    const bad = await ev(`window.SU7.battery.__bad.slice(-4)`);
    console.log("  update 入口采样(dt/speed/accel/slope/onGravel/soc/v/i):", JSON.stringify(bad));
    const nan = ["soc","v","i","speed"].some(k=>/NaN/.test(String(s1[k])));
    console.log(`  ${label}: NaN 出现? ${nan ? "是 ✗":"否 ✓"}`);
  }

  console.log("场景顺序: road → city → offroad（应用内点击切换）");
  await throttle3("场景1 road（油门3s）");
  console.log("\n-- 点击「城市」--");
  await ev(`(function(){const b=[...document.querySelectorAll('#scene-switch button')].find(x=>x.dataset.kind==='city');if(b)b.click();return b?'ok':'no';})()`);
  await sleep(2500);
  await throttle3("场景2 city（油门3s）");
  console.log("\n-- 点击「越野」--");
  await ev(`(function(){const b=[...document.querySelectorAll('#scene-switch button')].find(x=>x.dataset.kind==='offroad');if(b)b.click();return b?'ok':'no';})()`);
  await sleep(2500);
  await throttle3("场景3 offroad（油门3s）");

  // 全量 bad 记录
  const allBad = await ev(`window.SU7.battery.__bad`);
  console.log("\n[update 入口全部采样]", JSON.stringify(allBad));
  const final = await ev(SNAP);
  console.log("[终态]", JSON.stringify(final));
  console.log("\nERRS:", errs.slice(0,10));
  chrome.kill(); process.exit(0);
}
run().catch(e=>{console.error("FATAL",e.message);process.exit(1);});
