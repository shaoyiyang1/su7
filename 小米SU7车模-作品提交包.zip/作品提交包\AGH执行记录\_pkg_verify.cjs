/* 验证「提交包内」的离线 HTML 可正常运行（不是验证项目目录里的那份）
 * 检查：加载成功、SU7 就绪、三场景可切、电池数据无 NaN、曲线渲染
 */
const { spawn } = require("child_process");
const CHROME = "C:/Program Files/Google/Chrome/Application/chrome.exe";
const FILE = "file:///C:/Users/shaoyiyang/WorkBuddy/2026-10-03-18-03-15/agnes-harness/作品提交包/小米SU7车模-离线驾驶版.html";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function run() {
  const chrome = spawn(CHROME, [
    "--headless=new","--no-sandbox","--no-proxy-server",
    "--use-gl=angle","--use-angle=swiftshader","--enable-unsafe-swiftshader",
    "--remote-debugging-port=9606",
    "--user-data-dir=" + process.env.TEMP + "/_pkg_verify_" + Date.now(),
    "--window-size=1600,900","--force-device-scale-factor=1","about:blank",
  ], { stdio: "ignore" });
  let list = null;
  for (let i = 0; i < 40; i++) { await sleep(400); try { list = await fetch("http://127.0.0.1:9606/json/list").then(r=>r.json()); break; } catch(e){} }
  if (!list) { console.log("CDP 未就绪"); chrome.kill(); process.exit(2); }
  const page = list.find(t=>t.type==="page")||list[0];
  const ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((r,j)=>{ws.onopen=r;ws.onerror=j;});
  let id=0; const pending=new Map(); const errs=[];
  ws.addEventListener("message",(e)=>{const m=JSON.parse(e.data); if(m.id&&pending.has(m.id)){pending.get(m.id)(m.result);pending.delete(m.id);} if(m.method==="Runtime.exceptionThrown") errs.push("EXC "+(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text).slice(0,140));});
  function send(method,params){return new Promise(res=>{const i=++id;pending.set(i,res);ws.send(JSON.stringify({id:i,method,params}));});}
  async function ev(expr,to=60000){return Promise.race([send("Runtime.evaluate",{expression:expr,returnByValue:true,awaitPromise:true}).then(r=>r&&r.result&&r.result.value),sleep(to).then(()=>"TIMEOUT")]);}
  await send("Runtime.enable",{}); await send("Page.enable",{});
  await send("Page.navigate",{url:FILE});
  let ready=false;
  for(let i=0;i<40;i++){await sleep(1500); if(await ev(`!!(window.SU7&&window.SU7.driving&&window.SU7.battery)`)===true){ready=true;break;}}
  console.log("1) 页面加载 + SU7 就绪:", ready ? "✓" : "✗");
  if(!ready){ console.log("   SU7 keys:", await ev(`window.SU7?Object.keys(window.SU7).join(','):'no SU7'`)); console.log("   ERRS:", errs); chrome.kill(); process.exit(3); }
  await sleep(2000);

  // 车漆区块隐藏
  const paintHidden = await ev(`(function(){
    let hidden = true;
    document.querySelectorAll('.sp-root .sp-sec-title').forEach(t=>{
      if (t.textContent.includes('车漆')) { const s=t.closest('.sp-sec'); const r=s&&s.getBoundingClientRect(); if(r&&r.height>0) hidden=false; }
    });
    return hidden;
  })()`);
  console.log("2) 车漆预设区块隐藏:", paintHidden ? "✓" : "✗");

  // dock 尺寸
  const dock = await ev(`(function(){const d=document.getElementById('curve-dock'); if(!d)return null; return {w:d.offsetWidth,h:d.offsetHeight,vs:d.scrollHeight>d.clientHeight+1,hs:d.scrollWidth>d.clientWidth+1};})()`);
  console.log("3) 曲线 dock:", JSON.stringify(dock), dock && dock.h<=200 && !dock.vs && !dock.hs ? "✓" : "✗");

  // 三场景 + 油门，检测 NaN
  await ev(`window.SU7.setDrive(true)`);
  const seq = [["road",null],["city","city"],["offroad","offroad"]];
  let allFinite = true;
  for (const [label,btn] of seq) {
    if (btn) { await ev(`(function(){const b=[...document.querySelectorAll('#scene-switch button')].find(x=>x.dataset.kind==='${btn}');if(b)b.click();return 1;})()`); await sleep(2500); }
    const pre = await ev(`(function(){const m=window.SU7.battery,d=window.SU7.driving;return{soc:m.socPct,v:m.vPackNow,i:m.iPackNow,s:d.speed};})()`);
    await ev(`window.SU7.driving.pressW(true)`); await sleep(2500); await ev(`window.SU7.driving.pressW(false)`); await sleep(500);
    const post = await ev(`(function(){const m=window.SU7.battery,d=window.SU7.driving;const F=(x)=>Number.isFinite(x);return{soc:m.socPct,v:m.vPackNow,i:m.iPackNow,s:d.speed,ok:F(m.socPct)&&F(m.vPackNow)&&F(m.iPackNow)&&F(d.speed)};})()`);
    if (!post.ok) allFinite = false;
    console.log(`   ${label}: soc ${pre.soc.toFixed(3)} → ${post.soc.toFixed(3)} | speed ${pre.s.toFixed(2)} → ${post.s.toFixed(2)} | finite=${post.ok}`);
  }
  console.log("4) 三场景无 NaN:", allFinite ? "✓" : "✗");

  // 曲线渲染
  const ink = await ev(`(function(){const d=document.getElementById('curve-dock');const o=[];for(const c of d.querySelectorAll('canvas')){const x=c.getContext('2d');const w=c.width,h=c.height;if(!w||!h){o.push(0);continue;}const im=x.getImageData(0,0,w,h).data;let n=0;for(let i=0;i<im.length;i+=4){if(im[i]>20||im[i+1]>20||im[i+2]>20)n++;}o.push(n);}return o;})()`);
  console.log("5) 三条曲线墨迹量:", JSON.stringify(ink), ink.every(n=>n>200) ? "✓" : "✗");

  console.log("6) JS 错误数:", errs.length, errs.length===0 ? "✓" : "✗");
  const pass = ready && paintHidden && dock && dock.h<=200 && !dock.vs && !dock.hs && allFinite && ink.every(n=>n>200) && errs.length===0;
  console.log("\n提交包内 HTML 验证:", pass ? "全部通过 ✓" : "有未通过项 ✗");
  chrome.kill(); process.exit(pass?0:1);
}
run().catch(e=>{console.error("FATAL",e.message);process.exit(1);});
