/* 验证离线包：#city 与无 hash 两种 → HUD 常驻 + 不闪 + dock 尺寸 + 截图 */
const fs = require("fs");
const { spawn } = require("child_process");
const CHROME = "C:/Program Files/Google/Chrome/Application/chrome.exe";
const FILE = "file:///C:/Users/shaoyiyang/Desktop/su7-panel/小米SU7车模-离线驾驶版.html";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function runCase(hash, port, tag) {
  const url = FILE + (hash || "");
  const chrome = spawn(CHROME, [
    "--headless=new", "--no-sandbox", "--no-proxy-server",
    "--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader",
    `--remote-debugging-port=${port}`,
    "--user-data-dir=" + process.env.TEMP + "/_verify_" + tag + "_" + Date.now(),
    "--window-size=1600,900", "about:blank",
  ], { stdio: "ignore" });
  let list = null;
  for (let i = 0; i < 40; i++) { await sleep(400); try { list = await fetch(`http://127.0.0.1:${port}/json/list`).then(r => r.json()); break; } catch (e) {} }
  if (!list) { console.log(tag, "CDP 未就绪"); chrome.kill(); return null; }
  const page = list.find(t => t.type === "page") || list[0];
  const ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
  let id = 0; const pending = new Map(); const errs = [];
  ws.addEventListener("message", (e) => {
    const m = JSON.parse(e.data);
    if (m.id && pending.has(m.id)) { pending.get(m.id)(m.result); pending.delete(m.id); }
    if (m.method === "Runtime.exceptionThrown") errs.push("EXC " + (m.params.exceptionDetails.exception?.description || m.params.exceptionDetails.text).slice(0, 200));
  });
  function send(method, params) { return new Promise((res) => { const i = ++id; pending.set(i, res); ws.send(JSON.stringify({ id: i, method, params })); }); }
  async function ev(expr, to = 60000) {
    return Promise.race([send("Runtime.evaluate", { expression: expr, returnByValue: true, awaitPromise: true }).then(r => r && r.result && r.result.value), sleep(to).then(() => "TIMEOUT")]);
  }
  await send("Runtime.enable", {}); await send("Page.enable", {});
  await send("Page.navigate", { url });
  let ready = false;
  for (let i = 0; i < 40; i++) { await sleep(1500); const r = await ev(`!!(window.SU7 && window.SU7.driving)`); if (r === true) { ready = true; break; } }
  if (!ready) { console.log(tag, "NOT READY, errs:", errs.slice(0, 5)); chrome.kill(); return null; }
  await sleep(2000);
  // 进驾驶模式 + 踩油门 4s（让曲线有数据）
  await ev(`(function(){ if(window.SU7.setDrive) window.SU7.setDrive(true); window.dispatchEvent(new KeyboardEvent('keydown',{code:'KeyW'})); return 1; })()`);
  await sleep(4500);

  // ① HUD 可见性 + display 变更计数（4 秒内）
  const displayWatch = await ev(`(function(){
    const h = document.getElementById('safety-hud');
    if (!h) return {hud:false};
    const obs = new Set();
    const io = new MutationObserver(()=>{ obs.add(h.style.display); });
    io.observe(h, {attributes:true, attributeFilter:['style']});
    return new Promise(res => setTimeout(()=>{ io.disconnect(); res({hud:true, display:h.style.display,
      bigCount:h.querySelectorAll('.sh-big').length, secs:[...h.querySelectorAll('.sh-sec-label')].map(e=>e.textContent)}); }, 4000));
  })()`, 12000);
  await ev(`(function(){ window.dispatchEvent(new KeyboardEvent('keyup',{code:'KeyW'})); return 1; })()`);

  // ② 车速行 vs 推荐车速行的 DOM 顺序（应在推荐车速上方）
  const order = await ev(`(function(){
    const h = document.getElementById('safety-hud'); if(!h) return 'NO HUD';
    const secs=[...h.querySelectorAll('.sh-sec')];
    const recSec = secs.find(s=>/推荐车速/.test(s.querySelector('.sh-sec-label')?.textContent||''));
    if(!recSec) return 'NO REC SEC';
    const bigs=[...recSec.querySelectorAll('.sh-big')].map(b=>({txt:b.textContent, cls:b.className}));
    const subs=[...recSec.querySelectorAll('.sh-sub')].map(s=>s.textContent);
    return JSON.stringify({recSecLabel: recSec.querySelector('.sh-sec-label')?.textContent, bigs, subs});
  })()`);

  // ③ dock 尺寸
  const dock = await ev(`(function(){
    const d = document.getElementById('curve-dock');
    if (!d) return {dock:false};
    const r = d.getBoundingClientRect();
    const cs = getComputedStyle(d);
    const canvases = [...d.querySelectorAll('canvas')].map(c=>({w:c.width,h:c.height,cw:c.clientWidth,ch:c.clientHeight,
      ink: (function(){try{const x=c.getContext('2d');const dd=x.getImageData(0,0,c.width,c.height).data;let n=0;for(let k=0;k<dd.length;k+=4)if(dd[k+3]>8)n++;return n;}catch(e){return -1}})()}));
    return {dock:true, offW:d.offsetWidth, offH:d.offsetHeight, rect:{w:Math.round(r.width),h:Math.round(r.height)},
      maxH:cs.maxHeight, overflow:cs.overflowY, canvasCount:canvases.length, canvases};
  })()`);

  // ④ 曲线是否动态（两次采样）
  const dyn = await ev(`(function(){
    const m = window.SU7.battery; if(!m) return 'NO BATTERY';
    const s0 = m.historyTotalSamples;
    return new Promise(res => setTimeout(()=>{
      const s1 = m.historyTotalSamples;
      res(JSON.stringify({samples0:s0, samples1:s1, grew:s1>s0, charts:(window.__spCharts||[]).map(c=>c.lengths)}));
    }, 2000));
  })()`, 8000);

  // ⑤ 截图
  const shot = await send("Page.captureScreenshot", { format: "png" });
  const out = "C:/Users/shaoyiyang/WorkBuddy/2026-10-03-18-03-15/agnes-harness/su7-replica/_verify_" + tag + ".png";
  if (shot && shot.data) fs.writeFileSync(out, Buffer.from(shot.data, "base64"));

  console.log("\n=== 案例 " + tag + "（hash=" + JSON.stringify(hash) + "）===");
  console.log("displayWatch:", JSON.stringify(displayWatch));
  console.log("recSec:", order);
  console.log("dock:", dock);
  console.log("dyn:", dyn);
  console.log("errs:", errs.slice(0, 6));
  chrome.kill();
  return { displayWatch, order, dock, dyn, errs };
}

(async () => {
  // 先关掉可能残留的 5188 旧 vite（不影响离线验证，但避免 Chrome 抢占）
  const c1 = await runCase("#city", "9501", "city");
  await sleep(500);
  const c2 = await runCase("", "9502", "nohash");
  if (!c1 || !c2) { console.log("有案例未跑通"); process.exit(3); }
  console.log("\n== 汇总 ==");
  const ok = (x) => x && x.dock && x.dock.dock;
  console.log("city: HUD=", JSON.stringify(c1.displayWatch && c1.displayWatch.hud), "dockSize=", c1.dock && (c1.dock.offW + "x" + c1.dock.offH), "dyn=", c1.dyn);
  console.log("nohash: HUD=", JSON.stringify(c2.displayWatch && c2.displayWatch.hud), "dockSize=", c2.dock && (c2.dock.offW + "x" + c2.dock.offH), "dyn=", c2.dyn);
  process.exit(0);
})().catch(e => { console.error("FATAL", e.message); process.exit(1); });
