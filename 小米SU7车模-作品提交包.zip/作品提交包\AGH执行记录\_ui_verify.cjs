/* 验证：车漆区块隐藏 + #curve-dock 压扁 ≤200px、无滚动条、曲线完整、数据实时刷新。
 * 输出：dock 宽高、滚动条判据、曲线 canvas 实测尺寸与墨迹量、图例文字、面板区块可见性、截图。
 */
const fs = require("fs");
const { spawn } = require("child_process");
const CHROME = "C:/Program Files/Google/Chrome/Application/chrome.exe";
const FILE = "file:///C:/Users/shaoyiyang/Desktop/su7-panel/小米SU7车模-离线驾驶版.html";
const OUT = "C:/Users/shaoyiyang/WorkBuddy/2026-10-03-18-03-15/agnes-harness/su7-replica";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function run() {
  const chrome = spawn(CHROME, [
    "--headless=new","--no-sandbox","--no-proxy-server",
    "--use-gl=angle","--use-angle=swiftshader","--enable-unsafe-swiftshader",
    "--remote-debugging-port=9605",
    "--user-data-dir=" + process.env.TEMP + "/_ui_adj_" + Date.now(),
    "--window-size=1600,900","--force-device-scale-factor=1","about:blank",
  ], { stdio: "ignore" });
  let list = null;
  for (let i = 0; i < 40; i++) { await sleep(400); try { list = await fetch("http://127.0.0.1:9605/json/list").then(r=>r.json()); break; } catch(e){} }
  if (!list) { console.log("CDP 未就绪"); chrome.kill(); process.exit(2); }
  const page = list.find(t=>t.type==="page")||list[0];
  const ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((r,j)=>{ws.onopen=r;ws.onerror=j;});
  let id=0; const pending=new Map(); const errs=[];
  ws.addEventListener("message",(e)=>{const m=JSON.parse(e.data); if(m.id&&pending.has(m.id)){pending.get(m.id)(m.result);pending.delete(m.id);} if(m.method==="Runtime.exceptionThrown") errs.push("EXC "+(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text).slice(0,140));});
  function send(method,params){return new Promise(res=>{const i=++id;pending.set(i,res);ws.send(JSON.stringify({id:i,method,params}));});}
  async function ev(expr,to=60000){return Promise.race([send("Runtime.evaluate",{expression:expr,returnByValue:true,awaitPromise:true}).then(r=>r&&r.result&&r.result.value),sleep(to).then(()=>"TIMEOUT")]);}
  async function shot(name){
    const r = await send("Page.captureScreenshot",{format:"png"});
    if (r && r.data) { fs.writeFileSync(OUT + "/" + name, Buffer.from(r.data,"base64")); return true; }
    return false;
  }
  await send("Runtime.enable",{}); await send("Page.enable",{});
  await send("Page.navigate",{url:FILE});
  for(let i=0;i<40;i++){await sleep(1500); if(await ev(`!!(window.SU7&&window.SU7.driving&&window.SU7.battery)`)===true)break;}
  await sleep(2500);

  // 1) 面板区块可见性
  const secs = await ev(`(function(){
    const out = [];
    document.querySelectorAll('.sp-root .sp-sec-title, .sp-root .sp-head h1').forEach((t)=>{
      const sec = t.closest('.sp-sec') || t.closest('.sp-head');
      const r = sec ? sec.getBoundingClientRect() : null;
      out.push({ title: t.textContent.trim().slice(0,24), visible: !!r && r.height>0 && r.width>0, h: r?Math.round(r.height):0 });
    });
    return out;
  })()`);
  console.log("== 面板区块可见性 ==");
  for (const s of secs) console.log(`  ${s.visible?"可见":"隐藏"}  h=${String(s.h).padStart(3)}  ${s.title}`);

  // 2) dock 几何 + 滚动条
  const dockInfo = await ev(`(function(){
    const d = document.getElementById('curve-dock');
    if(!d) return null;
    const r = d.getBoundingClientRect();
    const cs = getComputedStyle(d);
    const vScroll = d.scrollHeight > d.clientHeight + 1;
    const hScroll = d.scrollWidth > d.clientWidth + 1;
    const cv = [...d.querySelectorAll('canvas')].map((c)=>{
      const cr = c.getBoundingClientRect();
      return { cssW: Math.round(cr.width), cssH: Math.round(cr.height), backW: c.width, backH: c.height };
    });
    return {
      offsetW: d.offsetWidth, offsetH: d.offsetHeight,
      rectH: Math.round(r.height), rectW: Math.round(r.width),
      scrollH: d.scrollHeight, clientH: d.clientHeight,
      vScroll, hScroll,
      padding: cs.padding, overflow: cs.overflow,
      canvases: cv,
      legend: [...d.querySelectorAll('.sp-chart-legend')].map(e=>e.textContent.trim()),
      accLine: (d.querySelector('.sp-batt-note')||{}).textContent || '',
      secTitle: (d.querySelector('.sp-sec-title')||{}).textContent || '',
      titlePx: (d.querySelector('.sp-chart-title')?getComputedStyle(d.querySelector('.sp-chart-title')).fontSize:'-'),
      legendPx: (d.querySelector('.sp-chart-legend')?getComputedStyle(d.querySelector('.sp-chart-legend')).fontSize:'-'),
      canvasPx: (d.querySelector('canvas')?getComputedStyle(d.querySelector('canvas')).height:'-')
    };
  })()`);
  console.log("\n== #curve-dock 几何 ==");
  console.log(JSON.stringify(dockInfo, null, 2));

  await shot("_ui_after_idle.png");

  // 3) 踩油门 3s：确认曲线/图例实时刷新
  const before = await ev(`(function(){
    const d=document.getElementById('curve-dock');
    return { legend: [...d.querySelectorAll('.sp-chart-legend')].map(e=>e.textContent.trim()),
             acc: (d.querySelector('.sp-batt-note')||{}).textContent||'',
             samples: window.SU7.battery.historyTotalSamples, soc: window.SU7.battery.socPct };
  })()`);
  await ev(`window.SU7.setDrive(true)`);
  await ev(`window.SU7.driving.pressW(true)`);
  await sleep(3000);
  await ev(`window.SU7.driving.pressW(false)`);
  await sleep(900);
  const after = await ev(`(function(){
    const d=document.getElementById('curve-dock');
    return { legend: [...d.querySelectorAll('.sp-chart-legend')].map(e=>e.textContent.trim()),
             acc: (d.querySelector('.sp-batt-note')||{}).textContent||'',
             samples: window.SU7.battery.historyTotalSamples, soc: window.SU7.battery.socPct,
             speed: window.SU7.driving.speed };
  })()`);
  console.log("\n== 踩油门前后（曲线数据实时性）==");
  console.log("  前 legend:", JSON.stringify(before.legend), "| acc:", before.acc, "| samples:", before.samples, "| soc:", before.soc);
  console.log("  后 legend:", JSON.stringify(after.legend), "| acc:", after.acc, "| samples:", after.samples, "| soc:", after.soc, "| speed:", after.speed);
  console.log("  samples 增长:", after.samples > before.samples ? "是 ✓" : "否 ✗", "| 图例变化:", JSON.stringify(after.legend)!==JSON.stringify(before.legend) ? "是 ✓" : "否 ✗");

  // 4) 曲线墨迹量（确认压扁后仍完整渲染、不失真）
  const ink = await ev(`(function(){
    const d=document.getElementById('curve-dock');
    const out=[];
    for (const c of d.querySelectorAll('canvas')) {
      const ctx=c.getContext('2d');
      const w=c.width,h=c.height; if(!w||!h){out.push(0);continue;}
      const im=ctx.getImageData(0,0,w,h).data;
      let n=0; for(let i=0;i<im.length;i+=4){ if(im[i]>20||im[i+1]>20||im[i+2]>20) n++; }
      out.push(n);
    }
    return out;
  })()`);
  console.log("\n== 三条曲线墨迹像素量（>0 即已渲染）==", JSON.stringify(ink));

  await shot("_ui_after_drive.png");

  // 5) 判定
  const ok = dockInfo && dockInfo.offsetH <= 200 && !dockInfo.vScroll && !dockInfo.hScroll
    && ink.every(n=>n>200) && after.samples > before.samples;
  console.log("\n== 判定 ==");
  console.log("  dock offsetHeight ≤200px:", dockInfo? dockInfo.offsetH + "px " + (dockInfo.offsetH<=200?"✓":"✗") : "n/a");
  console.log("  无滚动条:", dockInfo && !dockInfo.vScroll && !dockInfo.hScroll ? "✓" : "✗");
  console.log("  三条曲线均渲染:", ink.every(n=>n>200) ? "✓" : "✗");
  console.log("  数据实时刷新:", after.samples>before.samples ? "✓" : "✗");
  console.log(ok ? "\n全部通过 ✓" : "\n有未通过项 ✗");
  const paintHidden = !secs.some(s=>s.title.includes("车漆") && s.visible);
  console.log("车漆区块隐藏:", paintHidden ? "✓" : "✗");
  console.log("ERRS:", errs.slice(0,6));
  chrome.kill(); process.exit(ok && paintHidden ? 0 : 1);
}
run().catch(e=>{console.error("FATAL",e.message);process.exit(1);});
